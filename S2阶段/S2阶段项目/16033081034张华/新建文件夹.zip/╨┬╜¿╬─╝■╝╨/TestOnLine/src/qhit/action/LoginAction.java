package qhit.action;





import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import qhit.bean.Classes;
import qhit.bean.PageBean;
import qhit.bean.Paper;
import qhit.bean.Question;
import qhit.bean.Score;
import qhit.bean.Student;
import qhit.bean.Subject;
import qhit.bean.User;
import qhit.biz.UserBiz;
import qhit.biz.impl.UserBizImpl;

public class LoginAction extends ActionSupport{
	private User user;//�û�
	private Subject sub;//��Ŀ
	private List<Subject> subs;//��Ŀ����
	private List<Object[]> objs;//��Ŀͳ����ʾ ��ʾΪ��Ŀ���� ��Ŀid ��Ŀ����ͳ��
	private List<Paper> papers;
	private List dirs;//���򼯺�
	private List stas;//�׶μ���
	private List<Score> scores;//�ɼ����󼯺�
	private String dir;//�������
	private String sta;//�׶ζ���
	private Score score;//�ɼ�����
	private PageBean pb;//��ҳ��ʾ����
	private Paper paper;//�Ծ�����
	private UserBiz biz=new UserBizImpl();
	private Student s;
	private int zrenshu;//������
	private int jrenshu;//��������
	private double jigelv;//������
	
	private PageBean pagebean;//��ҳ��pagebean
	private int p;
	
	private List<Classes> listclasses;//������а༶
	private String begintime;//��ſ���ʱ��
	private Set<Integer> classid;//���Ҫ���Եİ༶
	
	private String identifer="�鿴�ɼ����Ծ���ҳ";//��ʶ������������ĳЩ����
	
	private List<Question> listtopic;// ���������Ŀ
	private Integer[] topicid;// ���������ѡ�е���Ŀ
	private Integer topiccount=0;//�������ѡ�е���Ŀ��
	
	
	private List<Question> radioeasy;//��ѡ����
	private List<Question> radiomedium;//��ѡһ����
	private List<Question> radiodifficulty;//��ѡ������
	private List<Question> choiceeasy;//��ѡ����
	private List<Question> choicemedium;//��ѡһ����
	private List<Question> choicedifficulty;//��ѡ������
	private Integer[] condition;//����ѡ��ֱ����Ŀ����
	private String result;
	//��½����

	public String Login(){
		  if(user.getRole()==3){
			  if(biz.findAdmi(user)!=null){
				  s=biz.findStudent(user);
				  Map<String, Object> session=ActionContext.getContext().getSession();
				  session.put("user",s);
					session.put("u",user);
				  return "loginok";
			  }
			  
		  }	else if(user.getRole()==2){
			  if(biz.findTeachar(user)!=null){
				  s=biz.findStudent(user);
				  Map<String, Object> session=ActionContext.getContext().getSession();
				  session.put("user",s);
					session.put("u",user);
					
				  return "loginok";  
			  }
		  }else if(user.getRole()==1){
			  if(biz.findStudent(user)!=null){
				  s=biz.findStudent(user);
				  Map<String, Object> session=ActionContext.getContext().getSession();
				  session.put("user",s);
					session.put("u",user);
				  return "loginok";
			  }
		  }
		  System.out.println("��¼ʧ��");
			this.addFieldError("loginfail", "������������������");
			return "loginfail";
		}
	
	//��ʾ��Ŀ����
	public String showsub(){
		if (dir==null) {
			//��һ�η���ʱ���跽��ͽ׶γ�ʼֵ�������� �׶� ��Ŀ �ֱ�������
			dir="3G4G";
			sta="s3";
			dirs=biz.dirList(Subject.class);
			stas=biz.staList(Subject.class, dir);
			objs=biz.subList( dir, sta);
		} else {
			dirs=biz.dirList(Subject.class);
			stas=biz.staList(Subject.class, dir);
			System.out.println("showsub������������");
			objs=biz.subList(dir, sta);
		}
		
		return "showsub";
	}
	
	//���ݷ���ı� �ı�׶������б�
	public String showsta(){
		dirs=biz.dirList(Subject.class);
		stas=biz.staList(Subject.class, dir);
		if (sta==null) {
			sta="s1";
		}
		objs=biz.subList( dir, sta);
		return "showsub";
	}

	//��ʾ����
	public String showque(){
		 
		return null;
	}
	
	//�Ծ������ݷ���ͽ׶θ��Ŀ�Ŀ--�Ƕ�̬��ѯ(�鿴�ɼ��������ͽ׶�ʱ)
	public String getstabydir(){
		showsta();
		pagebean=biz.showtestpaper(identifer,p,null);
		return "showtestpaper";
	}
	
	//�Ծ������ݷ���ͽ׶θ��Ŀ�Ŀ--�Ƕ�̬��ѯ���鿴�Ծ���
	public String getstaby(){
		showsta();
		pagebean=biz.showtestpaper(identifer,p,null);
		return "paper";
	}
	
	//ѡ������������п��ҳ��ʾ����
	public String xuanfangxiang(){
		
		return null;
	}
	
	//��ʾ�Ծ��������鿴�Ծ���
	public String paper(){
		identifer="�鿴�Ծ����Ծ���ҳ";
		showtestpaper();
		return "paper";
	}
	
	
	
	//���ݷ���ı�������(ѡ�������)
	public String updatesub(){
		showsta();
		pagebean=biz.qbcshowquestionbysub(p, sub);
		return "addpaper";
	}
	
	//ȡ�������ѡ�е���ĿID������topicid�е��ظ�Ԫ��
	public Integer[] repeat() {
		if(topicid==null||topicid.length<=0) {
			return null;
		}
		List<Integer> list=new ArrayList<Integer>();
		for (Integer id : topicid) {
			if(topicid!=null&&topicid.length>0) {
				if(!list.contains(id)) {
					list.add(id);
				}
			}
		}
		return list.toArray(new Integer[list.size()]);
	}
	
	//���������ϸ�ֵ�ķ���
	public void getQuestions(Subject s){
		Subject subject=biz.showonesub(s);
		
		Question question1=new Question();
		question1.setSubject(subject);
		question1.setChoose("��ѡ");
		question1.setDifficulty("��");
		radioeasy=biz.showsixques(question1);
		
		Question question2=new Question();
		question2.setSubject(subject);
		question2.setChoose("��ѡ");
		question2.setDifficulty("һ��");
		radiomedium=biz.showsixques(question2);
		
		Question question3=new Question();
		question3.setSubject(subject);
		question3.setChoose("��ѡ");
		question3.setDifficulty("����");
		radiodifficulty=biz.showsixques(question3);
		
		Question question4=new Question();
		question4.setSubject(subject);
		question4.setChoose("��ѡ");
		question4.setDifficulty("��");
		choiceeasy=biz.showsixques(question4);
		
		Question question5=new Question();
		question5.setSubject(subject);
		question5.setChoose("��ѡ");
		question5.setDifficulty("һ��");
		choicemedium=biz.showsixques(question5);
		
		Question question6=new Question();
		question6.setSubject(subject);
		question6.setChoose("��ѡ");
		question6.setDifficulty("����");
		choicedifficulty=biz.showsixques(question6);
	}
	//�������ͽ׶ο�Ŀ�����仯(������)
	public String bianbianbian(){
		showsta();
		sub=new Subject();
		sub.setId((Integer)objs.get(0)[1]);
		getQuestions(sub);
		return "random";
	}
	
	//����������Լ�ѡ���Ŀʱ��ת
	public String random(){
		showsub();
		if (paper==null) {
			sub=new Subject();
			sub.setId((Integer)objs.get(0)[1]);
			
		}else {
			sub=paper.getSubject();
		}
		getQuestions(sub);
		return "random";
	}
	
	//��������Ծ�����
	public String theend(){
		sub=paper.getSubject();
		getQuestions(sub);
		List<Question> allquestion=new ArrayList<Question>();
		Integer[] question=new Integer[paper.getQnumber()];
		if (condition[0]!=null) {
			Collections.shuffle(radioeasy);
			for (int i = 0; i <condition[0]; i++) {
				allquestion.add(radioeasy.get(i));
			}
		}
		if (condition[1]!=null) {
			Collections.shuffle(radiomedium);
			for (int i = 0; i <condition[1]; i++) {
				allquestion.add(radiomedium.get(i));
			}
		}
		if (condition[2]!=null) {
			Collections.shuffle(radiodifficulty);
			for (int i = 0; i <condition[2]; i++) {
				allquestion.add(radiodifficulty.get(i));
			}
		}
		if (condition[3]!=null) {
			Collections.shuffle(choiceeasy);
			for (int i = 0; i <condition[3]; i++) {
				allquestion.add(choiceeasy.get(i));
			}
		}
		if (condition[4]!=null) {
			Collections.shuffle(choicemedium);
			for (int i = 0; i <condition[4]; i++) {
				allquestion.add(choicemedium.get(i));
			}
		}
		if (condition[5]!=null) {
			Collections.shuffle(choicedifficulty);
			for (int i = 0; i <condition[5]; i++) {
				allquestion.add(choicedifficulty.get(i));
			}
		}
		for (int i = 0; i < allquestion.size(); i++) {
			question[i]=allquestion.get(i).getId();
		}
		int a=biz.addpaper(question, paper);
		if (a==0) {
			System.out.println("���ӳɹ�");
		}
		result="paperok";
		return "random";
	}
	
	//��������Ծ��Լ�ѡ���Ŀʱ��ת
	public String addpaper(){
		showsub();
		if (paper!=null&&paper.getSubject().getId()!=null) {
			sub=new Subject();
			sub.setId(paper.getSubject().getId());
			sub=biz.showonesub(sub);
			topicid=repeat();
		}
		pagebean=biz.qbcshowquestionbysub(p,sub);
		return "addpaper";
	}
	
	//�����Ծ��ķ���
	public String imok(){
		paper.setQnumber(topiccount);
		int a=biz.addpaper(topicid, paper);
		if (a==0) {
			System.out.println("���ӳɹ�");
		}
		return paper();
	}
	
	//��ѯ���а༶
	public String selectclasses(){
		listclasses=biz.allclass();
		return "classes";
	}
	
	
	//��ʼ����
	public String starpaper(){
		String testbgtime=DateFormat(begintime);
		paper.setTestTime(Timestamp.valueOf(testbgtime));
		int i=biz.starexam(paper, classid);
		if (i==0) {
			System.out.println("��ʼ����");
		}
		return "classes";
		
	}
	public String endpaper(){
		biz.endpaper(paper);
		paper=null;
		return paper();
	}
	
	//ת�����ڸ�ʽ
	public String DateFormat(String date) {
		 SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss" );
		 Date rdate=null;
		 String s=null;
		 try {
			rdate=sdf.parse(date);
			s=sdf.format(rdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	
	//��ʾ�Ծ�����������鿴�ɼ���
	public String showtestpaper(){	
		showsub();//֮ǰ��ʾ��Ŀ�ķ��� �ظ�����
		pagebean=biz.showtestpaper(identifer,p,paper);
		return "showtestpaper";
	}
	
	//��ʾ�Ծ��ɼ�
	public String showscore(){
		paper=biz.showonepaper(paper);
		if (score==null) {
			score=new Score();
		}
		score.setPaper(paper);
		scores=biz.showscore(score);
		zrenshu=0;
		jrenshu=0;
		jigelv=0;
		if (scores.size()>0) {
			for (Score s : scores) {
				zrenshu++;
				if (s.getScore()!=null) {
					double sc=Double.valueOf(s.getScore());
					if (sc>paper.getTotalScore()/60) {
						jrenshu++;
					} 
				}
				
			}
			if (jrenshu>0) {
				double a=jrenshu;
				double b=zrenshu;
				jigelv=a/b;
				System.out.println(jigelv);
				jigelv=jigelv*100;
			}
			
		}
		
		return "showscore";
	}
	
	//��ʾ�Ծ�����
	public String showpaperquestion(){
		paper=biz.showonepaper(paper);
		return "showpaperquestion";
	}
 	
	//��ʾѧ���ɼ�����
	public String showScoredetails(){
		score=biz.showScoredetails(score);
		
		return "showScoredetails";
	}
	
	//
	public String Cancellation() {
		HttpSession session= ServletActionContext.getRequest().getSession();
		if(session.getAttribute("users")!=null) {
			session.removeAttribute("users");
		}
		return "Cancellation";
	}
	
	
	//��Ϊset get ����
	
	
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	public Subject getSub() {
		return sub;
	}

	public void setSub(Subject sub) {
		this.sub = sub;
	}

	public List<Subject> getSubs() {
		return subs;
	}

	public void setSubs(List<Subject> subs) {
		this.subs = subs;
	}
	public List getDirs() {
		return dirs;
	}
	public void setDirs(List dirs) {
		this.dirs = dirs;
	}
	public List getStas() {
		return stas;
	}
	public void setStas(List stas) {
		this.stas = stas;
	}
	public String getDir() {
		return dir;
	}
	public void setDir(String dir) {
		this.dir = dir;
	}
	public String getSta() {
		return sta;
	}
	public void setSta(String sta) {
		this.sta = sta;
	}


	public List<Object[]> getObjs() {
		return objs;
	}


	public void setObjs(List<Object[]> objs) {
		this.objs = objs;
	}


	public List<Paper> getPapers() {
		return papers;
	}


	public void setPapers(List<Paper> papers) {
		this.papers = papers;
	}


	public PageBean getPb() {
		return pb;
	}


	public void setPb(PageBean pb) {
		this.pb = pb;
	}


	public Paper getPaper() {
		return paper;
	}


	public void setPaper(Paper paper) {
		this.paper = paper;
	}


	public List<Score> getScores() {
		return scores;
	}


	public void setScores(List<Score> scores) {
		this.scores = scores;
	}


	public Score getScore() {
		return score;
	}


	public void setScore(Score score) {
		this.score = score;
	}

	


	public int getZrenshu() {
		return zrenshu;
	}


	public void setZrenshu(int zrenshu) {
		this.zrenshu = zrenshu;
	}


	public int getJrenshu() {
		return jrenshu;
	}


	public void setJrenshu(int jrenshu) {
		this.jrenshu = jrenshu;
	}


	public double getJigelv() {
		return jigelv;
	}


	public void setJigelv(double jigelv) {
		this.jigelv = jigelv;
	}


	public PageBean getPagebean() {
		return pagebean;
	}


	public void setPagebean(PageBean pagebean) {
		this.pagebean = pagebean;
	}


	public int getP() {
		return p;
	}


	public void setP(int p) {
		this.p = p;
	}


	public String getIdentifer() {
		return identifer;
	}


	public void setIdentifer(String identifer) {
		this.identifer = identifer;
	}


	public List<Question> getListtopic() {
		return listtopic;
	}


	public void setListtopic(List<Question> listtopic) {
		this.listtopic = listtopic;
	}


	public Integer[] getTopicid() {
		return topicid;
	}


	public void setTopicid(Integer[] topicid) {
		this.topicid = topicid;
	}


	public Integer getTopiccount() {
		return topiccount;
	}


	public void setTopiccount(Integer topiccount) {
		this.topiccount = topiccount;
	}


	public List<Classes> getListclasses() {
		return listclasses;
	}


	public void setListclasses(List<Classes> listclasses) {
		this.listclasses = listclasses;
	}


	public String getBegintime() {
		return begintime;
	}


	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}



	public Set<Integer> getClassid() {
		return classid;
	}


	public void setClassid(Set<Integer> classid) {
		this.classid = classid;
	}


	public List<Question> getRadioeasy() {
		return radioeasy;
	}


	public void setRadioeasy(List<Question> radioeasy) {
		this.radioeasy = radioeasy;
	}


	public List<Question> getRadiomedium() {
		return radiomedium;
	}


	public void setRadiomedium(List<Question> radiomedium) {
		this.radiomedium = radiomedium;
	}


	public List<Question> getRadiodifficulty() {
		return radiodifficulty;
	}


	public void setRadiodifficulty(List<Question> radiodifficulty) {
		this.radiodifficulty = radiodifficulty;
	}


	public List<Question> getChoiceeasy() {
		return choiceeasy;
	}


	public void setChoiceeasy(List<Question> choiceeasy) {
		this.choiceeasy = choiceeasy;
	}


	public List<Question> getChoicemedium() {
		return choicemedium;
	}


	public void setChoicemedium(List<Question> choicemedium) {
		this.choicemedium = choicemedium;
	}


	public List<Question> getChoicedifficulty() {
		return choicedifficulty;
	}


	public void setChoicedifficulty(List<Question> choicedifficulty) {
		this.choicedifficulty = choicedifficulty;
	}


	public Integer[] getCondition() {
		return condition;
	}


	public void setCondition(Integer[] condition) {
		this.condition = condition;
	}


	public String getResult() {
		return result;
	}


	public void setResult(String result) {
		this.result = result;
	}
	
	

}
