package qhit.bean;

public class ExamTopic {
	//ѧ���𰸱�����ID
	private Integer studenaid;
	//��������
	private String content;
	//��������
	private String type;
	//Aѡ��
	private String firstA;
	//Bѡ��
	private String secondB;
	//Cѡ��
	private String thirdC;
	//Dѡ��
	private String fourthD;
	//ѧ����
	private String studentanswer;
	public Integer getStudenaid() {
		return studenaid;
	}
	public void setStudenaid(Integer studenaid) {
		this.studenaid = studenaid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getFirstA() {
		return firstA;
	}
	public void setFirstA(String firstA) {
		this.firstA = firstA;
	}
	public String getSecondB() {
		return secondB;
	}
	public void setSecondB(String secondB) {
		this.secondB = secondB;
	}
	public String getThirdC() {
		return thirdC;
	}
	public void setThirdC(String thirdC) {
		this.thirdC = thirdC;
	}
	public String getFourthD() {
		return fourthD;
	}
	public void setFourthD(String fourthD) {
		this.fourthD = fourthD;
	}
	public String getStudentanswer() {
		return studentanswer;
	}
	public void setStudentanswer(String studentanswer) {
		this.studentanswer = studentanswer;
	}

	
	
}
