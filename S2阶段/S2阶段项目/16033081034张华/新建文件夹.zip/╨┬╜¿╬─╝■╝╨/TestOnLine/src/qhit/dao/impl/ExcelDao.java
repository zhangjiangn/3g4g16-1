package qhit.dao.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import qhit.bean.Question;
import qhit.bean.Subject;
import qhit.biz.UserBiz;
import qhit.biz.impl.UserBizImpl;

import jxl.Sheet;
import jxl.Workbook;

public class ExcelDao {

     	/**
         * ��ѯָ��Ŀ¼�е��ӱ��������е�����
         * @param file �ļ�����·��
         * @return
         */
        public static List<Object[]> getAllByExcel(String file){
        	UserBiz biz=new UserBizImpl();
            List<Object[]> list=new ArrayList<Object[]>();
            try {
                Workbook rwb=Workbook.getWorkbook(new File(file));
                Sheet rs=rwb.getSheet(0);//����rwb.getSheet(0)
                int clos=rs.getColumns();//�õ����е���
                int rows=rs.getRows();//�õ����е���
                
                System.out.println("clos"+clos+" rows:"+rows);
                for (int i = 1; i < rows; i++) {
                    for (int j = 0; j < clos; j++) {
                        //��һ�����������ڶ���������
                        String a1=rs.getCell(j++, i).getContents();//Ĭ������߱��Ҳ��һ�� ���������j++  ��Ŀ��
                        String a2=rs.getCell(j++, i).getContents();//��˫ѡ
                        String a3=rs.getCell(j++, i).getContents();//��Ŀ����
                        String a4=rs.getCell(j++, i).getContents();//ѡ��A
                        String a5=rs.getCell(j++, i).getContents();//ѡ��B
                        String a6=rs.getCell(j++, i).getContents();//ѡ��C
                        String a7=rs.getCell(j++, i).getContents();//ѡ��D
                        String a8=rs.getCell(j++, i).getContents();//��ȷ��
                        String a9=rs.getCell(j++, i).getContents();//�Ѷ�
                        String a10=rs.getCell(j++, i).getContents();//�½�
                        Question question=new Question();
                        Subject subject=new Subject();
                        subject.setSubjectname(a1);
                        subject=biz.getsubbyname(subject);
                        question.setSubject(subject);
                        question.setChoose(a2);
                        question.setContent(a3);
                        question.setOptionA(a4);
                        question.setOptionB(a5);
                        question.setOptionC(a6);
                        question.setOptionD(a7);
                        question.setAnswer(a8);
                        question.setDifficulty(a9);
                        question.setChapter(a10);
                        biz.addquestion(question);
                    }
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
            return list;
            
        }
    }
