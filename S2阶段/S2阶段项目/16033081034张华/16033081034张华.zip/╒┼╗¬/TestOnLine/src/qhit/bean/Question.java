package qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Question entity. @author MyEclipse Persistence Tools
 */

public class Question implements java.io.Serializable {
	
	// Fields ����

	private Integer id;//���
	private Subject subject;//��Ŀ
	private String kind;//���
	private String choose;//��˫ѡ
	private String content;//����
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String answer;//
	private String difficulty;//���׶�
	private String chapter;//�½�
	private Set scoredetailses = new HashSet(0); //������
	private Set papers = new HashSet(0); //�Ծ�

	// Constructors

	/** default constructor */
	public Question() {
	}

	

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getKind() {
		return this.kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getOptionA() {
		return this.optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return this.optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return this.optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getOptionD() {
		return this.optionD;
	}

	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getDifficulty() {
		return this.difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getChapter() {
		return this.chapter;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public Set getScoredetailses() {
		return this.scoredetailses;
	}

	public void setScoredetailses(Set scoredetailses) {
		this.scoredetailses = scoredetailses;
	}



	public Set getPapers() {
		return papers;
	}



	public void setPapers(Set papers) {
		this.papers = papers;
	}



	public String getChoose() {
		return choose;
	}



	public void setChoose(String choose) {
		this.choose = choose;
	}
	
	

}