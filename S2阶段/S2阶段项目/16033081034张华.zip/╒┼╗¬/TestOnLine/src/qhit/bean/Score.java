package qhit.bean;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Score entity. @author MyEclipse Persistence Tools
 */

public class Score implements java.io.Serializable {

	// Fields

	private Integer id;
	private Student student;
	private Paper paper;
	private String score;
	private Timestamp beginTime;
	private Timestamp endTime;
	private Double surplustime;//�������Ծ���ʣʱ��
	private Integer submit;//�Ƿ��Ѿ����� 0��Ϊδ������1���ѽ���
	private Set scoredetailses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Score() {
	}

	
	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Paper getPaper() {
		return this.paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	


	public Timestamp getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(Timestamp beginTime) {
		this.beginTime = beginTime;
	}

	public Timestamp getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}


	public Set getScoredetailses() {
		return this.scoredetailses;
	}

	public void setScoredetailses(Set scoredetailses) {
		this.scoredetailses = scoredetailses;
	}


	public String getScore() {
		return score;
	}


	public void setScore(String score) {
		this.score = score;
	}


	public Double getSurplustime() {
		return surplustime;
	}


	public void setSurplustime(Double surplustime) {
		this.surplustime = surplustime;
	}


	public Integer getSubmit() {
		return submit;
	}


	public void setSubmit(Integer submit) {
		this.submit = submit;
	}
	
}