package com.qhit.biz.interfaces;

public interface BizInterface {
	
	/**
	 * @author ���ղ�
	 * ��¼��֤
	 * */
	public <T>Object Login(Object obj);

}
