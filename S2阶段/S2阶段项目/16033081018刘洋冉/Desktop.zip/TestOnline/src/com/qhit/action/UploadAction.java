package com.qhit.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;

import com.qhit.dao.implents.ExcelDao;




public class UploadAction {
	private String name;
	private File upload;//���ļ��ϴ��ؼ�����ͬ������˽����ϴ��ļ����ݵ���ʱ�ļ�
	private String uploadFileName;//�ļ��ϴ��ؼ���+Name�����ϴ��ļ����ļ���
	private String uploadContentType;//�ļ��ϴ��ؼ���+Type�����ϴ��ļ���MIME����
	
	private String downfile_name;
	private InputStream downfile_is;
	
	public String upload(){
		if(upload!=null){
			try {
				InputStream is=new FileInputStream(upload);
				String filepath=ServletActionContext.getServletContext().getRealPath("/")
					+"upfile/"+uploadFileName;
				OutputStream os=new FileOutputStream(filepath);
				byte[] buffer=new byte[8096];
				int len=0;
				while ((len=is.read(buffer))!=-1) {
					os.write(buffer, 0, len);
				}
				ExcelDao ed=new ExcelDao();
				//�õ�excel��������
				List list=ed.getAllByExcel(filepath);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return "upload";
	}
	public String download(){

		return "download";
		
	}
	public InputStream getInputStream(){
		String filepath=ServletActionContext.getServletContext().getRealPath("/dowlad/Topic.xls");
		System.out.println(filepath);
	try {
		downfile_is=new FileInputStream(filepath);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return downfile_is; 
		//ServletActionContext.getServletContext().getResourceAsStream("dowlad/Topic.xls");
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public File getUpload() {
		return upload;
	}

	public void setUpload(File upload) {
		this.upload = upload;
	}

	

	public String getUploadFileName() {
		return uploadFileName;
	}

	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	public String getUploadContentType() {
		return uploadContentType;
	}

	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}


	public String getDownfile_name() {
		return downfile_name;
	}


	public void setDownfile_name(String downfileName) {
		downfile_name = downfileName;
	}


	public InputStream getDownfile_is() {
		return downfile_is;
	}


	public void setDownfile_is(InputStream downfileIs) {
		downfile_is = downfileIs;
	}
	

		
	
	


}
