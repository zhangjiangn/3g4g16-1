package com.qhit.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class ThreadB extends Thread{
	private Session session;
	public ThreadB (Session session) {
		this.session=session;
	}
	public void run() {
		session.beginTransaction();
		Query query=session.createQuery("from Topic");
		List list=query.list();
		session.beginTransaction().commit();
		System.out.println("ThreadB"+list.size());
	}
}
