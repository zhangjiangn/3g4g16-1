package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Stage entity. @author MyEclipse Persistence Tools
 */

public class Stage implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Direction direction;
	private String sname;
	private Set subjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public Stage() {
	}

	/** minimal constructor */
	public Stage(Integer sid) {
		this.sid = sid;
	}

	/** full constructor */
	public Stage(Integer sid, Direction direction, String sname, Set subjects) {
		this.sid = sid;
		this.direction = direction;
		this.sname = sname;
		this.subjects = subjects;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Set getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Set subjects) {
		this.subjects = subjects;
	}

}