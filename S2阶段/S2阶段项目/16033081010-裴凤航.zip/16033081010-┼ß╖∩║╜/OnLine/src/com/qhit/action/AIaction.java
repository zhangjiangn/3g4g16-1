package com.qhit.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.xml.registry.infomodel.User;

import net.sf.json.JSONArray;

import org.apache.struts2.ServletActionContext;
import org.jgroups.tests.perf.Test;

import com.opensymphony.xwork2.ActionContext;
import com.qhit.bean.Admin;
import com.qhit.bean.Classroom;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.StudentAnswer;
import com.qhit.bean.Studentscore;
import com.qhit.bean.Subject;
import com.qhit.bean.TestPaper;
import com.qhit.bean.Title;
import com.qhit.bean.Users;
import com.qhit.biz.PageBean;

import com.qhit.biz.UserDaoBiz;

import com.qhit.biz.impl.UserDaoBizImpl;
import com.sun.org.apache.regexp.internal.RE;

public class AIaction {
	private int p=0;
	private PageBean pb;
	private UserDaoBiz userdao = new UserDaoBizImpl();
	private Admin a;
	private Student stu;
	private Users u;
	private List<Direction> dirlist;
	private List<Stage> stlist;
	private List<Subject> sublist;
	private List<Title> tlist;
	private List<Object[]> obj;
	private Title t;
	private Direction dir;
	private Stage s;
	private Subject j;
	private TestPaper tp;
	private Set<Title> tset;
	private List<TestPaper> tplist;
	private List<Classroom> croom;
	private Classroom csm;
	private Integer titleid;
	private Integer nubmer=1;
	private List<StudentAnswer> studentanswerlist;
	private StudentAnswer studentanswer;
	private List<Studentscore> sslist;
	private Studentscore score;
	private String result;
	private Integer [] condition;
	private Integer[] Restrict ;
	//�û���½
	public String login() {
		if(userdao.login(u)==null){
			return "aaa";
		}else {
			Map<String, Object> session = ActionContext.getContext().getSession();
			session.put("u", u);
			return "login";
		}	
	}

	public String TmBiz() {
		dirlist=userdao.Get("from Direction", null);
		if(dir!=null){
			stlist=userdao.Get("from Stage s where s.direction.dname=?", new Object []{dir.getDname()});
			if(dir!=null&&s!=null&&s.getSname()!="��ѡ��..."){
				sublist=userdao.Get("from Subject j where j.stage.sname=? and j.stage.direction.dname=?", new Object []{s.getSname(),dir.getDname()});
			}
		}
		
		return "tmbiz";
	}
	//��ҳ
	public String TmByname() {
		//System.out.println(j.getJname()+"222222");
		String hql="from Title t where t.subject.jid=?";
		sublist=userdao.Get(hql, new Object []{j.getJid()});
		System.out.println(sublist.size()+"0000");
		pb=new PageBean();
		pb.setCount(sublist.size());
		pb.setPagesize(4);
		pb.setP(p);
		pb=userdao.selectfenye(hql, new Object[]{j.getJid()}, pb);
		return "tmbyname";
	}

	public String addTitle() {
		//System.out.println(j.getJid()+"000000000000");
		Subject subject=null;
		if(j.getJid()!=null||j.getJid()!=0){
			 subject=(Subject) userdao.Get("from Subject j where j.jid=?", new Object []{j.getJid()}).get(0);
		}		
		t.setSubject(subject);
		int i = userdao.addTi(t);
		if (i == 0) {
			return TmByname();
		} else {
			return "addshiban";
		}

	}

	

	public String Testpaper() {
		String hql="from  TestPaper";
		dirlist=userdao.Get("from Direction", null);
		if(dir!=null){
			stlist=userdao.Get("from Stage s where s.direction.dname=?", new Object []{dir.getDname()});
			if(dir!=null&&s!=null&&s.getSname()!="��ѡ��..."){
				sublist=userdao.Get("from Subject j where j.stage.sname=? and j.stage.direction.dname=?", new Object []{s.getSname(),dir.getDname()});
				if(dir!=null&&s!=null&&j!=null&&s.getSname()!="��ѡ��..."&&j.getJname()!="��ѡ��..."){
					tplist=userdao.Get("from TestPaper t where t.subject.jname=? and t.subject.stage.sname=? and t.subject.stage.direction.dname=?", new Object[]{j.getJname(),s.getSname(),dir.getDname()});
					String hql1="from TestPaper t where t.subject.jname=? and t.subject.stage.sname=? and t.subject.stage.direction.dname=?";
					pb=new PageBean();
					pb.setCount(tplist.size());
					pb.setPagesize(4);
					pb.setP(p);
					pb=userdao.selectfenye(hql1,  new Object[]{j.getJname(),s.getSname(),dir.getDname()}, pb);
				}
			}
		}else {			
			tplist=userdao.Get("from  TestPaper ", null);
			pb=new PageBean();
			pb.setCount(tplist.size());
			pb.setPagesize(4);
			pb.setP(p);
			pb=userdao.selectfenye(hql, null, pb);
		}
		
		return "paper";
	}

	public String choose() {		
		dirlist=userdao.Get("from Direction", null);
		if(dir!=null){
			stlist=userdao.Get("from Stage s where s.direction.dname=?", new Object []{dir.getDname()});
			if(dir!=null&&s!=null&&s.getSname()!="��ѡ��..."){
				sublist=userdao.Get("from Subject j where j.stage.sname=? and j.stage.direction.dname=?", new Object []{s.getSname(),dir.getDname()});
				if(dir!=null&&s!=null&&j!=null&&s.getSname()!="��ѡ��..."&&j.getJname()!="��ѡ��..."){
					tlist=userdao.Get("from Title t where t.subject.jname=? and t.subject.stage.sname=? and t.subject.stage.direction.dname=?", new Object[]{j.getJname(),s.getSname(),dir.getDname()});
				}
			}
		
		}
		return "choose";
	}
	
	public String random() {
	
		dirlist=userdao.Get("from Direction", null);
		if(dir!=null){
			stlist=userdao.Get("from Stage s where s.direction.dname=?", new Object []{dir.getDname()});
			if(dir!=null&&s!=null&&s.getSname()!="��ѡ��..."){
				sublist=userdao.Get("from Subject j where j.stage.sname=? and j.stage.direction.dname=?", new Object []{s.getSname(),dir.getDname()});
				if(dir!=null&&s!=null&&j!=null&&s.getSname()!="��ѡ��..."&&j.getJname()!="��ѡ��..."){
					tlist=userdao.Get("from Title t where t.subject.jname=? and t.subject.stage.sname=? and t.subject.stage.direction.dname=?", new Object[]{j.getJname(),s.getSname(),dir.getDname()});
					int danjian=0;
					int duojian=0;
					int danyiban=0;
					int duoyiban=0;
					int dank=0;
					int duok=0;		
					for (int i = 0; i < tlist.size(); i++) {
						if(tlist.get(i).getDanxuan().equals("��ѡ")&&tlist.get(i).getNandu().equals("��")){					
							danjian++;
						}else if (tlist.get(i).getDanxuan().equals("��ѡ")&&tlist.get(i).getNandu().equals("һ��")) {
							danyiban++;
						}else if (tlist.get(i).getDanxuan().equals("��ѡ")&&tlist.get(i).getNandu().equals("����")) {
							dank++;
						}else if (tlist.get(i).getDanxuan().equals("��ѡ")&&tlist.get(i).getNandu().equals("��")) {
							duojian++;
						}else if (tlist.get(i).getDanxuan().equals("��ѡ")&&tlist.get(i).getNandu().equals("һ��")) {
							duoyiban++;
						}else if (tlist.get(i).getDanxuan().equals("��ѡ")&&tlist.get(i).getNandu().equals("����")) {
							duok++;
						}
					}
					Restrict=new Integer[6];
					Restrict[0]=danjian;
					Restrict[1]=danyiban;
					Restrict[2]=dank;
					Restrict[3]=duojian;
					Restrict[4]=duoyiban;
					Restrict[5]=duok;
				}
		
		}
			
		}
		return "random";
	}
	//���
	public String randomAdd(){
		tlist=userdao.Get("from Title t where t.subject.jname=? and t.subject.stage.sname=? and t.subject.stage.direction.dname=?", new Object[]{j.getJname(),s.getSname(),dir.getDname()});
		System.out.println(tlist.get(0).getA());		
		List<Title> listtopic=new ArrayList<Title>();
		List list=new ArrayList();
		String hql="";
		list.add("where danxuan='��ѡ' and nandu='��' order by newid()");
		list.add("where danxuan='��ѡ' and nandu='һ��' order by newid()");
		list.add("where danxuan='��ѡ' and nandu='����' order by newid()");
		list.add("where danxuan='��ѡ' and nandu='��' order by newid()");
		list.add("where danxuan='��ѡ' and nandu='һ��' order by newid()");
		list.add("where danxuan='��ѡ' and nandu='����' order by newid()");
		//������ѯ
		for (int i = 0; i < condition.length; i++) {
			if(condition[i]!=null) {
				hql=" from Title "+list.get(i);
				List select=userdao.Select(hql, null,condition[i]);
				for (Object object : select) {
					listtopic.add((Title) object);
				}
			}
		}
		j=(Subject) userdao.Get("from Subject j where j.stage.sname=? and j.stage.direction.dname=? and j.jname=?", new Object []{s.getSname(),dir.getDname(),j.getJname()}).get(0);
		TestPaper tpp=new TestPaper();
		tpp.setTpname(tp.getTpname());
		tpp.setTestTime(tp.getTestTime());		
		tpp.setState("δ����");
		tpp.setAvg(tp.getAvg());
		tpp.setTishu(tp.getTishu());
		tpp.setSubject(j);
		tpp.setTitle(new HashSet(listtopic));
		int i =userdao.addTi(tpp);
		
		return "random";
		}
	
		
	
	
	public String getTByid() {
		List<Title> tt = new ArrayList<Title>();
		for (int i = 0; i < tlist.size(); i++) {
			Title t = (Title) userdao.Get("from Title t where t.tid=?", new Object []{tlist.get(i).getTid()}).get(0);
			tt.add(t);
		}
		TestPaper tpp = new TestPaper();
		Subject subject=null;
		subject=(Subject) userdao.Get("from Subject j where j.stage.sname=? and j.stage.direction.dname=? and j.jname=?", new Object []{s.getSname(),dir.getDname(),j.getJname()}).get(0);
		System.out.println(subject.getJname());
		tpp.setTpname(tp.getTpname());
		tpp.setTestTime(tp.getTestTime());
		tpp.setAvg(tp.getAvg());
		tpp.setTishu(tp.getTishu());
		tpp.setState("δ����");
		tpp.setSubject(subject);
		tpp.setTitle(new HashSet(tt));
		int i =userdao.addTi(tpp);
		if (i == 0) {
			System.out.println("cg");
			return "getTByid";
		} else {
			return "getTByid";
		}

	}
	public String starTest(){
		Set<Classroom> cmset=new HashSet<Classroom>();
		TestPaper t=(TestPaper)userdao.Get("from TestPaper t where t.tpid=?", new Object []{tp.getTpid()}).get(0);
		Classroom cr=(Classroom) userdao.Get("from Classroom c where c.cid=?", new Object []{csm.getCid()}).get(0);;
		cmset.add(cr);
		t.setState("������");
		t.setStartime(tp.getStartime());
		t.setClassroom(cmset);
		int i=userdao.addTi(t);
		if (i == 0) {
			System.out.println("cg");
			return Testpaper();
		} else {
			return "room";
		}
		
	}
	public String chakan() {
		
		return "chakan";
	}
	public String room(){
		System.out.println(tp.getTpid()+"tttppp");
		croom=userdao.Get("from Classroom", null);
		return "room";
	}
	public String jieshu(){
		tp=(TestPaper) userdao.Get("from TestPaper tp where tp.tpid=?", new Object[]{tp.getTpid()}).get(0);
		tp.setState("���Խ���");
		int i=userdao.addTi(tp);
		if(i==0){
			System.out.println("cg");
		}
		return Testpaper();
	}
	
	public String studentTestPaper(){
		Map<String, Object> map=ActionContext.getContext().getSession();
		//session�д�ŵ��и��û�
		if(map.containsKey("u")) {
			u=(Users)map.get("u");
		}
		Student student=(Student) userdao.Get("from Student s where s.saccount=?", new Object[]{u.getName()}).get(0);
		tplist=new ArrayList(student.getClassroom().getTestpaper());
		croom=new ArrayList(student.getClassroom().getTestpaper());
		return "studentTestPaper";
	}
	public String studentbegintest(){
		Users u=null;
		//�õ�ѧ��ID
		Map<String, Object> map=ActionContext.getContext().getSession();
		//session�д�ŵ��и��û�
		if(map.containsKey("u")) {
			u=(Users)map.get("u");
		}
		Student student=(Student) userdao.Get("from Student s where s.saccount=?", new Object[]{u.getName()}).get(0);
		tp=(TestPaper) userdao.Get("from TestPaper tp where tp.tpid=?", new Object []{tp.getTpid()}).get(0);
		String hql="from StudentAnswer sa where sa.student.sid=? and sa.testPaper.tpid=?";
		List<StudentAnswer> listanswer=userdao.Get(hql, new Object[]{student.getSid(),tp.getTpid()});
		if(listanswer!=null&&listanswer.size()>0){
			studentanswerlist=listanswer;
			if(titleid==null||titleid==0){
				if(nubmer>=listanswer.size()+1){
					nubmer=listanswer.size()+1;
					t=(Title) userdao.Get("from Title t where t.tid=?", new Object[]{listanswer.get(nubmer-2).getTitle().getTid()}).get(0);	
					}else {
						t=(Title) userdao.Get("from Title t where t.tid=?", new Object[]{listanswer.get(nubmer-1).getTitle().getTid()}).get(0);	
	
					}
				if(studentanswer!=null){
						Title title;
						
							 title=(Title) userdao.Get("from Title t where t.tid=?", new Object[]{listanswer.get(nubmer-2).getTitle().getTid()}).get(0);	
						
						String hqll="from StudentAnswer sa where sa.student.sid=? and sa.testPaper.tpid=? and sa.title.tid=?";
						StudentAnswer sanswer=(StudentAnswer) userdao.Get(hqll, new Object[]{student.getSid(),tp.getTpid(),title.getTid()}).get(0);
						sanswer.setStuanswer(studentanswer.getStuanswer());
						userdao.addTi(sanswer);
					}
					
			}else {
				t=(Title) userdao.Get("from Title t where t.tid=?", new Object[]{titleid}).get(0);
			}
			
		}
		else {		
		Student stu=(Student) userdao.Get("from Student s where s.saccount=?", new Object []{u.getName()}).get(0);
		tp=(TestPaper) userdao.Get("from TestPaper tp where tp.tpid=?", new Object []{tp.getTpid()}).get(0);
		tlist=new ArrayList(tp.getTitle());		
		Collections.shuffle(tlist);
		studentanswerlist=new ArrayList<StudentAnswer>();
		for (Title title : tlist) {
			StudentAnswer studentanswer=new StudentAnswer();
			studentanswer.setStudent(stu);
			studentanswer.setTestPaper(tp);
			studentanswer.setTitle(title);
			int i=userdao.addTi(studentanswer);
			if(i==0){
				studentanswerlist.add(studentanswer);
			}			
		}
		t=(Title) userdao.Get("from Title t where t.tid=?", new Object[]{studentanswerlist.get(0).getTitle().getTid()}).get(0);
		}
		return "studentbegintest";
	}
	public String testOver(){
		Users u=null;
		//�õ�ѧ��ID
		Map<String, Object> map=ActionContext.getContext().getSession();
		//session�д�ŵ��и��û�
		if(map.containsKey("u")) {
			u=(Users)map.get("u");
		}
		stu=(Student) userdao.Get("from Student s where s.saccount=?", new Object[]{u.getName()}).get(0);
		String hql="from StudentAnswer sa where sa.student.sid=? and sa.testPaper.tpid=?";
		studentanswerlist=userdao.Get(hql, new Object[]{stu.getSid(),tp.getTpid()});
		tp=(TestPaper) userdao.Get("from TestPaper tp where tp.tpid=?", new Object[]{tp.getTpid()}).get(0);
		tlist=new ArrayList(tp.getTitle());
		int rellycount=1;
		int sumfen=0;
		for (int i = 0; i < studentanswerlist.size(); i++) {
			if(studentanswerlist.get(i).getStuanswer().equals(tlist.get(i).getAnswer())){
				System.out.println(studentanswerlist.get(i).getStuanswer());
				System.out.println(tlist.get(i).getAnswer());
				sumfen=rellycount*tp.getAvg();
				rellycount++;
			}			
		}
		Studentscore score=new Studentscore();
		score.setStudent(stu);
		score.setTestPaper(tp);
		score.setSum(sumfen);
		int i=userdao.addTi(score);
		if(i==0){
			System.out.println("cg");
		}
		return studentTestPaper();
		
	}
	
	//�ɼ�����ģ��
	public String scoreG(){
//		List<Studentscore> sslist=userdao.Get("from Studentscore", null);
//		int ii=sslist.size();
//		Integer [] obj=new Integer[ii];
//		for (int i = 0; i < sslist.size(); i++) {
//			obj[i]=sslist.get(i).getTestPaper().getTpid();
//		}
//		System.out.println(obj[0]+"kkkk");
		dirlist=userdao.Get("from Direction", null);
		if(dir!=null){
			stlist=userdao.Get("from Stage s where s.direction.dname=?", new Object []{dir.getDname()});
			if(dir!=null&&s!=null&&s.getSname()!="��ѡ��..."){
				sublist=userdao.Get("from Subject j where j.stage.sname=? and j.stage.direction.dname=?", new Object []{s.getSname(),dir.getDname()});
				if(dir!=null&&s!=null&&j!=null&&!s.getSname().equals("��ѡ��...")&&!j.getJname().equals("��ѡ��...")){					
					tplist=userdao.Get("from TestPaper t where t.state<>'δ����' and t.subject.jname=? and t.subject.stage.sname=? and t.subject.stage.direction.dname=?", new Object[]{j.getJname(),s.getSname(),dir.getDname()});
					String hql1="from TestPaper t where t.state<>'δ����' and t.subject.jname=? and t.subject.stage.sname=? and t.subject.stage.direction.dname=?";
					pb=new PageBean();
					pb.setCount(tplist.size());
					pb.setPagesize(4);
					pb.setP(p);
					pb=userdao.selectfenye(hql1, new Object[]{j.getJname(),s.getSname(),dir.getDname()}, pb);					
				}
			}
		
		}else {
			tplist=userdao.Get("from TestPaper t where t.state<>'δ����'", null);
			pb=new PageBean();
			pb.setCount(tplist.size());
			pb.setPagesize(4);
			pb.setP(p);
			pb=userdao.selectfenye("from TestPaper t where t.state<>'δ����'",null, pb);
		}
		return "scoreG";
	}
	public String ckscore(){
			String hql="from Studentscore ss where ss.testPaper.tpid=?";
			sslist=userdao.Get(hql,new Object[]{tp.getTpid()});
		return "ckscore";
	}
	public String Infoscore(){
		Users u=null;
		//�õ�ѧ��ID
		Map<String, Object> map=ActionContext.getContext().getSession();
		//session�д�ŵ��и��û�
		if(map.containsKey("u")) {
			u=(Users)map.get("u");
		}
		Student student=(Student) userdao.Get("from Student s where s.saccount=?", new Object[]{u.getName()}).get(0);
		tp=(TestPaper)userdao.Get("from TestPaper tp where tp.tpid=?", new Object[]{tp.getTpid()}).get(0);
		studentanswerlist=userdao.Get("from StudentAnswer sa where sa.student.sid=? and sa.testPaper.tpid=?", new Object[]{student.getSid(),tp.getTpid()});
		score=(Studentscore) userdao.Get("from Studentscore sss where sss.student.sid=? and sss.testPaper.tpid=?", new Object[]{student.getSid(),tp.getTpid()}).get(0);
		tlist=new ArrayList(tp.getTitle());		
		return "Scoredetails";
	}
	public Admin getA() {
		return a;
	}

	public void setA(Admin a) {
		this.a = a;
	}

	public Users getU() {
		return u;
	}

	public void setU(Users u) {
		this.u = u;
	}

	public List<Direction> getDirlist() {
		return dirlist;
	}

	public void setDirlist(List<Direction> dirlist) {
		this.dirlist = dirlist;
	}

	public List<Stage> getStlist() {
		return stlist;
	}

	public void setStlist(List<Stage> stlist) {
		this.stlist = stlist;
	}

	public List<Subject> getSublist() {
		return sublist;
	}

	public void setSublist(List<Subject> sublist) {
		this.sublist = sublist;
	}

	public List<Title> getTlist() {
		return tlist;
	}

	public void setTlist(List<Title> tlist) {
		this.tlist = tlist;
	}

	public Title getT() {
		return t;
	}

	public void setT(Title t) {
		this.t = t;
	}

	public Stage getS() {
		return s;
	}

	public void setS(Stage s) {
		this.s = s;
	}

	public List<Object[]> getObj() {
		return obj;
	}

	public void setObj(List<Object[]> obj) {
		this.obj = obj;
	}

	public Subject getJ() {
		return j;
	}

	public void setJ(Subject j) {
		this.j = j;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public PageBean getPb() {
		return pb;
	}

	public void setPb(PageBean pb) {
		this.pb = pb;
	}

	public Direction getDir() {
		return dir;
	}

	public void setDir(Direction dir) {
		this.dir = dir;
	}

	public TestPaper getTp() {
		return tp;
	}

	public void setTp(TestPaper tp) {
		this.tp = tp;
	}

	public Set<Title> getTset() {
		return tset;
	}

	public void setTset(Set<Title> tset) {
		this.tset = tset;
	}

	public List<Classroom> getCroom() {
		return croom;
	}

	public void setCroom(List<Classroom> croom) {
		this.croom = croom;
	}

	public Classroom getCsm() {
		return csm;
	}

	public void setCsm(Classroom csm) {
		this.csm = csm;
	}

	public List<TestPaper> getTplist() {
		return tplist;
	}

	public void setTplist(List<TestPaper> tplist) {
		this.tplist = tplist;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}

	public Integer getTitleid() {
		return titleid;
	}

	public void setTitleid(Integer titleid) {
		this.titleid = titleid;
	}

	public List<StudentAnswer> getStudentanswerlist() {
		return studentanswerlist;
	}

	public void setStudentanswerlist(List<StudentAnswer> studentanswerlist) {
		this.studentanswerlist = studentanswerlist;
	}

	public Integer getNubmer() {
		return nubmer;
	}

	public void setNubmer(Integer nubmer) {
		this.nubmer = nubmer;
	}

	public StudentAnswer getStudentanswer() {
		return studentanswer;
	}

	public void setStudentanswer(StudentAnswer studentanswer) {
		this.studentanswer = studentanswer;
	}

	public List<Studentscore> getSslist() {
		return sslist;
	}

	public void setSslist(List<Studentscore> sslist) {
		this.sslist = sslist;
	}

	public Studentscore getScore() {
		return score;
	}

	public void setScore(Studentscore score) {
		this.score = score;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Integer[] getCondition() {
		return condition;
	}

	public void setCondition(Integer[] condition) {
		this.condition = condition;
	}

	public Integer[] getRestrict() {
		return Restrict;
	}

	public void setRestrict(Integer[] restrict) {
		Restrict = restrict;
	}

}
