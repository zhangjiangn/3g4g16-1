package com.qhit.biz;

import java.util.List;

import com.qhit.bean.Admin;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.bean.Teacher;
import com.qhit.bean.TestPaper;
import com.qhit.bean.Title;
import com.qhit.bean.Users;

public interface UserDaoBiz {
	public Object login(Object object);
	
	public List Get(String hql,Object [] object);
	public PageBean selectfenye(String hql ,Object [] object,PageBean p);
	public int addTi(Object object);
	public  List Select(String hql, Object[] object,Integer maxresult);
	
}
