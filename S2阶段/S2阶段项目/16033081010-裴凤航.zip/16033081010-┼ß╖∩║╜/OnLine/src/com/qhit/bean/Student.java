package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private Integer sid;
	private String saccount;
	private String spwd;
	private Classroom classroom;
	private Set studentanswer=new HashSet();
	private Set studentscore=new HashSet();
	
	// Constructors

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(Integer sid) {
		this.sid = sid;
	}

	/** full constructor */
	

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	
	public Student(Integer sid, String saccount, String spwd,
			Classroom classroom, Set studentanswer, Set studentscore) {
		super();
		this.sid = sid;
		this.saccount = saccount;
		this.spwd = spwd;
		this.classroom = classroom;
		this.studentanswer = studentanswer;
		this.studentscore = studentscore;
	}

	public Set getStudentscore() {
		return studentscore;
	}

	public void setStudentscore(Set studentscore) {
		this.studentscore = studentscore;
	}

	public Set getStudentanswer() {
		return studentanswer;
	}

	public void setStudentanswer(Set studentanswer) {
		this.studentanswer = studentanswer;
	}

	public Classroom getClassroom() {
		return classroom;
	}

	public void setClassroom(Classroom classroom) {
		this.classroom = classroom;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSaccount() {
		return this.saccount;
	}

	public void setSaccount(String saccount) {
		this.saccount = saccount;
	}

	public String getSpwd() {
		return this.spwd;
	}

	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}

}