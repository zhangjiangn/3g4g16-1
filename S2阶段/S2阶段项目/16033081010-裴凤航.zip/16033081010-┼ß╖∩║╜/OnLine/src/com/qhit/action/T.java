package com.qhit.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.hibernate.Session;

import com.qhit.bean.TestPaper;
import com.qhit.bean.Title;
import com.qhit.dao.HibernateSessionFactory;

public class T {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Integer> list=new ArrayList<Integer>();
		list.add(1);
		list.add(12);
		list.add(48);
		list.add(98);
		list.add(5);		
		List<Integer> list1=new ArrayList<Integer>();
		int b=0;
		int a=0;
		int c=3;
		for (int i = 0; i < c; i++) {
			 a=(int) (Math.random()*list.size());
			if(b!=a){				
				list1.add(list.get(a));	
				System.out.println(list.get(a));
				b=a;
			
			}
					
		}
		
	}

}
