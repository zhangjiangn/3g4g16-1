package com.qhit.dao.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.rmi.CORBA.Tie;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;

import com.qhit.bean.Admin;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.bean.Teacher;
import com.qhit.bean.TestPaper;
import com.qhit.bean.Title;
import com.qhit.bean.Users;
import com.qhit.biz.PageBean;
import com.qhit.dao.UserDao;

public class UserDaoImpl implements UserDao{

	public List Get(String hql, Object[] object) {
		Query query=session.createQuery(hql);
		if(object!=null){
		for (int i = 0; i < object.length; i++) {
			query.setParameter(i, object[i]);
		}
		}
		return query.list();
	}

	public PageBean selectfenye(String hql,Object [] object,PageBean p) {
		Query query=session.createQuery(hql);
		if(object!=null){
			for (int i = 0; i < object.length; i++) {
				query.setParameter(i, object[i]);
			}
			}
		p.setData(query.setFirstResult((p.getP()-1)*4).setMaxResults(p.getPagesize()).list());
		return p;
	}
	
	public int addTi(Object object){
		int i=0;
		try {
			session.beginTransaction();			
			session.save(object);
			session.beginTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			i=1;
		}		
		return i;
	}
	public  List Select(String hql, Object[] object,Integer maxresult) {
		//ʵ����һ��List���ڷ���ֵ
		List list=new ArrayList();
		
	
		//�õ�Query����
		Query query=session.createQuery(hql);
		//���object���鲻Ϊ�� ��֤��Ϊ������ѯ �㽫object�����е�ֵһ�θ���ռλ��
		if(object!=null){
			for (int i = 0; i < object.length; i++) {
				query.setParameter(i, object[i]);
			}
		}
		query.setMaxResults(maxresult);
		
		Transaction transaction = session.beginTransaction();
		try {
			list=query.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			
		}
	
		return list;
	}
}
