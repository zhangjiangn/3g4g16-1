package com.qhit.dao.implents;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.qhit.biz.implents.BizImplents;
import com.qhit.model.Answer;
import com.qhit.model.Subject;
import com.qhit.model.Topic;


import jxl.Sheet;
import jxl.Workbook;

public class ExcelDao {

     	/**
         * ��ѯָ��Ŀ¼�е��ӱ��������е�����
         * @param file �ļ�����·��
         * @return
         */
        public static List<Object[]> getAllByExcel(String file){
        	BizImplents bizimplents=new BizImplents();
            List<Object[]> list=new ArrayList<Object[]>();
            try {
                Workbook rwb=Workbook.getWorkbook(new File(file));
                Sheet rs=rwb.getSheet(0);//����rwb.getSheet(0)
                int clos=rs.getColumns();//�õ����е���
                int rows=rs.getRows();//�õ����е���
                
                System.out.println("clos"+clos+" rows:"+rows);
                for (int i = 1; i < rows; i++) {
                    for (int j = 0; j < clos; j++) {
                        //��һ�����������ڶ���������
                        String a1=rs.getCell(j++, i).getContents();//Ĭ������߱��Ҳ��һ�� ���������j++  content
                        String a2=rs.getCell(j++, i).getContents();//A
                        String a3=rs.getCell(j++, i).getContents();//B
                        String a4=rs.getCell(j++, i).getContents();//C
                        String a5=rs.getCell(j++, i).getContents();//D
                        String a6=rs.getCell(j++, i).getContents();//answer
                        String a7=rs.getCell(j++, i).getContents();//sub
                        String a8=rs.getCell(j++, i).getContents();//level
                        String a9=rs.getCell(j++, i).getContents();//type
                        
                        Topic topic=new Topic();
                        Subject subject=(Subject)bizimplents.Select("from Subject where subname=?", new Object[] {a7}).get(0);
                        topic.setSubject(subject);
                        topic.setContent(a1);
                        Answer a=new Answer();
                        a.setA(a2);
                        a.setB(a3);
                        a.setC(a4);
                        a.setD(a5);
                        a.setRightanswer(a6);
                        topic.setAnswer(a);
                        topic.setLevel(a8);
                        topic.setTtype(a9);
                        bizimplents.Add(topic);
                    }
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
            return list;
            
        }
    }
