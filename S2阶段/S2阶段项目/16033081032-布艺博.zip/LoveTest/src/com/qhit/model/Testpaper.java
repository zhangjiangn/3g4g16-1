package com.qhit.model;

import java.util.Date;
import java.util.Set;

public class Testpaper {
	private Integer pid;
	private Subject subject;
	private String ptype;
	private String ptitle;
	private Integer ptime;
	private String tbegintime;
	private String tendtime;
	private Double score;
	private Integer state;
	private Set<Testpaper_Topic> settopic;
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	public String getPtitle() {
		return ptitle;
	}
	public void setPtitle(String ptitle) {
		this.ptitle = ptitle;
	}
	public Integer getPtime() {
		return ptime;
	}
	public void setPtime(Integer ptime) {
		this.ptime = ptime;
	}

	public String getTbegintime() {
		return tbegintime;
	}
	public void setTbegintime(String tbegintime) {
		this.tbegintime = tbegintime;
	}
	public String getTendtime() {
		return tendtime;
	}
	public void setTendtime(String tendtime) {
		this.tendtime = tendtime;
	}
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Set<Testpaper_Topic> getSettopic() {
		return settopic;
	}
	public void setSettopic(Set<Testpaper_Topic> settopic) {
		this.settopic = settopic;
	}

	

	
	
	

}
