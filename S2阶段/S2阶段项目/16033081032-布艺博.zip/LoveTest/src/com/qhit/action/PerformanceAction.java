package com.qhit.action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.qhit.biz.implents.BizImplents;
import com.qhit.model.Classes;
import com.qhit.model.Direction;
import com.qhit.model.PageBean;
import com.qhit.model.Performance;
import com.qhit.model.Score;
import com.qhit.model.Student;
import com.qhit.model.StudentAnswer;
import com.qhit.model.Subject;
import com.qhit.model.Testpaper;
import com.qhit.model.Testpaper_Classes;
import com.qhit.model.Testpaper_Topic;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
/**
 * @author ���ղ�
 * ��Action���ڳɼ�����ģ��
 * */
public class PerformanceAction {
	private PageBean pagebean;
	private Subject subject;
	private List<Direction> listdirection;
	private List<Testpaper_Classes> listc;	
	//����ҳ�洫�͹������Ծ���Ϣ
	private Testpaper testpaper;
	//�첽���ظ�ǰ̨����
	private String result;
	//�����Ծ���༶�Ķ�Զ��ϵ����ֳ�һ�Զ� �������ͨ��������-ѧ��-�༶ ����ȡ�༶ 
	//��˰༶���ظ� ������Ҫset������װ��ĳ���Ծ��İ༶
	private Set<Classes> setclasses;
	//��ҳ�洫�ͳɼ���Ϣ
	private List<Score> listscore;
	//����ҳ��İ༶��Ϣ
	private Classes classesforpaper;
	//����ҳ���ѧ����Ϣ
	private Student studentforpape;
	//���ڽ���ǰ̨���͵�ѧ����ʵ������Ϣ
	private Score score;
	//ѧ���𰸱�����
	private List<StudentAnswer> studenta;
	//�Ծ�����Ĺ�ϵʵ���༯��
	private List<Testpaper_Topic> listttp;
	/**
	 * @author ���ղ�
	 * �˷������ڲ�ѯ����������ת���ɼ�������ҳ
	 * */
	public String Main() {
		BizImplents biz=new BizImplents();
		listdirection=biz.Select("from Direction", null);
		Paging();
		
		return "Main";
	}
	
	
	/**
	 * @author ���ղ�
	 * �˷������ڳɼ�����ҳ����첽ˢ��
	 * */
	public String Asynchronous() {
		Paging();
		List<Performance> list=new ArrayList<Performance>();
		for (Object obj : pagebean.getList()) {
			Testpaper tp=(Testpaper) obj;
			Performance pf=new Performance();
			pf.setPid(tp.getPid());
			pf.setTime(tp.getPtime());
			pf.setTitle(tp.getPtitle());
			pf.setSubjectname(tp.getSubject().getSubname());
			String classname="";
			for (Testpaper_Classes testpaper_Classes : listc) {
				if(testpaper_Classes.getTestpaper().getPid()==tp.getPid()) {
					classname+=testpaper_Classes.getClasses().getCcode()+testpaper_Classes.getClasses().getCname()+",";
				}
			}
			classname=classname.substring(0, classname.length());
			pf.setClassname(classname);
			list.add(pf);
		}
		pagebean.setList(null);
		Object[] resultobj=new Object[2];
		resultobj[0]=pagebean;
		resultobj[1]=list;
		JSONArray jsonArray=JSONArray.fromObject(resultobj);
		result=jsonArray.toString();
		return "Asynchronous";
	}
	
	/**
	 * @author ���ղ�
	 * �˷�������ѡ���Ծ�����ʾ���вμӸôο��Ե�ѧ�����б�
	 * */
	public String AllStudentForTestPaper() {
		BizImplents biz=new BizImplents();
		setclasses=new HashSet<Classes>();
		Object[] obje;
		String hql;
		
		 if(classesforpaper!=null && studentforpape!=null) {
			 hql="from Score where testpaper.pid=? and student.sid=? and student.classes.cid=?";
			 obje=new Object[3];
			 obje[0]=testpaper.getPid();
			 obje[1]=studentforpape.getSid();
			 obje[2]=classesforpaper.getCid();
		 }
		 else {
			 hql="from Score where testpaper.pid=?";
				obje=new Object[1];
				obje[0]=testpaper.getPid();
		 }
	
		
		listscore=biz.Select(hql, obje);
		for (Score score : listscore) {
			setclasses.add(score.getStudent().getClasses());
		}
		return "allstudentforpaper";
	}
	
	/**
	 * @author ���ղ�
	 * �鿴ѧ���Ծ�����ҳ��
	 * */
	public String Details() {
		BizImplents biz=new BizImplents();
		String hql="from Score where scoid=?";
		String hqla="from StudentAnswer where testpaper.pid=? and student.sid=?";
		List list=biz.Select(hql, new Object[] {score.getScoid()});
		List lista=biz.Select(hqla, new Object[] {testpaper.getPid(),studentforpape.getSid()});
		score=(Score) list.get(0);
		studenta=lista;
		return "paperdetails";
	}
	
	/**
	 * @author ���ղ�
	 * �鿴�Ծ� ����ҳ���ȡ���Ծ�ID��ѯ�����Ծ��µ�������Ŀ������ʾ
	 * */
	public String TopicForTestPaper() {
		BizImplents biz=new BizImplents();
		listttp=biz.Select("from Testpaper_Topic where testpaper.pid=?", new Object[] {testpaper.getPid()});
		return "topicdetials";
	}
	
	/**
	 * @author ���ղ�
	 * ��ҳ��ʾ�Ծ��б�����
	 * */
	public void Paging() {
		BizImplents biz=new BizImplents();
		String hql="";
		String counthql="";
		String tcql="from Testpaper_Classes";
		//�ж�ҳ���Ƿ񴫵ݹ�����ǰҳ
		if(pagebean==null||pagebean.getPagenow()<=0) {
			pagebean=new PageBean();
			pagebean.setPagenow(1);
			pagebean.setPagesize(5);
		}
		pagebean.setPagesize(5);
		if(subject==null) {
			hql="from Testpaper where state<>0 ";
			counthql="select count(t) from Testpaper t where t.state<>0";
		}
		else {
			hql="from Testpaper where state<>0 and subject.subid="+subject.getSubid();
			counthql="select count(t) from Testpaper t where   t.state<>0 and t.subject.subid="+subject.getSubid();
		}
		biz.SelectPageing(hql,null, pagebean);
		List count=biz.Select(counthql,null);
		listc=biz.Select(tcql, null);
		if(count!=null&&count.size()>0) {
			Integer c=Integer.parseInt(count.get(0).toString());
			Integer b=pagebean.getPagesize();
			Integer pagec=(int)Math.ceil((double)c/(double)b);
			pagebean.setPagecount(pagec);
			
		}
		
		
		
	}
	
	
	
	
	public List<Testpaper_Classes> getListc() {
		return listc;
	}
	public void setListc(List<Testpaper_Classes> listc) {
		this.listc = listc;
	}
	public PageBean getPagebean() {
		return pagebean;
	}
	public void setPagebean(PageBean pagebean) {
		this.pagebean = pagebean;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public List<Direction> getListdirection() {
		return listdirection;
	}
	public void setListdirection(List<Direction> listdirection) {
		this.listdirection = listdirection;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}


	public Testpaper getTestpaper() {
		return testpaper;
	}


	public void setTestpaper(Testpaper testpaper) {
		this.testpaper = testpaper;
	}


	public Set<Classes> getSetclasses() {
		return setclasses;
	}


	public void setSetclasses(Set<Classes> setclasses) {
		this.setclasses = setclasses;
	}


	public List<Score> getListscore() {
		return listscore;
	}


	public void setListscore(List<Score> listscore) {
		this.listscore = listscore;
	}


	public Classes getClassesforpaper() {
		return classesforpaper;
	}


	public void setClassesforpaper(Classes classesforpaper) {
		this.classesforpaper = classesforpaper;
	}


	public Student getStudentforpape() {
		return studentforpape;
	}


	public void setStudentforpape(Student studentforpape) {
		this.studentforpape = studentforpape;
	}


	public Score getScore() {
		return score;
	}


	public void setScore(Score score) {
		this.score = score;
	}


	public List<StudentAnswer> getStudenta() {
		return studenta;
	}


	public void setStudenta(List<StudentAnswer> studenta) {
		this.studenta = studenta;
	}


	public List<Testpaper_Topic> getListttp() {
		return listttp;
	}


	public void setListttp(List<Testpaper_Topic> listttp) {
		this.listttp = listttp;
	}

	

	
	
	
	

}
