package com.qhit.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionSupport;
import com.qhit.biz.implents.BizImplents;
import com.qhit.model.Direction;
import com.qhit.model.PageBean;
import com.qhit.model.Stage;
import com.qhit.model.Subject;
import com.qhit.model.Topic;
@SuppressWarnings("unchecked")
public class TopicAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//����ID
	private Integer direction;
	//�׶�ID
	private Integer stage;
	//��ĿID
	private Integer fortopicsubid;
	//���򼯺�
	private List<Direction> listdirection;
	//��Ŀ����
	private List<Topic> listtopic;
	//�׶μ���
	private List<Stage> liststage;
	//��Ŀ����
	private List<Subject> listsubject;
	//��Ŀ�µ�����
	private Map<Integer,Integer> subjecttopiccount=new HashMap<Integer, Integer>();
	//��ҳʵ����
	private  PageBean pagebean;
	//���ӵ���Ŀ����
	private Topic addtopic;
	//�޸ĵ���Ŀ����
	private Topic updatetopic;

	/**
	 * @author ���ղ�
	 * ��ѯ���з������н׶�
	 * */
	public String Main(){
			BizImplents bizimplents=new BizImplents();
			listdirection=bizimplents.Select("from Direction ",null);
			if(direction==null||direction==0) {
				liststage=bizimplents.Select("select ds.stage from Direction_Stage ds where ds.direction.did=?  ",new Object[] {listdirection.get(0).getDid()});
				direction=listdirection.get(0).getDid();
			}
			liststage=bizimplents.Select("select ds.stage from Direction_Stage ds where ds.direction.did=?  ",new Object[] {listdirection.get(0).getDid()});
			if(stage==null||stage==0) {
				stage=liststage.get(0).getSid();
			}
			listsubject=SelectCountSubject(direction,stage);
			
		return "TopicSuccess";
	}
	
	/**
	 * @author ���ղ�
	 * ��ѯĳ���׶��µ����п�Ŀ�Լ�������Ŀ�¸��ж�������
	 * @param directionid �����ID
	 * @param stageid �׶α�ID
	 * */
	public List SelectCountSubject(Integer directionid,Integer stageid) {   
		List<Subject> list=new ArrayList();
		BizImplents bizimplents=new BizImplents();
		String sql="select * from subject where subid in(select subid from subject_direction_stage where dsid=(select dsid from direction_stage where did=? and sid=?))";
		list=bizimplents.SelectSQLQuery(sql, new Object[] {directionid,stageid});
		//list��ŵ��ǵ�ǰ����ǰ�׶��µ����п�Ŀ �����Ϊ�� ���ѯ�ÿ�Ŀ�µ�������
		if(list!=null&&list.size()!=0) {
			//��Ҫ�Ȳ�ѯ����������Ŀ����
			String sqla="from Subject where subid=?";
			String sqlb="select count(t) from Topic t where t.subject=?";
			for (Subject sub : list) {
				Subject uniquesubject=(Subject) bizimplents.Select(sqla, new Object[] {sub.getSubid()}).get(0);
				List lists=bizimplents.Select(sqlb, new Object[] {uniquesubject});
				if(lists!=null&&lists.size()!=0) {
					Object count=lists.get(0);
					subjecttopiccount.put(sub.getSubid(),Integer.parseInt(count.toString()));
				}
			
			}
			
		}
		return list;
	}
	/**
	 * @author ���ղ�
	 * ��ѯĳ����Ŀ�µ����������ҳ��ʾ
	 * */
	public String SelectTopicForSubject() {
		BizImplents bizimplents=new BizImplents();
		Subject subject=null;
		//�õ���Ŀ������Ŀ�Ŀ�Ŀ����
		String hqlforsubject="from Subject where subid=?";
		String hqlfortopic="from Topic where subject=?";
		if(fortopicsubid!=null&&fortopicsubid!=0) {
			listsubject=bizimplents.Select(hqlforsubject, new Object[] {fortopicsubid});
		}
		if(listsubject!=null&&listsubject.size()>0) {
			 subject=(Subject) listsubject.get(0);
		}
	
		//�ж�ҳ���Ƿ񴫵ݹ�����ǰҳ
		if(pagebean==null||pagebean.getPagenow()<=0) {
			pagebean=new PageBean();
			pagebean.setPagenow(1);
			pagebean.setPagesize(5);
		}
		pagebean.setPagesize(5);
		List count=bizimplents.Select("select count(t) from Topic t where t.subject=?",new Object[] {subject});
		if(count!=null&&count.size()>0) {
			Integer c=Integer.parseInt(count.get(0).toString());
			Integer b=pagebean.getPagesize();
			Integer pagec=(int)Math.ceil((double)c/(double)b);
			pagebean.setPagecount(pagec);
			
		}
		if(subject!=null) {
				pagebean=bizimplents.SelectPageing(hqlfortopic, new Object[] {subject}, pagebean);
		}
			
	
		return "lookattopic";
	}
	/**
	 * @author ���ղ�
	 * ��������Ŀ�����
	 * */
	public String AddTopic() {
		BizImplents bizimplents=new BizImplents();
		Subject subject=null;
		if(fortopicsubid!=null&&fortopicsubid!=0) {
			subject=(Subject)bizimplents.Select("from Subject where subid=?", new Object[] {fortopicsubid}).get(0);
		}
		addtopic.setSubject(subject);
		boolean add=bizimplents.Add(addtopic);
		if(add){
			this.addFieldError("addmessage", "���ӳɹ�");
		}
		else{
			this.addFieldError("addmessage", "����ʧ��");
		}
		return SelectTopicForSubject();
	}
	
	/**
	 * @author ���ղ�
	 * �޸���Ŀ
	 * */
	public String UpdateTopic() {
		BizImplents bizimplents=new BizImplents();
		if (updatetopic.getTid()!=null&&updatetopic.getAnswer()==null) {
			List list=bizimplents.Select("from Topic where tid=?", new Object[] {updatetopic.getTid()});
			if(list!=null&&list.size()>0){
				updatetopic=(Topic) list.get(0);
				
			}
			return "canupdate";
		}else {
			List list=bizimplents.Select("from Topic where tid=?", new Object[] {updatetopic.getTid()});
			Topic  t=(Topic)list.get(0);
			updatetopic.setSettestpaper(t.getSettestpaper());
			bizimplents.Update(updatetopic);
		}
		return SelectTopicForSubject();
	}

	
	
	
	
	
	
	
	
	
	public Integer getDirection() {
		return direction;
	}

	public void setDirection(Integer direction) {
		this.direction = direction;
	}

	public Integer getStage() {
		return stage;
	}

	public void setStage(Integer stage) {
		this.stage = stage;
	}

	public List<Direction> getListdirection() {
		return listdirection;
	}

	public void setListdirection(List<Direction> listdirection) {
		this.listdirection = listdirection;
	}

	public List<Stage> getListstage() {
		return liststage;
	}

	public void setListstage(List<Stage> liststage) {
		this.liststage = liststage;
	}

	public List<Subject> getListsubject() {
		return listsubject;
	}

	public void setListsubject(List<Subject> listsubject) {
		this.listsubject = listsubject;
	}

	public Map<Integer, Integer> getSubjecttopiccount() {
		return subjecttopiccount;
	}

	public void setSubjecttopiccount(Map<Integer, Integer> subjecttopiccount) {
		this.subjecttopiccount = subjecttopiccount;
	}

	public Integer getFortopicsubid() {
		return fortopicsubid;
	}

	public void setFortopicsubid(Integer fortopicsubid) {
		this.fortopicsubid = fortopicsubid;
	}

	public List<Topic> getListtopic() {
		return listtopic;
	}

	public void setListtopic(List<Topic> listtopic) {
		this.listtopic = listtopic;
	}

	public PageBean getPagebean() {
		return pagebean;
	}

	public void setPagebean(PageBean pagebean) {
		this.pagebean = pagebean;
	}

	public Topic getAddtopic() {
		return addtopic;
	}

	public void setAddtopic(Topic addtopic) {
		this.addtopic = addtopic;
	}

	public Topic getUpdatetopic() {
		return updatetopic;
	}

	public void setUpdatetopic(Topic updatetopic) {
		this.updatetopic = updatetopic;
	}
	
	
	
	
	

}
