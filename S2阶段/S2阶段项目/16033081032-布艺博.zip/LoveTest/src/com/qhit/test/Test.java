package com.qhit.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.biz.implents.BizImplents;
import com.qhit.dao.implents.DaoImplents;
import com.qhit.dao.implents.HibernateSessionFactory;
import com.qhit.dao.interfaces.DaoInterface;
import com.qhit.model.Subject;
import com.qhit.model.Teacher;
import com.qhit.model.Testpaper;

public class Test {
	public static void main(String[] args) {
		String s="������������";
		s=(String) s.subSequence(0, 2);

		System.out.println(s);
//		String s="����";
//		char[] k=s.toCharArray();
//		for (char c : k) {
//			System.out.println(c);
//		}
		
//		 Session session=HibernateSessionFactory.getSession();
//			session.beginTransaction();
//			Query query=session.createQuery("from Testpaper order by newid()");
//			List<Testpaper> list= query.list();
//			for (Testpaper te : list) {
//				System.out.println(te.getPtitle());
//			}
		
//		List list=new ArrayList<Integer>();
//		for (int i = 1; i <11; i++) {
//			list.add(i);
//		}
//		System.out.println("����ǰ");
//		System.out.println(list);
//		for (int i = 0; i <5; i++) {
//			Collections.shuffle(list);
//			}
//		System.out.println("���Һ�");
//		System.out.println(list);
//		
//		
		
//			session.beginTransaction().commit();
//			session.close();
////		ThreadA a;
//		ThreadB b;
//		ThreadA a2;
//		for (int i = 0; i <200; i++) {
//			ThreadA ai=new ThreadA(session);
//			ThreadB bi=new ThreadB(session);
//			a2=new ThreadA(session);
//			ai.start();
//			bi.start();
//		}
		
}
}