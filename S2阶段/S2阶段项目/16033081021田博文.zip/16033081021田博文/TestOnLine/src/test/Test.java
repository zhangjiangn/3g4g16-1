package test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		List<Integer> list=new ArrayList<Integer>();
//		
//		list.add(1);
//		list.add(12);
//		list.add(25);
//		list.add(89);
//		list.add(49);
//		int []nums=new int[list.size()];
//		List<Integer> list2=new ArrayList<Integer>();
//	
//		
//		int b=0;
//
//		int a=0;
//		int c=3;
//		int d=0;
//		
//		HashSet<Integer> suiji=new HashSet<Integer>();
//		for (int i = 0; i <= c; i++) {
//			a=(int)(Math.random()*list.size()+1);
//			System.out.println(11111);
//				if (i==0) {
//					list2.add(list.get(a));
//					suiji.add(a);
//					
//				}else if(i>0){
//					for (Integer integer : suiji) {
//						if (integer==a) {
//							d=1;
//							break;
//						}
//					}
//					if (d==1) {
//						i--;
//					}else{
//						list2.add(list.get(a));
//					}		
//				}				
//												
//		}
//		for (Integer integer : list2) {
//			System.out.println(integer);
//		}		
//		String str1 = "3G4G-1631,JAVA-1631";
//		String str2 = "3G4G-1632";
//		for(int i = 0; i < str2.length(); i++){
//			
//			if(str1.indexOf(str2.charAt(i)) != -1){
//				System.out.println("����");
//			}else{
//				System.out.println(str2.charAt(i)+"������");
//			}
//		}
		String str1 = "3G4G-1631,JAVA-1631";
		String str2 = "JAVA-1631";
		boolean isEquals = true;
		    for (int i = 0; i < str2.length(); i++) {
		        if (str1.indexOf(str2.charAt(i)) > -1) {
		        	
		        }else{
		        	isEquals = false;
		        	
		        }
		    }
		    System.out.println(isEquals);
	
		
	
	}
	
}
