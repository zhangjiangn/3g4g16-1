package Biz;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import beans.Admin;
import beans.Classes;
import beans.Direction;
import beans.Problem;
import beans.Stage;
import beans.StuAchievements;
import beans.Student;
import beans.StudentAnswer;
import beans.Subject;
import beans.Teacher;
import beans.TestPaper;
import beans.TestPaperProblem;
import beans.Users;

public interface BizInter {
	
	public Admin findAdmin(Users users);
	
	public Student findStudent(Users users);
	
	public Teacher findTeacher(Users users);
	
	public List<Direction> findDirection();
	
	public List<Stage> findStage(Direction direction);
	
	public List<Object[]> findAllProblemByDireAndSta();
	
	public String findStaName(Direction direction,Stage stage);
	
	public String findStaName1();

	public List<Object[]> findProIdAndSubName(Direction direction, Stage stage);
	
	public List<Object[]> findAllProblem(int staId,int direId,String subName,int fenye);
	
	public List<Object[]> findProblemCount(int staId,int direId,String subName);
	
	public int addProblem(Problem problem,int direId);
	
	public int findSubIdBySubName(int staId,int direId,String subName);
	
	public int updateProblem(Problem problem);
	
	public Problem findProblemByProId(Problem problem);
	
	public List<Object[]> findAllTestPaper();
	
	public List<Stage> findStageById(int direId);
	
	public List<Object[]> findTestPaperByChoose(TestPaper testPaper,Direction direction,Stage stage,Subject subject);
	
	public List<Object[]> findSubjectName();
	
	public List<Problem> findProblemByDireIdAndStaIdAndSubId(Direction direction,Stage stage,Subject subject);
	
	public int addTestPaper(String testPaperSubName,TestPaper testPaper,Set testPaperProblems);
	
	public String findDireNameById(Direction direction);
	
	public String findSubNameBySubId(Subject subject);
	
	public String findStaNameByStaId(Stage stage);
	
	public int addtestPaperProblem(int testId,int proId);
	
	public List<Object[]> findSubjectName(Direction direction,Stage stage);
	
	public List<Object[]> findTestPaperById(int testId);

	public List<Integer> findTestProblemIdBytestId(int testId);

	public List<Object[]> findtestProblemByproId(List<Integer> proIds);
	
	public List<Classes> findClassName();

	public int addClassNameForTestPaper(String claName,int testId);

	public int updatetestPaperState(String testState,int testId,Timestamp beginTime);
	
	public int updatetestPaperStateEnd(int testId);
	
	public List<Integer> findAllproId(int direId,int staId,int subId);
	
	public int findClaId(String name,String pwd);
	
	public String findClaName(int claId);
	
	public List<Object[]> findtestPaperBytestId(List<Integer> testId);
	
	public List<Object[]> findClaNameAndtestId();
	
	public List<Integer> findtestId();
	
	public List<String> findtestClass();
	
	public List<Object[]> findtestPaperWhenTestOnLine(int testId);
	
	public List<Integer> findproIdBytestId(int testId);
	
	public List<Problem> findproNameByproId(List<Integer> ids);
	
	public List<Problem> findproNameByproId(int proId);

	public int addStudentAnswer(int testId,int claId,int proId);
	
	public int updateStudentAnswer(int swid,String stuAnswer);
	
	public int findSwidByProIdAndTestId(int proId,int testId);
	
	public int findSumOfSwidByClaIdAndtestId(int claId,int testId);

	public List<StudentAnswer> findStuAnswer(int claId,int testId);
	
	public List<Integer> findproIdBytestIdAndclaId(int testId,int claId);
	
	public List<Object[]> findproAnswerByproId(List<Integer> ids);
	
	public List<String> findstuAnswerByproId(int testId,int claId);
	
	public int findtestOneScoreBytestId(int testId);

	public int addstuAchievements(int claId,int testId,int sumCount,String subjectName,Timestamp beginTime);
	
	public String findSubjectNameBytestId(int testId);
	
	public List<StuAchievements> findstuAchievement();
	
	public String findstuNameByclaId(int claId);
	
	public TestPaper findtestPaperBytestId(int testId);

	public List<Object[]> findstuAchievementsByclaIdAndTestId(int claId,int testId);
	
	public int findSumProblemCount(int testId,int claId);
	
	public List<Problem> findproolemByproId(List<Integer> proIds);
	
	public int addWrongProblem(int testId,int claId,int wrongProId);
	
	public List<Integer> findWrongProblemBytestId(int testId,int claId);
	
	public Timestamp findBeginTimeBytestId(int testId);
	
	public Timestamp findendTimeBytestIdAndclaId(int testId,int claId);
	
	public Student findstuNameAndstuPwdByclaId(int claId);
	
	public int findSubIdBydireIdAndstaId(int direId,int staId);
	
	public Subject findSubjectBysubName(String subName);
	
	public int addProblem(Problem problem);
}
