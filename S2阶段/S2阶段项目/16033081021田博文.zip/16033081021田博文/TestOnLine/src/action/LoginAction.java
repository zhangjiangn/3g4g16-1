package action;



import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.jms.Session;
import javax.rmi.CORBA.Tie;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;



import dao.DaoImpl;
import daoInter.DaoInter;
import beans.Admin;
import beans.Classes;
import beans.Direction;
import beans.Problem;
import beans.Stage;
import beans.StuAchievements;
import beans.Student;
import beans.StudentAnswer;
import beans.Subject;
import beans.Teacher;
import beans.TestPaper;
import beans.TestPaperProblem;
import beans.Users;

public class LoginAction {
	static int fenye=0;
	
	private Admin admin;
	
	private Classes classes1;
	
	private Teacher teacher;
	
	private Student student;
	
	private Users users;
	
	private Direction direction;
	
	private Stage stage;
	
	private Subject subject;
	
	private Problem problem;
	
	private List<Integer> proIds;
	
	private List<Object[]> problems;
	
	private List<Problem> problemss;
	
	private int sumProId;
	
	private int testId;
	
	private List<Object[]> sumTestState;
	
	private int testPanduan;
	
	public int getTestPanduan() {
		return testPanduan;
	}
	public void setTestPanduan(int testPanduan) {
		this.testPanduan = testPanduan;
	}
	public List<Object[]> getSumTestState() {
		return sumTestState;
	}
	public void setSumTestState(List<Object[]> sumTestState) {
		this.sumTestState = sumTestState;
	}
	private StudentAnswer studentAnswer;
	
	private List<StudentAnswer> stuAnswers;
	
	private List<StuAchievements> achievements;

	public List<StuAchievements> getAchievements() {
		return achievements;
	}
	public void setAchievements(List<StuAchievements> achievements) {
		this.achievements = achievements;
	}
	public List<StudentAnswer> getStuAnswers() {
		return stuAnswers;
	}
	public void setStuAnswers(List<StudentAnswer> stuAnswers) {
		this.stuAnswers = stuAnswers;
	}
	public StudentAnswer getStudentAnswer() {
		return studentAnswer;
	}
	public void setStudentAnswer(StudentAnswer studentAnswer) {
		this.studentAnswer = studentAnswer;
	}
	public Classes getClasses1() {
		return classes1;
	}
	public void setClasses1(Classes classes1) {
		this.classes1 = classes1;
	}
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public int getSumProId() {
		return sumProId;
	}
	public void setSumProId(int sumProId) {
		this.sumProId = sumProId;
	}
	public List<Problem> getProblemss() {
		return problemss;
	}
	public void setProblemss(List<Problem> problemss) {
		this.problemss = problemss;
	}
	
	private List<Integer> wrongAnswer;
	
	public List<Integer> getWrongAnswer() {
		return wrongAnswer;
	}
	public void setWrongAnswer(List<Integer> wrongAnswer) {
		this.wrongAnswer = wrongAnswer;
	}
	private List<Object[]> subjects;

	private List<Object[]> timus1;
	
	private List<Direction> directions;
	
	private List<Stage> stages;
	
	private int direId;
	
	private String staName;
	
	private String subName;
	
	private TestPaper testPaper;
	
	private List<Object[]> testPapers;
	
	private Set testPaperProblems;
	
	private TestPaperProblem testPaperProblem;
	
	private int sumProCount=0;
	
	private List<Classes> classes;
	
	private List<String> classNames;
	
	private String stuName;
	
	private List<Object[]> StuAchievements;
	
	public List<Object[]> getStuAchievements() {
		return StuAchievements;
	}
	public void setStuAchievements(List<Object[]> stuAchievements) {
		StuAchievements = stuAchievements;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	private int xiabiao;
	
	public int getXiabiao() {
		return xiabiao;
	}
	public void setXiabiao(int xiabiao) {
		this.xiabiao = xiabiao;
	}
	public TestPaper getTestPaper() {
		return testPaper;
	}
	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}
	
	public List<String> getClassNames() {
		return classNames;
	}
	public void setClassNames(List<String> classNames) {
		this.classNames = classNames;
	}
	public List<Object[]> getTestPapers() {
		return testPapers;
	}
	public void setTestPapers(List<Object[]> testPapers) {
		this.testPapers = testPapers;
	}
	DaoInter dao=new DaoImpl();
	
	public String login(){
		
		
		String fanhui="";
		
		int role=users.getRole();
		
		switch (role) {
		case 1:
			
			student=dao.findStudent(users);
			
			if (student==null) {
				
				fanhui="loginSB";
			}else{
				Map<String, Object> ses=ActionContext.getContext().getSession();
				users.setUid(1);
				ses.put("name", users);
				fanhui="loginCG";
			}
			break;
		case 2:
			
			teacher=dao.findTeacher(users);
			if (teacher==null) {
				
				fanhui="loginSB";
			}else{
				Map<String, Object> ses=ActionContext.getContext().getSession();
				users.setUid(2);
				ses.put("name", users);
				fanhui="loginCG";
			}
			break;
		case 3:
			
			admin=dao.findAdmin(users);
			if (admin==null) {
			
				fanhui="loginSB";
			}else{
				Map<String, Object> ses=ActionContext.getContext().getSession();
				users.setUid(3);
				ses.put("name", users);
				fanhui="loginCG";
			}
			break;
		default:
			break;
		}
		
		return fanhui;
	}
	public String findAll(){
			directions=dao.findDirection();
			stages=dao.findStage(direction);
			staName=dao.findStaName(direction, stage);
			timus1=dao.findProIdAndSubName(direction, stage);	
		return "findAll";
	}
	public String selTimu(){
		
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		String subName=subject.getSubName();
		problems=dao.findAllProblem(staId, direId, subName,fenye);
		return "selTimu";
	}
	public String xiayiye(){
		
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		String subName=subject.getSubName();
		List<Object[]> counts=dao.findProblemCount(staId, direId, subName);
		int a=counts.size();
		fenye+=5;
		if (fenye>=a) {
			fenye-=5;	
		}
		return "next";
	}
	public String shangyiye(){
		
		if (fenye<=0) {
			fenye=0;
		}else{
			fenye-=5;
		}
		return "up";
	}
	public String addChuli(){
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		String subName=subject.getSubName();	
		return "addChuli";
	}
	public String addProblem(){
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		String subName=subject.getSubName();
		Integer subId=dao.findSubIdBySubName(staId,direId,subName);
		problem.setStaId(staId);
		problem.setSubId(subId);
		int i=dao.addProblem(problem,direId);
		if (i==0) {
			System.out.println("���ӳɹ���");
			return "addProblemCG";
		}else{
			System.out.println("����ʧ��");
			return "addProblemSB";
		}
	}
	public String updateProblemChuli(){
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		String subName=subject.getSubName();
	
		problem=dao.findProblemByProId(problem);
		return "updateProblemChuli";
	}
	public String updateProblem(){
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		String subName=subject.getSubName();
		dao.updateProblem(problem);
		
		return "updateProblem";
	}
	public String testPaper(){
		
		directions=dao.findDirection();
		stages=dao.findStage(direction);
		subjects=dao.findSubjectName(direction, stage);
		testPapers=dao.findAllTestPaper();
		
		return "testPaper";
	}
	public String findTestPaper(){
		
		directions=dao.findDirection();
		stages=dao.findStage(direction);
		subjects=dao.findSubjectName(direction, stage);
		testPapers=dao.findTestPaperByChoose(testPaper, direction, stage, subject);

	
		
		return "findTestPaper";
	}
	public String chooseTestPaper(){
				
				directions=dao.findDirection();
				stages=dao.findStage(direction);
				subjects=dao.findSubjectName(direction, stage);
				problemss=dao.findProblemByDireIdAndStaIdAndSubId(direction, stage, subject);
		return "chooseTestPaper";
	}
	public String addTestpaper(){
		

		String direName=dao.findDireNameById(direction);
		String staName=dao.findStaNameByStaId(stage);
		String subName=dao.findSubNameBySubId(subject);
		String testPaperSubName="["+direName+" "+staName+"]"+" "+subName;

			List<Integer> list=proIds;
			testPaperProblems = new HashSet(0);
			
			for (Integer s : list) {
				problem=new Problem();
				testPaperProblem=new TestPaperProblem();
				testPaper.setTestSubjectName(testPaperSubName);
				testPaper.setSubject(subject);
				testPaper.setTestType("����");
				testPaper.setTestState("δ����");
				problem.setProId(s);
				testPaperProblem.setProblem(problem);
				testPaperProblem.setTestPaper(testPaper);
				testPaperProblems.add(testPaperProblem);
			}
			int i=dao.addTestPaper(testPaperSubName, testPaper,testPaperProblems);
			if (i==0) {
				System.out.println("���ӳɹ���");
			}else{
				System.out.println("����ʧ��!");
			}
		
		return "addTestpaper";
	}
	public String showTestPaper(){
		
		testPapers=dao.findTestPaperById(testPaper.getTestId());
		List<Integer> proIds=dao.findTestProblemIdBytestId(testPaper.getTestId());
		problems=dao.findtestProblemByproId(proIds);
		
		return "showTestPaper";
	}
	public String suijiTestPaperJilian(){
		directions=dao.findDirection();
		stages=dao.findStage(direction);
		subjects=dao.findSubjectName(direction, stage);
		
		return "suijiTestPaper";
	}
	public String suijiTestPaper(){
		String direName=dao.findDireNameById(direction);
		String staName=dao.findStaNameByStaId(stage);
		String subName=dao.findSubNameBySubId(subject);
		String testPaperSubName="["+direName+" "+staName+"]"+" "+subName;
		
		List<Integer> proIds=dao.findAllproId(direction.getDireId(), stage.getStaId(), subject.getSubId());
		
		
		
		
		return "";
	}
	public String beginTest(){
		
		classes=dao.findClassName();
		
		return "beginTest";
	}
	public String testChuli(){
		
		System.out.println(testPaper.getTestId()+"testId");
		String className="";
		List<String> s=classNames;
		for (int i = 0; i <= s.size(); i++) {		
			if (i==s.size()-1){
				className+=s.get(i);
			}else if(i<s.size()){				
				className+=s.get(i);
				className+=",";
			}
		}
		dao.addClassNameForTestPaper(className, testPaper.getTestId());

		String testState="������";
		dao.updatetestPaperState(testState, testPaper.getTestId(),testPaper.getBeginTime());
		
		return "testChuli";
	}
	public String endTest(){
	
		dao.updatetestPaperStateEnd(testPaper.getTestId());

		return "endTest";
	}
	public String testOnLine(){
		
		int claId=dao.findClaId(student.getStuName(), student.getStuPwd());
		direId=claId;
		System.out.println("claId="+claId);
		String claName=dao.findClaName(claId);
		System.out.println("claName="+claName);
		List<Integer> testId=new ArrayList<Integer>();
		boolean isEquals = false;
		List<Integer> id=dao.findtestId();
		List<String> testClass=dao.findtestClass();
		
		for (int i = 0; i < id.size(); i++) {
				String [] claNamess=testClass.get(i).split(",");
				for(int j=0;j<claNamess.length;j++){
					if(claNamess[j].equals(claName)){
						isEquals=true;
					}
				}
				if (isEquals){
					testId.add(id.get(i));
				}
		}
		testPapers=dao.findtestPaperBytestId(testId);	
		return "testOnLine";
	}
	public String beginTestOnline(){
		
		Timestamp endTime=dao.findendTimeBytestIdAndclaId(testPaper.getTestId(), classes1.getClaId());
		student=dao.findstuNameAndstuPwdByclaId(classes1.getClaId());
		
		if (endTime!=null) {
			student.setStuName(student.getStuName());
			student.setStuPwd(student.getStuPwd());
			
			return "tested";
			
		}else{
		
			classes1.setClaId(classes1.getClaId());
			xiabiao=0;
			testId=testPaper.getTestId();
			testPapers=dao.findtestPaperWhenTestOnLine(testPaper.getTestId());
			stuAnswers=dao.findStuAnswer(classes1.getClaId(), testPaper.getTestId());
			
			List<Integer> list=dao.findproIdBytestId(testPaper.getTestId());
			
			problemss=dao.findproNameByproId(list);
			
			int sum=dao.findSumOfSwidByClaIdAndtestId(classes1.getClaId(), testPaper.getTestId());
	
			if (sum==0) {
				for (int i = 0; i < list.size(); i++) {
					
					int j=dao.addStudentAnswer(testId, classes1.getClaId(), list.get(i));
					
				}
			}
		
			return "beginTestOnline";
		}
		
	}
	public String beginTestOnline2(){
		classes1.setClaId(classes1.getClaId());
		System.out.println("claId1="+classes1.getClaId());
		System.out.println("testId1="+testPaper.getTestId());
		stuAnswers=dao.findStuAnswer(classes1.getClaId(), testPaper.getTestId());
		xiabiao=xiabiao;
		testId=testPaper.getTestId();
		testPapers=dao.findtestPaperWhenTestOnLine(testPaper.getTestId());
		
		
		List<Integer> list=dao.findproIdBytestId(testPaper.getTestId());
		int []proId=new int[list.size()];
		for (int i = 0; i < list.size(); i++) {
			proId[i]=list.get(i);
		}
		int p;
		if (xiabiao<=0) {
			xiabiao=0;
			p=proId[0];
		}else if (xiabiao>=proId.length) {
			xiabiao=proId.length-1;
			p=proId[proId.length-1];
		}else{
			p=proId[xiabiao];
		}
		System.out.println("��ťproId="+p);
		problemss=dao.findproNameByproId(p);
		
		return "beginTestOnline2";
	}
	public String beginTestOnline3(){
		System.out.println("����beginTestOnline3");
		classes1.setClaId(classes1.getClaId());
		stuAnswers=dao.findStuAnswer(classes1.getClaId(), testPaper.getTestId());
		xiabiao=xiabiao;
		testId=testPaper.getTestId();
		testPapers=dao.findtestPaperWhenTestOnLine(testPaper.getTestId());
		List<Integer> list=dao.findproIdBytestId(testPaper.getTestId());
		int []proId=new int[list.size()];
		for (int i = 0; i < list.size(); i++) {
			proId[i]=list.get(i);
		}
		int p;
		if (xiabiao<=0) {
			xiabiao=0;
			p=proId[0];
		}else if (xiabiao>=proId.length) {
			xiabiao=proId.length-1;
			p=proId[proId.length-1];
		}else{
			p=proId[xiabiao];
		}
		problemss=dao.findproNameByproId(p);
		String answer=problem.getProAnswer();
		problem.setProAnswer(answer);
		
		int swid=dao.findSwidByProIdAndTestId(problem.getProId(),testPaper.getTestId());
		dao.updateStudentAnswer(swid,problem.getProAnswer());
		return "beginTestOnline3";
	}
	public String endTestOnline(){
		
		
		
		direId=classes1.getClaId();
		String claName=dao.findClaName(classes1.getClaId());
		List<Integer> testId=new ArrayList<Integer>();
		String claNames=null;
		boolean isEquals = true;
		List<Integer> id=dao.findtestId();
		List<String> testClass=dao.findtestClass();
		for (int i = 0; i < id.size(); i++) {
			claNames=testClass.get(i);
			 for (int j = 0; j < claName.length(); j++) {
			        if (claNames.indexOf(claName.charAt(i)) <= -1) {
			            isEquals = false;
			        }else{
			        	testId.add(id.get(i));
			        }
			    }
		}
		testPapers=dao.findtestPaperBytestId(testId);
//		----------------
		List<Integer> list=dao.findproIdBytestIdAndclaId(testPaper.getTestId(), classes1.getClaId());
		List<Object[]> rightAnswer=dao.findproAnswerByproId(list);
		List<String> stuAnswer=dao.findstuAnswerByproId(testPaper.getTestId(), classes1.getClaId());
		wrongAnswer=new ArrayList<Integer>();
		
		for (int i = 0; i < wrongAnswer.size(); i++) {
			int c=dao.addWrongProblem(testPaper.getTestId(), classes1.getClaId(),wrongAnswer.get(i) );
			if (c==0) {
				System.out.println("���ӳɹ���");
			}else{				
				System.out.println("���ӳɹ���");
			}
		}
		
		int sumCount=0;
		int testOneScore=dao.findtestOneScoreBytestId(testPaper.getTestId());
		for (int i = 0; i < rightAnswer.size(); i++) {
			if (rightAnswer.get(i)[0].equals(stuAnswer.get(i))||rightAnswer.get(i)[0]==stuAnswer.get(i)) {
				sumCount+=testOneScore;
			}else{
				wrongAnswer.add((Integer)rightAnswer.get(i)[1]);
			}
			
		}
		String subjectName=dao.findSubjectNameBytestId(testPaper.getTestId());
		Timestamp beginTime=dao.findBeginTimeBytestId(testPaper.getTestId());
		System.out.println("beginTime="+beginTime);
		dao.addstuAchievements(classes1.getClaId(), testPaper.getTestId(), sumCount, subjectName,beginTime);

		achievements=dao.findstuAchievement();
		
		return "endTestOnline";
	}
	public String findstuAchievement(){
				
		 achievements=dao.findstuAchievement();
		  
		return "findstuAchievement";
	}
	public String showStuachievements(){
		
		List<Integer> list=dao.findWrongProblemBytestId(testPaper.getTestId(),classes1.getClaId());
		
		testPaper=dao.findtestPaperBytestId(testPaper.getTestId());
		stuName=dao.findstuNameByclaId(classes1.getClaId());
		StuAchievements=dao.findstuAchievementsByclaIdAndTestId(classes1.getClaId(), testPaper.getTestId());
		sumProCount=dao.findSumProblemCount(testPaper.getTestId(), classes1.getClaId());
		
		List<Integer> proIds=dao.findproIdBytestIdAndclaId(testPaper.getTestId(), classes1.getClaId());
		problemss=dao.findproolemByproId(proIds);
		
		stuAnswers=dao.findStuAnswer(classes1.getClaId(),testPaper.getTestId());
		
		return "showStuachievements";
	}
	public String zhuxiao(){
		
		Map<String, Object> ses=ActionContext.getContext().getSession();
		ses.remove("name");
		
		return "zhuxiao";
	}
	
	
	public int getSumProCount() {
		return sumProCount;
	}
	public void setSumProCount(int sumProCount) {
		this.sumProCount = sumProCount;
	}
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}
	public Direction getDirection() {
		return direction;
	}
	public void setDirection(Direction direction) {
		this.direction = direction;
	}
	public Stage getStage() {
		return stage;
	}
	public void setStage(Stage stage) {
		this.stage = stage;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public Problem getProblem() {
		return problem;
	}
	public void setProblem(Problem problem) {
		this.problem = problem;
	}
	public List<Object[]> getTimus1() {
		return timus1;
	}
	public void setTimus1(List<Object[]> timus1) {
		this.timus1 = timus1;
	}


	public List<Object[]> getProblems() {
		return problems;
	}
	public void setProblems(List<Object[]> problems) {
		this.problems = problems;
	}
	public String getStaName() {
		return staName;
	}
	public void setStaName(String staName) {
		this.staName = staName;
	}

	public int getDireId() {
		return direId;
	}
	public void setDireId(int direId) {
		this.direId = direId;
	}
	public List<Stage> getStages() {
		return stages;
	}
	public void setStages(List<Stage> stages) {
		this.stages = stages;
	}
	public List<Direction> getDirections() {
		return directions;
	}
	public void setDirections(List<Direction> directions) {
		this.directions = directions;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
	public List<Object[]> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<Object[]> subjects) {
		this.subjects = subjects;
	}
	public List<Integer> getProIds() {
		return proIds;
	}
	public void setProIds(List<Integer> proIds) {
		this.proIds = proIds;
	}
	public TestPaperProblem getTestPaperProblem() {
		return testPaperProblem;
	}
	public void setTestPaperProblem(TestPaperProblem testPaperProblem) {
		this.testPaperProblem = testPaperProblem;
	}
	public Set getTestPaperProblems() {
		return testPaperProblems;
	}
	public void setTestPaperProblems(Set testPaperProblems) {
		this.testPaperProblems = testPaperProblems;
	}
	public List<Classes> getClasses() {
		return classes;
	}
	public void setClasses(List<Classes> classes) {
		this.classes = classes;
	}

	
	
	
	
}
