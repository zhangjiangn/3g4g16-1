package bizImpl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import dao.DaoImpl;
import daoInter.DaoInter;
import beans.Admin;
import beans.Classes;
import beans.Direction;
import beans.Problem;
import beans.Stage;
import beans.StuAchievements;
import beans.Student;
import beans.StudentAnswer;
import beans.Subject;
import beans.Teacher;
import beans.TestPaper;
import beans.TestPaperProblem;
import beans.Users;
import Biz.BizInter;

public class BizImpl implements BizInter {

	DaoInter dao=new DaoImpl();
	
	
	public Admin findAdmin(Users users) {
		// TODO Auto-generated method stub
		return dao.findAdmin(users);
	}

	public Student findStudent(Users users) {
		// TODO Auto-generated method stub
		return dao.findStudent(users);
	}

	public Teacher findTeacher(Users users) {
		// TODO Auto-generated method stub
		return dao.findTeacher(users);
	}
	public List<Direction> findDirection(){
		
		return dao.findDirection();
	}
	public List<Stage> findStage(Direction direction){
		
		return dao.findStage(direction);
	}

	public List<Object[]> findAllProblemByDireAndSta(){
		
		return dao.findAllProblemByDireAndSta();
	}


	public String findStaName(Direction direction, Stage stage) {
		// TODO Auto-generated method stub
		return dao.findStaName(direction,stage);
	}
	public List<Object[]> findProIdAndSubName(Direction direction, Stage stage){
		
		return dao.findProIdAndSubName(direction,stage);
	}
	public String findStaName1(){
		
		return dao.findStaName1();
	}
	public List<Object[]> findAllProblem(int staId,int direId,String subName,int fenye){
		
		return dao.findAllProblem(staId,direId,subName,fenye);
	}
	public List<Object[]> findProblemCount(int staId,int direId,String subName){
		
		return dao.findProblemCount(staId, direId, subName);
	}
	public int addProblem(Problem problem,int direId){
		return dao.addProblem(problem,direId);
	}
	public int findSubIdBySubName(int staId,int direId,String subName){
		
		return dao.findSubIdBySubName(staId,direId,subName);
	}
	public int updateProblem(Problem problem){
		
		return dao.updateProblem(problem);
	}
	public Problem findProblemByProId(Problem problem){
		
		return dao.findProblemByProId(problem);
	}
	public List<Object[]> findAllTestPaper(){
		
		return dao.findAllTestPaper();
	}
	public List<Stage> findStageById(int direId){
		return dao.findStageById(direId);
	}
	public List<Object[]> findTestPaperByChoose(TestPaper testPaper,Direction direction,Stage stage,Subject subject){
		
		return dao.findTestPaperByChoose(testPaper,direction,stage,subject);
	}
	public List<Object[]> findSubjectName(){
		return dao.findSubjectName();
	}
	public List<Problem> findProblemByDireIdAndStaIdAndSubId(Direction direction,Stage stage,Subject subject){
		
		return dao.findProblemByDireIdAndStaIdAndSubId(direction,stage,subject);
	}
	public int addTestPaper(String testPaperSubName,TestPaper testPaper,Set testPaperProblems){
		
		return dao.addTestPaper(testPaperSubName, testPaper,testPaperProblems);
	}
	public String findDireNameById(Direction direction){
		
		return dao.findDireNameById(direction);
	}
	public String findSubNameBySubId(Subject subject){
		
		return dao.findSubNameBySubId(subject);
	}
	public String findStaNameByStaId(Stage stage){
		
		return dao.findStaNameByStaId(stage);
	}

	public int addtestPaperProblem(int testId,int proId){
		
		return dao.addtestPaperProblem(testId, proId);
	}
	public List<Object[]> findSubjectName(Direction direction,Stage stage){
		
		return dao.findSubjectName(direction, stage);
	}
	public List<Object[]> findTestPaperById(int testId){
		
		return dao.findTestPaperById(testId);
	}
	public List<Integer> findTestProblemIdBytestId(int testId){
		
		return dao.findTestProblemIdBytestId(testId);
	}
	public List<Object[]> findtestProblemByproId(List<Integer> proIds){
		return dao.findtestProblemByproId(proIds);
	}
	public List<Classes> findClassName(){
		
		return dao.findClassName();
	}
	public int addClassNameForTestPaper(String claName,int testId){
		
		return dao.addClassNameForTestPaper(claName,testId);
	}
	public int updatetestPaperState(String testState,int testId,Timestamp beginTime){
		
		return dao.updatetestPaperState(testState, testId,beginTime);
	}
	public int updatetestPaperStateEnd(int testId){
		
		return dao.updatetestPaperStateEnd(testId);
	}
	public List<Integer> findAllproId(int direId,int staId,int subId){
		
		return dao.findAllproId(direId, staId, subId);
	}
	public int findClaId(String name,String pwd){
		
		return dao.findClaId(name, pwd);
	}
	public String findClaName(int claId){
		
		return dao.findClaName(claId);
	}
	public List<Object[]> findtestPaperBytestId(List<Integer> testId){
		return dao.findtestPaperBytestId(testId);
	}
	public List<Object[]> findClaNameAndtestId(){
		
		return dao.findClaNameAndtestId();
	}
	public List<Integer> findtestId(){
		
		return dao.findtestId();
	}
	public List<String> findtestClass(){
		
		return dao.findtestClass();
	}
	public List<Object[]> findtestPaperWhenTestOnLine(int testId){
		
		return dao.findtestPaperWhenTestOnLine(testId);
	}
	public List<Integer> findproIdBytestId(int testId){
		
		return dao.findproIdBytestId(testId);
	}
	public List<Problem> findproNameByproId(List<Integer> ids){
		
		return dao.findproNameByproId(ids);
	}
	public List<Problem> findproNameByproId(int proId){
		
		return dao.findproNameByproId(proId);
	}
	public int addStudentAnswer(int testId,int claId,int proId){
		
		return dao.addStudentAnswer(testId, claId, proId);
		
	}
	public int updateStudentAnswer(int swid,String stuAnswer){
		
		return dao.updateStudentAnswer(swid,stuAnswer);
	}
	public int findSwidByProIdAndTestId(int proId,int testId){
		
		return dao.findSwidByProIdAndTestId(proId, testId);
	}
	public int findSumOfSwidByClaIdAndtestId(int claId,int testId){
		
		return dao.findSumOfSwidByClaIdAndtestId(claId, testId);
	}
	public List<StudentAnswer> findStuAnswer(int claId,int testId){
		
		return dao.findStuAnswer(claId, testId);
	}
	public List<Integer> findproIdBytestIdAndclaId(int testId,int claId){
		
		return dao.findproIdBytestIdAndclaId(testId,claId);
	}
	public List<Object[]> findproAnswerByproId(List<Integer> ids){
		
		return dao.findproAnswerByproId(ids);
	}
	public List<String> findstuAnswerByproId(int testId,int claId){
		
		return dao.findstuAnswerByproId(testId, claId);
	}
	public int findtestOneScoreBytestId(int testId){
		
		return dao.findtestOneScoreBytestId(testId);
	}
	public int addstuAchievements(int claId,int testId,int sumCount,String subjectName,Timestamp beginTime){
		
		return dao.addstuAchievements(claId, testId, sumCount, subjectName,beginTime);
	}
	public String findSubjectNameBytestId(int testId){
		
		return dao.findSubjectNameBytestId(testId);
	}
	public List<StuAchievements> findstuAchievement(){
		
		return dao.findstuAchievement();
	}
	public String findstuNameByclaId(int claId){
		
		return dao.findstuNameByclaId(claId);
	}
	public TestPaper findtestPaperBytestId(int testId){
		
		return dao.findtestPaperBytestId(testId);
	}
	public List<Object[]> findstuAchievementsByclaIdAndTestId(int claId,int testId){
		
		return dao.findstuAchievementsByclaIdAndTestId(claId, testId);
	}
	public int findSumProblemCount(int testId,int claId){
		
		return dao.findSumProblemCount(testId, claId);
	}
	public List<Problem> findproolemByproId(List<Integer> proIds){
		
		return dao.findproolemByproId(proIds);
	}
	public int addWrongProblem(int testId,int claId,int wrongProId){
		
		return dao.addWrongProblem(testId, claId, wrongProId);
	}
	public List<Integer> findWrongProblemBytestId(int testId,int claId){
		
		return dao.findWrongProblemBytestId(testId,claId);
	}
	public Timestamp findBeginTimeBytestId(int testId){
		
		return dao.findBeginTimeBytestId(testId);
	}
	public Timestamp findendTimeBytestIdAndclaId(int testId,int claId){
		
		return dao.findendTimeBytestIdAndclaId(testId, claId);
	}
	public Student findstuNameAndstuPwdByclaId(int claId){
		return dao.findstuNameAndstuPwdByclaId(claId);
	}
	public int findSubIdBydireIdAndstaId(int direId,int staId){
		
		return dao.findSubIdBydireIdAndstaId(direId, staId);
	}
	public Subject findSubjectBysubName(String subName){
		
		return dao.findSubjectBysubName(subName);
	}
	public int addProblem(Problem problem){
		return dao.addProblem(problem);
	}
}
