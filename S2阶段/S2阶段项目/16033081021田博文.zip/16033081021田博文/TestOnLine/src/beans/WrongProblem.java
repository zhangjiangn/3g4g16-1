package beans;

/**
 * WrongProblem entity. @author MyEclipse Persistence Tools
 */

public class WrongProblem implements java.io.Serializable {

	// Fields

	private Integer wid;
	private Classes classes;
	private TestPaper testPaper;
	private Integer wrongProId;

	// Constructors

	/** default constructor */
	public WrongProblem() {
	}

	/** full constructor */
	public WrongProblem(Integer wid, Classes classes, TestPaper testPaper,
			Integer wrongProId) {
		this.wid = wid;
		this.classes = classes;
		this.testPaper = testPaper;
		this.wrongProId = wrongProId;
	}

	// Property accessors

	public Integer getWid() {
		return this.wid;
	}

	public void setWid(Integer wid) {
		this.wid = wid;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Integer getWrongProId() {
		return this.wrongProId;
	}

	public void setWrongProId(Integer wrongProId) {
		this.wrongProId = wrongProId;
	}

}