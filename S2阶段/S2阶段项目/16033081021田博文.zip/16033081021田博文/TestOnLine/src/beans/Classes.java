package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Classes entity. @author MyEclipse Persistence Tools
 */

public class Classes implements java.io.Serializable {

	// Fields

	private Integer claId;
	private String claName;
	private Set students = new HashSet(0);

	// Constructors

	/** default constructor */
	public Classes() {
	}

	/** minimal constructor */
	public Classes(Integer claId, String claName) {
		this.claId = claId;
		this.claName = claName;
	}

	/** full constructor */
	public Classes(Integer claId, String claName, Set students) {
		this.claId = claId;
		this.claName = claName;
		this.students = students;
	}

	// Property accessors

	public Integer getClaId() {
		return this.claId;
	}

	public void setClaId(Integer claId) {
		this.claId = claId;
	}

	public String getClaName() {
		return this.claName;
	}

	public void setClaName(String claName) {
		this.claName = claName;
	}

	public Set getStudents() {
		return this.students;
	}

	public void setStudents(Set students) {
		this.students = students;
	}

}