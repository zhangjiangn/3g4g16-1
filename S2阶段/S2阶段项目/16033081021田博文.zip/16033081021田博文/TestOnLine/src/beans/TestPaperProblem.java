package beans;

/**
 * TestPaperProblem entity. @author MyEclipse Persistence Tools
 */

public class TestPaperProblem implements java.io.Serializable {

	// Fields

	private Integer testProId;
	private TestPaper testPaper;
	private Problem problem;

	// Constructors

	/** default constructor */
	public TestPaperProblem() {
	}

	/** full constructor */
	public TestPaperProblem(Integer testProId, TestPaper testPaper,
			Problem problem) {
		this.testProId = testProId;
		this.testPaper = testPaper;
		this.problem = problem;
	}

	// Property accessors

	public Integer getTestProId() {
		return this.testProId;
	}

	public void setTestProId(Integer testProId) {
		this.testProId = testProId;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Problem getProblem() {
		return this.problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

}