package beans;

import java.sql.Timestamp;

/**
 * StuAchievements entity. @author MyEclipse Persistence Tools
 */

public class StuAchievements implements java.io.Serializable {

	// Fields

	private Integer caId;
	private Classes classes;
	private TestPaper testPaper;
	private String stuSubjectName;
	private Integer stuAchievements;
	private Timestamp begintime;
	private Timestamp endtime;

	// Constructors

	/** default constructor */
	public StuAchievements() {
	}

	/** minimal constructor */
	public StuAchievements(Integer caId, Classes classes, TestPaper testPaper,
			String stuSubjectName, Integer stuAchievements) {
		this.caId = caId;
		this.classes = classes;
		this.testPaper = testPaper;
		this.stuSubjectName = stuSubjectName;
		this.stuAchievements = stuAchievements;
	}

	/** full constructor */
	public StuAchievements(Integer caId, Classes classes, TestPaper testPaper,
			String stuSubjectName, Integer stuAchievements,
			Timestamp begintime, Timestamp endtime) {
		this.caId = caId;
		this.classes = classes;
		this.testPaper = testPaper;
		this.stuSubjectName = stuSubjectName;
		this.stuAchievements = stuAchievements;
		this.begintime = begintime;
		this.endtime = endtime;
	}

	// Property accessors

	public Integer getCaId() {
		return this.caId;
	}

	public void setCaId(Integer caId) {
		this.caId = caId;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public String getStuSubjectName() {
		return this.stuSubjectName;
	}

	public void setStuSubjectName(String stuSubjectName) {
		this.stuSubjectName = stuSubjectName;
	}

	public Integer getStuAchievements() {
		return this.stuAchievements;
	}

	public void setStuAchievements(Integer stuAchievements) {
		this.stuAchievements = stuAchievements;
	}

	public Timestamp getBegintime() {
		return this.begintime;
	}

	public void setBegintime(Timestamp begintime) {
		this.begintime = begintime;
	}

	public Timestamp getEndtime() {
		return this.endtime;
	}

	public void setEndtime(Timestamp endtime) {
		this.endtime = endtime;
	}

}