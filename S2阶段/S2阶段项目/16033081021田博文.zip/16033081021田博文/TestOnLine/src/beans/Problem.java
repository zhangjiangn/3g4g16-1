package beans;

/**
 * Problem entity. @author MyEclipse Persistence Tools
 */

public class Problem implements java.io.Serializable {

	// Fields

	private Integer proId;
	private Direction direction;
	private String proType;
	private String proName;
	private String probA;
	private String probB;
	private String probC;
	private String probD;
	private String proAnswer;
	private String proDiff;
	private String proChapter;
	private Integer subId;
	private Integer staId;

	// Constructors

	/** default constructor */
	public Problem() {
	}

	/** minimal constructor */
	public Problem(Integer proId, String proType, String proName, String probA,
			String probB, String probC, String probD, String proAnswer,
			String proDiff, String proChapter, Integer subId) {
		this.proId = proId;
		this.proType = proType;
		this.proName = proName;
		this.probA = probA;
		this.probB = probB;
		this.probC = probC;
		this.probD = probD;
		this.proAnswer = proAnswer;
		this.proDiff = proDiff;
		this.proChapter = proChapter;
		this.subId = subId;
	}

	/** full constructor */
	public Problem(Integer proId, Direction direction, String proType,
			String proName, String probA, String probB, String probC,
			String probD, String proAnswer, String proDiff, String proChapter,
			Integer subId, Integer staId) {
		this.proId = proId;
		this.direction = direction;
		this.proType = proType;
		this.proName = proName;
		this.probA = probA;
		this.probB = probB;
		this.probC = probC;
		this.probD = probD;
		this.proAnswer = proAnswer;
		this.proDiff = proDiff;
		this.proChapter = proChapter;
		this.subId = subId;
		this.staId = staId;
	}

	// Property accessors

	public Integer getProId() {
		return this.proId;
	}

	public void setProId(Integer proId) {
		this.proId = proId;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public String getProType() {
		return this.proType;
	}

	public void setProType(String proType) {
		this.proType = proType;
	}

	public String getProName() {
		return this.proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getProbA() {
		return this.probA;
	}

	public void setProbA(String probA) {
		this.probA = probA;
	}

	public String getProbB() {
		return this.probB;
	}

	public void setProbB(String probB) {
		this.probB = probB;
	}

	public String getProbC() {
		return this.probC;
	}

	public void setProbC(String probC) {
		this.probC = probC;
	}

	public String getProbD() {
		return this.probD;
	}

	public void setProbD(String probD) {
		this.probD = probD;
	}

	public String getProAnswer() {
		return this.proAnswer;
	}

	public void setProAnswer(String proAnswer) {
		this.proAnswer = proAnswer;
	}

	public String getProDiff() {
		return this.proDiff;
	}

	public void setProDiff(String proDiff) {
		this.proDiff = proDiff;
	}

	public String getProChapter() {
		return this.proChapter;
	}

	public void setProChapter(String proChapter) {
		this.proChapter = proChapter;
	}

	public Integer getSubId() {
		return this.subId;
	}

	public void setSubId(Integer subId) {
		this.subId = subId;
	}

	public Integer getStaId() {
		return this.staId;
	}

	public void setStaId(Integer staId) {
		this.staId = staId;
	}

}