package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Stage entity. @author MyEclipse Persistence Tools
 */

public class Stage implements java.io.Serializable {

	// Fields

	private Integer staId;
	private Direction direction;
	private String staName;
	private Set subjects = new HashSet(0);
	

	// Constructors

	/** default constructor */
	public Stage() {
	}

	/** minimal constructor */
	public Stage(Integer staId, Direction direction) {
		this.staId = staId;
		this.direction = direction;
	}

	/** full constructor */
	public Stage(Integer staId, Direction direction, String staName,
			Set subjects) {
		this.staId = staId;
		this.direction = direction;
		this.staName = staName;
		this.subjects = subjects;
	}

	// Property accessors

	public Integer getStaId() {
		return this.staId;
	}

	public void setStaId(Integer staId) {
		this.staId = staId;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public String getStaName() {
		return this.staName;
	}

	public void setStaName(String staName) {
		this.staName = staName;
	}

	public Set getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Set subjects) {
		this.subjects = subjects;
	}

}