package beans;

public class DemoBean {

}
