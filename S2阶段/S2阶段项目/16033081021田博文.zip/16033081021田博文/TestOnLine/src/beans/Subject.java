package beans;

/**
 * Subject entity. @author MyEclipse Persistence Tools
 */

public class Subject implements java.io.Serializable {

	// Fields

	private Integer subId;
	private Direction direction;
	private String subName;
	private Integer staId;

	// Constructors

	/** default constructor */
	public Subject() {
	}

	/** minimal constructor */
	public Subject(Integer subId, String subName, Integer staId) {
		this.subId = subId;
		this.subName = subName;
		this.staId = staId;
	}

	/** full constructor */
	public Subject(Integer subId, Direction direction, String subName,
			Integer staId) {
		this.subId = subId;
		this.direction = direction;
		this.subName = subName;
		this.staId = staId;
	}

	// Property accessors

	public Integer getSubId() {
		return this.subId;
	}

	public void setSubId(Integer subId) {
		this.subId = subId;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public String getSubName() {
		return this.subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	public Integer getStaId() {
		return this.staId;
	}

	public void setStaId(Integer staId) {
		this.staId = staId;
	}

}