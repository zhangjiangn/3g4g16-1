package beans;

/**
 * Teacher entity. @author MyEclipse Persistence Tools
 */

public class Teacher implements java.io.Serializable {

	// Fields

	private Integer teacId;
	private String teacName;
	private String teacPwd;

	// Constructors

	/** default constructor */
	public Teacher() {
	}

	/** minimal constructor */
	public Teacher(Integer teacId) {
		this.teacId = teacId;
	}

	/** full constructor */
	public Teacher(Integer teacId, String teacName, String teacPwd) {
		this.teacId = teacId;
		this.teacName = teacName;
		this.teacPwd = teacPwd;
	}

	// Property accessors

	public Integer getTeacId() {
		return this.teacId;
	}

	public void setTeacId(Integer teacId) {
		this.teacId = teacId;
	}

	public String getTeacName() {
		return this.teacName;
	}

	public void setTeacName(String teacName) {
		this.teacName = teacName;
	}

	public String getTeacPwd() {
		return this.teacPwd;
	}

	public void setTeacPwd(String teacPwd) {
		this.teacPwd = teacPwd;
	}

}