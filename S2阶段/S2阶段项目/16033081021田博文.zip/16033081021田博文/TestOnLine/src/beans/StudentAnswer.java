package beans;

/**
 * StudentAnswer entity. @author MyEclipse Persistence Tools
 */

public class StudentAnswer implements java.io.Serializable {

	// Fields

	private Integer swid;
	private Classes classes;
	private TestPaper testPaper;
	private Problem problem;
	private String stuAnswer;
	private Integer endTestState;

	// Constructors

	/** default constructor */
	public StudentAnswer() {
	}

	/** minimal constructor */
	public StudentAnswer(Integer swid, Classes classes, TestPaper testPaper,
			Problem problem) {
		this.swid = swid;
		this.classes = classes;
		this.testPaper = testPaper;
		this.problem = problem;
	}

	/** full constructor */
	public StudentAnswer(Integer swid, Classes classes, TestPaper testPaper,
			Problem problem, String stuAnswer, Integer endTestState) {
		this.swid = swid;
		this.classes = classes;
		this.testPaper = testPaper;
		this.problem = problem;
		this.stuAnswer = stuAnswer;
		this.endTestState = endTestState;
	}

	// Property accessors

	public Integer getSwid() {
		return this.swid;
	}

	public void setSwid(Integer swid) {
		this.swid = swid;
	}

	public Classes getClasses() {
		return this.classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Problem getProblem() {
		return this.problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

	public String getStuAnswer() {
		return this.stuAnswer;
	}

	public void setStuAnswer(String stuAnswer) {
		this.stuAnswer = stuAnswer;
	}

	public Integer getEndTestState() {
		return this.endTestState;
	}

	public void setEndTestState(Integer endTestState) {
		this.endTestState = endTestState;
	}

}