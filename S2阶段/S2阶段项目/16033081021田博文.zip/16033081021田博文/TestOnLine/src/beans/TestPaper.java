package beans;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * TestPaper entity. @author MyEclipse Persistence Tools
 */

public class TestPaper implements java.io.Serializable {

	// Fields

	private Integer testId;
	private Subject subject;
	private String testType;
	private String testSubjectName;
	private String testTitle;
	private String testClass;
	private String testTime;
	private String testState;
	private Integer testSumScore;
	private Double testOneScore;
	private Timestamp beginTime;
	private Set wrongProblems = new HashSet(0);
	private Set stuAchievementses = new HashSet(0);
	private Set testPaperProblems = new HashSet(0);
	private Set studentAnswers = new HashSet(0);

	// Constructors

	/** default constructor */
	public TestPaper() {
	}

	/** minimal constructor */
	public TestPaper(Integer testId, Subject subject, String testType,
			String testSubjectName, String testTitle, String testTime,
			String testState) {
		this.testId = testId;
		this.subject = subject;
		this.testType = testType;
		this.testSubjectName = testSubjectName;
		this.testTitle = testTitle;
		this.testTime = testTime;
		this.testState = testState;
	}

	/** full constructor */
	public TestPaper(Integer testId, Subject subject, String testType,
			String testSubjectName, String testTitle, String testClass,
			String testTime, String testState, Integer testSumScore,
			Double testOneScore, Timestamp beginTime, Set wrongProblems,
			Set stuAchievementses, Set testPaperProblems, Set studentAnswers) {
		this.testId = testId;
		this.subject = subject;
		this.testType = testType;
		this.testSubjectName = testSubjectName;
		this.testTitle = testTitle;
		this.testClass = testClass;
		this.testTime = testTime;
		this.testState = testState;
		this.testSumScore = testSumScore;
		this.testOneScore = testOneScore;
		this.beginTime = beginTime;
		this.wrongProblems = wrongProblems;
		this.stuAchievementses = stuAchievementses;
		this.testPaperProblems = testPaperProblems;
		this.studentAnswers = studentAnswers;
	}

	// Property accessors

	public Integer getTestId() {
		return this.testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getTestType() {
		return this.testType;
	}

	public void setTestType(String testType) {
		this.testType = testType;
	}

	public String getTestSubjectName() {
		return this.testSubjectName;
	}

	public void setTestSubjectName(String testSubjectName) {
		this.testSubjectName = testSubjectName;
	}

	public String getTestTitle() {
		return this.testTitle;
	}

	public void setTestTitle(String testTitle) {
		this.testTitle = testTitle;
	}

	public String getTestClass() {
		return this.testClass;
	}

	public void setTestClass(String testClass) {
		this.testClass = testClass;
	}

	public String getTestTime() {
		return this.testTime;
	}

	public void setTestTime(String testTime) {
		this.testTime = testTime;
	}

	public String getTestState() {
		return this.testState;
	}

	public void setTestState(String testState) {
		this.testState = testState;
	}

	public Integer getTestSumScore() {
		return this.testSumScore;
	}

	public void setTestSumScore(Integer testSumScore) {
		this.testSumScore = testSumScore;
	}

	public Double getTestOneScore() {
		return this.testOneScore;
	}

	public void setTestOneScore(Double testOneScore) {
		this.testOneScore = testOneScore;
	}

	public Timestamp getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(Timestamp beginTime) {
		this.beginTime = beginTime;
	}

	public Set getWrongProblems() {
		return this.wrongProblems;
	}

	public void setWrongProblems(Set wrongProblems) {
		this.wrongProblems = wrongProblems;
	}

	public Set getStuAchievementses() {
		return this.stuAchievementses;
	}

	public void setStuAchievementses(Set stuAchievementses) {
		this.stuAchievementses = stuAchievementses;
	}

	public Set getTestPaperProblems() {
		return this.testPaperProblems;
	}

	public void setTestPaperProblems(Set testPaperProblems) {
		this.testPaperProblems = testPaperProblems;
	}

	public Set getStudentAnswers() {
		return this.studentAnswers;
	}

	public void setStudentAnswers(Set studentAnswers) {
		this.studentAnswers = studentAnswers;
	}

}