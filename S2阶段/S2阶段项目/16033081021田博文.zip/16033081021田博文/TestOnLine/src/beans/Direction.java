package beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Direction entity. @author MyEclipse Persistence Tools
 */

public class Direction implements java.io.Serializable {

	// Fields

	private Integer direId;
	private String dname;
	private Set stages = new HashSet(0);

	// Constructors

	/** default constructor */
	public Direction() {
	}

	/** minimal constructor */
	public Direction(Integer direId) {
		this.direId = direId;
	}

	/** full constructor */
	public Direction(Integer direId, String dname, Set stages) {
		this.direId = direId;
		this.dname = dname;
		this.stages = stages;
	}

	// Property accessors

	public Integer getDireId() {
		return this.direId;
	}

	public void setDireId(Integer direId) {
		this.direId = direId;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public Set getStages() {
		return this.stages;
	}

	public void setStages(Set stages) {
		this.stages = stages;
	}

}