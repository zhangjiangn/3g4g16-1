package dao;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import beans.Direction;
import beans.Problem;
import beans.Subject;

import daoInter.DaoInter;



import jxl.Sheet;
import jxl.Workbook;

public class ExcelDao {

     	/**
         * ��ѯָ��Ŀ¼�е��ӱ��������е�����
         * @param file �ļ�����·��
         * @return
         */
        public static List<Object[]> getAllByExcel(String file){
        	DaoInter dao=new DaoImpl();
            List<Object[]> list=new ArrayList<Object[]>();
            try {
                Workbook rwb=Workbook.getWorkbook(new File(file));
                Sheet rs=rwb.getSheet(0);//����rwb.getSheet(0)
                int clos=rs.getColumns();//�õ����е���
                int rows=rs.getRows();//�õ����е���
                
                System.out.println("clos"+clos+" rows:"+rows);
                for (int i = 1; i < rows; i++) {
                    for (int j = 0; j < clos; j++) {
                        //��һ�����������ڶ���������
                        String a1=rs.getCell(j++, i).getContents();//Ĭ������߱��Ҳ��һ�� ���������j++  ��Ŀ��
                        String a2=rs.getCell(j++, i).getContents();//��˫ѡ
                        String a3=rs.getCell(j++, i).getContents();//��Ŀ����
                        String a4=rs.getCell(j++, i).getContents();//ѡ��A
                        String a5=rs.getCell(j++, i).getContents();//ѡ��B
                        String a6=rs.getCell(j++, i).getContents();//ѡ��C
                        String a7=rs.getCell(j++, i).getContents();//ѡ��D
                        String a8=rs.getCell(j++, i).getContents();//��ȷ��
                        String a9=rs.getCell(j++, i).getContents();//�Ѷ�
                        String a10=rs.getCell(j++, i).getContents();//�½�
                        Subject subject=new Subject();
                        subject=dao.findSubjectBysubName(a1);
                        int direId=subject.getDirection().getDireId();
                        int staId=subject.getStaId();
                        Direction direction=new Direction();
                        direction.setDireId(direId);
                        Problem problem=new Problem();
                        problem.setProType(a2);
                        problem.setProName(a3);
                        problem.setProbA(a4);
                        problem.setProbB(a5);
                        problem.setProbC(a6);
                        problem.setProbD(a7);
                        problem.setProAnswer(a8);
                        problem.setProDiff(a9);
                        problem.setProChapter(a10);
                        problem.setStaId(staId);
                        problem.setDirection(direction);
                        problem.setSubId(subject.getSubId());
                        dao.addProblem(problem);
                        
                    }
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
            return list;
            
        }
    }
