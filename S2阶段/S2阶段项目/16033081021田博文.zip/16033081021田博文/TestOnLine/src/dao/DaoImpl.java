package dao;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import beans.Admin;
import beans.Classes;
import beans.Direction;
import beans.Problem;
import beans.Stage;
import beans.StuAchievements;
import beans.Student;
import beans.StudentAnswer;
import beans.Teacher;
import beans.TestPaper;
import beans.TestPaperProblem;
import beans.Users;
import beans.WrongProblem;
import daoInter.DaoInter;
import beans.Subject;;

public class DaoImpl implements DaoInter {

	public Admin findAdmin(Users users) {

		return (Admin)session.createQuery("from Admin where aName='"+users.getUname()+"' and aPwd='"+users.getPwd()+"'").uniqueResult();
	}

	public Student findStudent(Users users) {
		
		return (Student)session.createQuery("from Student where stuName='"+users.getUname()+"' and stuPwd='"+users.getPwd()+"'").uniqueResult();
	}
	public Teacher findTeacher(Users users) {		
		
		return (Teacher)session.createQuery("from Teacher where teacName='"+users.getUname()+"' and teacPwd='"+users.getPwd()+"'").uniqueResult();
	}
	public List<Direction> findDirection( ){		
		
		return session.createQuery("from Direction").list();
	}

	public List<Stage> findStage(Direction direction){
		int direId=direction.getDireId();
		return session.createQuery("from Stage where direId="+direId).list();
	}
	public List<Object[]> findAllProblemByDireAndSta(){
		String hql="select sub.subName,count(pro.proName) from Problem pro,Subject sub where sub.subId=pro.subId and pro.direction.direId=1 and pro.staId=1 and pro.subId in(select subId from Subject sub where sub.direction.direId=1 and sub.staId=1) group by sub.subName)";
		Query query=session.createQuery(hql);
		return query.list();
	}
	public String findStaName1() {
		String staNames="select staName from Stage where direId=1 and staId=1";
		Query query=session.createQuery(staNames);
		return (String)query.uniqueResult();
	}
	public String findStaName(Direction direction, Stage stage) {
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		String staNames="select staName from Stage where direId="+direId+" and staId="+staId+"";
		Query query=session.createQuery(staNames);
		return (String)query.uniqueResult();
	}
	public List<Object[]> findProIdAndSubName(Direction direction, Stage stage){
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		System.out.println("direId=---"+direId+"---staId=--"+staId);
		String hql="select sub.subName,count(pro.proName) from Problem pro,Subject sub where sub.subId=pro.subId and pro.direction.direId="+direId+" and pro.staId="+staId+" and pro.subId in(select subId from Subject sub where sub.direction.direId="+direId+" and sub.staId="+staId+") group by sub.subName)";
		String hql1="select sub.subName,count(proId) from Problem pro,Subject sub where pro.subId=sub.subId and pro.subId in(select subId from Subject sub where sub.direction.direId="+direId+" and sub.staId="+staId+") and pro.direction.direId="+direId+" and pro.staId="+staId+" group by sub.subName";
		Query query=session.createQuery(hql1);
		return query.list();
	}
	public List<Object[]> findAllProblem(int staId,int direId,String subName,int fenye){
		
		String hql="select pro.proType,pro.proName,pro.probA,pro.probB,pro.probC,pro.probD,pro.proAnswer,pro.proDiff,pro.proChapter,pro.proId from Problem pro,Subject sub where pro.subId=sub.subId and sub.subName='"+subName+"' and pro.direction.direId="+direId+" and pro.staId="+staId+" order by proId desc";
		Query query=session.createQuery(hql);
		query.setFirstResult(fenye);
		query.setMaxResults(5);
		return query.list();
	}
	public List<Object[]> findProblemCount(int staId,int direId,String subName){
		String hql="select pro.proType,pro.proName,pro.probA,pro.probB,pro.probC,pro.probD,pro.proAnswer,pro.proDiff,pro.proChapter from Problem pro,Subject sub where pro.subId=sub.subId and sub.subName='"+subName+"' and pro.direction.direId="+direId+" and pro.staId="+staId;
		
		
		return session.createQuery(hql).list();
	}
	public int addProblem(Problem problem,int direId){
		int i=0;
		try {
			session.beginTransaction();
			
			Direction direction=new Direction();
			direction.setDireId(direId);
			problem.setDirection(direction);
			session.save(problem);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		
		return i;
	}
	public int addProblem(Problem problem){
		int i=0;
		
		try {
			session.beginTransaction();
			System.out.println("���ӳɹ���");
			session.save(problem);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("����ʧ�ܣ�");
			e.printStackTrace();
			i=1;
		}
		
		return i;
	}
	public int findSubIdBySubName(int staId,int direId,String subName){
		
		
		return (Integer)session.createQuery("select subId from Subject where subName='"+subName+"' and staId="+staId+" and direId="+direId).uniqueResult(); 
	}
	public Problem findProblemByProId(Problem problem){
		int proId=problem.getProId();
		String hql="from Problem where proId="+proId;
		Query query=session.createQuery(hql);
		
		return (Problem)query.uniqueResult();
	}
	public int updateProblem(Problem problem){
		int i=0;
		try {
			session.beginTransaction();
			Problem p=(Problem)session.get(Problem.class,problem.getProId());
			p.setProAnswer(problem.getProAnswer());
			p.setProbA(problem.getProbA());
			p.setProbB(problem.getProbB());
			p.setProbC(problem.getProbC());
			p.setProbD(problem.getProbD());
			p.setProChapter(problem.getProChapter());
			p.setProDiff(problem.getProDiff());
			p.setProName(problem.getProName());
			p.setProType(problem.getProType());
			session.update(p);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		
		return i;
	}

	public List<Stage> findStageById(int direId){

		return session.createQuery("from Stage where direId="+direId).list();
	}
	public List<Object[]> findAllTestPaper(){
		
		Query query=session.createQuery("select t.testId,t.testType,t.testSubjectName,t.testTitle,t.testClass,t.testTime,t.testState,t.subject.subId from TestPaper t order by t.testId desc");
		
		
		
		return query.list();
	}
	public List<Object[]> findTestPaperByChoose(TestPaper testPaper,Direction direction,Stage stage,Subject subject){
		String testType=testPaper.getTestType();
		String testState=testPaper.getTestState();
		int subId=subject.getSubId();
		int direId=direction.getDireId();
		int staId=stage.getStaId();
		System.out.println("testPaper===="+testPaper.getTestId());
		String hql="select t.testId,t.testType,t.testSubjectName,t.testTitle,t.testClass,t.testTime,t.testState,t.subject.subId from TestPaper t where t.subject.subId like '%"+subId+"%' and t.testType like '%"+testType+"%' and t.testState like '%"+testState+"%' order by t.testId desc";
		
		return session.createQuery(hql).list();
	}
	public List<Object[]> findSubjectName(){

		String hql="select s.subId,s.subName from Subject s";
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public List<Object[]> findSubjectName(Direction direction,Stage stage){
		String hql="select s.subId,s.subName from Subject s where direId="+direction.getDireId()+" and staId="+stage.getStaId();
		Query query=session.createQuery(hql);
		return query.list();
	}
	public List<Problem> findProblemByDireIdAndStaIdAndSubId(Direction direction,Stage stage,Subject subject){
		String hql="from Problem pro where pro.direction.direId like '%"+direction.getDireId()+"%' and pro.subId like '%"+subject.getSubId()+"%' and pro.staId like '%"+stage.getStaId()+"%'";
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public int addTestPaper(String testPaperSubName,TestPaper testPaper,Set testPaperProblems){
		int i=0;
		try {
			session.beginTransaction();
			TestPaper testPaper2=testPaper;
			testPaper2.setTestSubjectName(testPaperSubName);
			testPaper2.setTestPaperProblems(testPaperProblems);
			session.save(testPaper2);
			System.out.println("�˷���������");
			session.beginTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			i=1;
		}
		
		return i;
		
	}
	public int addtestPaperProblem(int testId,int proId){
		int i=0;
		try {
			session.beginTransaction();
			
			TestPaperProblem testPaperProblem=new TestPaperProblem();
			Problem p=new Problem();
			TestPaper testPaper=new TestPaper();
			p.setProId(proId);
			testPaper.setTestId(testId);
			testPaperProblem.setProblem(p);
			testPaperProblem.setTestPaper(testPaper);
			session.save(testPaperProblem);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		
		return i;
	}
	
	
	
	public String findDireNameById(Direction direction){

		return (String)session.createQuery("select dname from Direction where direId="+direction.getDireId()).uniqueResult();
	}
	public String findSubNameBySubId(Subject subject){
		
		
		return (String)session.createQuery("select subName from Subject where subId="+subject.getSubId()).uniqueResult(); 
	}
	public String findStaNameByStaId(Stage stage){
		
		return (String)session.createQuery("select staName from Stage where staId="+stage.getStaId()).uniqueResult();
	}
	public List<Object[]> findTestPaperById(int testId){
		
		return session.createQuery("select testSubjectName,testTime,testSumScore from TestPaper where testId="+testId).list();
	}
	public List<Integer> findTestProblemIdBytestId(int testId){
		
		return session.createQuery("select t.problem.proId from TestPaperProblem t where t.testPaper.testId="+testId).list();
	}
	public List<Object[]> findtestProblemByproId(List<Integer> proIds){
		String hql="select proName,probA,probB,probC,probD from Problem where proId in(";
		for (int i = 0; i <= proIds.size(); i++) {
			
			if (i==proIds.size()-1){
				hql+=proIds.get(i);
			}else if (i==proIds.size()) {
				hql+=")";
			}else{
				hql+=proIds.get(i);
				hql+=",";
			}
		}
		System.out.println("��ѯ��䣺"+hql);
		
		
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public List<Classes> findClassName(){
		
		return session.createQuery("from Classes").list();
	}
	public int addClassNameForTestPaper(String claName,int testId){
		int i=0;
		try {
			session.beginTransaction();
		
			TestPaper testPaper=(TestPaper)session.get(TestPaper.class, testId);
			testPaper.setTestClass(claName);
			session.save(testPaper);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		
		return i;
	}
	public int updatetestPaperState(String testState,int testId,Timestamp beginTime){
		int i=0;
		try {
			session.beginTransaction();
		
			TestPaper testPaper=(TestPaper)session.get(TestPaper.class, testId);
			testPaper.setTestState(testState);
			testPaper.setBeginTime(beginTime);
			session.save(testPaper);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			i=1;
		}
		return i;
	}
	public int updatetestPaperStateEnd(int testId){
		int i=0;
		try {
			session.beginTransaction();
		
			TestPaper testPaper=(TestPaper)session.get(TestPaper.class, testId);
			testPaper.setTestState("���Խ���");
			session.save(testPaper);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		
		return i;
	}
	public List<Integer> findAllproId(int direId,int staId,int subId){
		
		
		return session.createQuery("select proId from Problem where direId="+direId+" and staId="+staId+" and subId="+subId).list();
	}
	public List<Problem> findSuijitetsProblem(String nandu,List<Integer> id){
		
		Query query=session.createQuery("from Problem where proName='"+nandu+"' and proId in("+id+")" );
		
		
		
		return query.list();
	}
	public int findClaId(String name,String pwd){

		return (Integer)session.createQuery("select t.classes.claId from Student t where t.stuName='"+name+"' and t.stuPwd="+pwd).uniqueResult();
	}
	public String findClaName(int claId){
		
		return (String)session.createQuery("select claName from Classes where claId="+claId).uniqueResult();
	}
	public List<Object[]> findClaNameAndtestId(){
		
		return session.createQuery("select testId,testClass from TestPaper").list();
	}
	public List<Integer> findtestId(){
		
		return session.createQuery("select testId from TestPaper").list();
	}
	public List<String> findtestClass(){
		
		return session.createQuery("select testClass from TestPaper").list();
	}
	
						  
	public List<Object[]> findtestPaperBytestId(List<Integer> testId){
		String hql="select t.testId,t.testType,t.testSubjectName,t.testTitle,t.testClass,t.testTime from TestPaper t where t.testId in(";
		
		for (int i = 0; i <= testId.size(); i++) {
			
			if (i==testId.size()-1){
				hql+=testId.get(i);
			}else if (i==testId.size()){
				hql+=")";
			}else{
				hql+=testId.get(i);
				hql+=",";
			}
		}
		System.out.println("hql="+hql);
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public List<Object[]> findtestPaperWhenTestOnLine(int testId){
		String hql="select t.testSubjectName,t.testTime,t.testSumScore,count(te.testProId) from TestPaper t,TestPaperProblem te where t.testId=te.testPaper.testId and te.testPaper.testId="+testId+" group by t.testSubjectName,t.testTime,t.testSumScore";
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public List<Integer> findproIdBytestId(int testId){
		
		return session.createQuery("select t.problem.proId from TestPaperProblem t where t.testPaper.testId="+testId).list();
	}
	public List<Problem> findproNameByproId(List<Integer> ids){
		
		String hql="from Problem where proId in(";
		for (int i = 0; i <= ids.size(); i++) {
			
			if (i==0){
				hql+=ids.get(0);
			}else if (i>0&&i<=ids.size()-1){
				hql+="";
			}else if (i==ids.size()) {
				hql+=")";

			}
		}
		System.out.println("hql="+hql);
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public List<Problem> findproNameByproId(int proId){
		
		String hql="from Problem where proId="+proId;
		
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public int addStudentAnswer(int testId,int claId,int proId){
		int i=0;
		try {
			session.beginTransaction();
		
			StudentAnswer studentAnswer=new StudentAnswer();
			Problem problem=new Problem();
			TestPaper testPaper=new TestPaper();
			Classes classes=new Classes();
			
			testPaper.setTestId(testId);
			classes.setClaId(claId);
			studentAnswer.setStuAnswer("*");
			problem.setProId(proId);
			
			studentAnswer.setTestPaper(testPaper);
			studentAnswer.setClasses(classes);
			studentAnswer.setProblem(problem);
			
			session.save(studentAnswer);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			i=1;
		}
		
		
		return i;
	}
	
	public int updateStudentAnswer(int swid,String stuAnswer){
		
		int i=0;
		
		try {
			session.beginTransaction();
		
			StudentAnswer studentAnswer=(StudentAnswer)session.get(StudentAnswer.class, swid);
			studentAnswer.setStuAnswer(stuAnswer);
			session.update(studentAnswer);						
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			i=1;
		}
		
		return i;
	}
	public int findSwidByProIdAndTestId(int proId,int testId){
		
		return (Integer)session.createQuery("select swid from StudentAnswer s where s.problem.proId="+proId+" and s.testPaper.testId="+testId).uniqueResult();
	}
	public int findSumOfSwidByClaIdAndtestId(int claId,int testId){
		String hql="select count(swid) from StudentAnswer s where s.classes.claId="+claId+" and s.testPaper.testId="+testId;
		Query query=session.createQuery(hql);
		Number count = (Number) query.uniqueResult();
		
		return count.intValue();
	}
	public List<StudentAnswer> findStuAnswer(int claId,int testId){
		
		String hql="from StudentAnswer s where s.classes.claId="+claId+" and s.testPaper.testId="+testId;
		System.out.println("hql="+hql);
		Query query=session.createQuery(hql);
		return query.list();
	}
	public List<Integer> findproIdBytestIdAndclaId(int testId,int claId){
		
		
		return session.createQuery("select s.problem.proId from StudentAnswer s where s.testPaper.testId="+testId+" and s.classes.claId="+claId).list();
	}
	public List<Object[]> findproAnswerByproId(List<Integer> ids){
		
		String hql="select p.proAnswer,p.proId from Problem p where p.proId in(";
		for (int i = 0; i <= ids.size(); i++) {
			
			if (i==ids.size()-1){
				hql+=ids.get(i);
			}else if (i==ids.size()){
				hql+=")";
			}else{
				hql+=ids.get(i);
				hql+=",";
			}
		}
		System.out.println("hql="+hql);
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public List<String> findstuAnswerByproId(int testId,int claId){
		
		String hql="select s.stuAnswer from StudentAnswer s where s.testPaper.testId="+testId+" and s.classes.claId="+claId;

		System.out.println("hql="+hql);
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public int findtestOneScoreBytestId(int testId){
		
		String hql="select testOneScore from TestPaper where testId="+testId;
		Query query=session.createQuery(hql);
		Number count = (Number) query.uniqueResult();
		
		
		return count.intValue();
	}
	public int addstuAchievements(int claId,int testId,int sumCount,String subjectName,Timestamp beginTime){
		int i=0;
		try {
			session.beginTransaction();
			
			Date day=new Date();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			StuAchievements achievements=new StuAchievements();
			
			TestPaper testPaper=new TestPaper();
			testPaper.setTestId(testId);
			
			Classes classes=new Classes();
			classes.setClaId(claId);
			
			achievements.setBegintime(beginTime);
			achievements.setStuSubjectName(subjectName);
			achievements.setStuAchievements(sumCount);
			achievements.setEndtime(Timestamp.valueOf(df.format(day)));
			achievements.setClasses(classes);
			achievements.setTestPaper(testPaper);
			
			session.save(achievements);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			i=1;
		}
		
		return i;
	}
	public String findSubjectNameBytestId(int testId){
		
		
		
		return (String)session.createQuery("select testSubjectName from TestPaper where testId="+testId).uniqueResult();
	}
	public List<StuAchievements> findstuAchievement(){
		
		
		return session.createQuery("from StuAchievements").list();
	}
	public String findstuNameByclaId(int claId){
		
		return (String)session.createQuery("select s.stuName from Student s where s.classes.claId="+claId).uniqueResult();
	}
	public TestPaper findtestPaperBytestId(int testId){
		
		return (TestPaper)session.createQuery("from TestPaper where testId="+testId).uniqueResult();
	}
	public List<Object[]> findstuAchievementsByclaIdAndTestId(int claId,int testId){
		
		return session.createQuery("select s.stuAchievements,s.begintime,s.endtime from StuAchievements s where s.testPaper.testId="+testId+" and s.classes.claId="+claId).list();
	}
	public int findSumProblemCount(int testId,int claId){
		
		String hql="select count(swid) from StudentAnswer s where s.testPaper.testId="+testId+" and s.classes.claId="+claId;
		Query query=session.createQuery(hql);
		Number count = (Number) query.uniqueResult();
		return count.intValue();
	}
	public List<Problem> findproolemByproId(List<Integer> proIds){
		
		String hql="from Problem p where p.proId in(";
		for (int i = 0; i <= proIds.size(); i++) {
			
			if (i==proIds.size()-1){
				hql+=proIds.get(i);
			}else if (i==proIds.size()){
				hql+=")";
			}else{
				hql+=proIds.get(i);
				hql+=",";
			}
		}
		System.out.println("hql="+hql);
		Query query=session.createQuery(hql);
		
		return query.list();
	}
	public int addWrongProblem(int testId,int claId,int wrongProId){
		int i=0;
		
		try {
			session.beginTransaction();
			
			Classes classes=new Classes();
			classes.setClaId(claId);
			TestPaper testPaper=new TestPaper();
			testPaper.setTestId(testId);
			WrongProblem wrongProblem=new WrongProblem();
			wrongProblem.setClasses(classes);
			wrongProblem.setTestPaper(testPaper);
			wrongProblem.setWrongProId(wrongProId);
			session.save(wrongProblem);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			i=1;
		}
		
		return i;
	}
	public List<Integer> findWrongProblemBytestId(int testId,int claId){
		
		
		return session.createQuery("select w.wrongProId from WrongProblem w where w.testPaper.testId="+testId+" and w.classes.claId="+claId).list();
	}
	public Timestamp findBeginTimeBytestId(int testId){
		
		return (Timestamp)session.createQuery("select beginTime from TestPaper where testId="+testId).uniqueResult();
	}
	public Timestamp findendTimeBytestIdAndclaId(int testId,int claId){
		
		return (Timestamp)session.createQuery("select s.endtime from StuAchievements s where s.testPaper.testId="+testId+" and s.classes.claId="+claId).uniqueResult();
	}
	public Student findstuNameAndstuPwdByclaId(int claId){
		
		return (Student)session.createQuery("from Student s where s.classes.claId="+claId).uniqueResult();
	}
	public int findSubIdBydireIdAndstaId(int direId,int staId){
		
		
		String hql="select s.subId from Subject s where s.direction.direId="+direId+" and s.staId="+staId;
		Query query=session.createQuery(hql);
		Number count = (Number) query.uniqueResult();
		
		
		return count.intValue();
	}
	public Subject findSubjectBysubName(String subName){
		
		return (Subject)session.createQuery("from Subject where subName='"+subName+"'").uniqueResult();
	}
}
