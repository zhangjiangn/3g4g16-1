package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BaseDao {
	protected Connection con;
	protected PreparedStatement ps;
	protected ResultSet rs;

	public  BaseDao() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url = "jdbc:sqlserver://localhost:1433;databaseName=NewMsg";
			con = DriverManager.getConnection(url, "sa", "123");
		}  catch (Exception e) {
			e.printStackTrace();
		}
	}	
	/**
	 * ��ȡ���ݿ����Ӷ���
	 * @return
	 */
	public Connection getConnection() {
		return con;
	}

	/**
	 * ִ����ɾ�Ĳ���ʹ��
	 * @param sql  ִ�е�sql���
	 * @param parms sql�У���Ӧ�Ĳ�����û�У���null
	 * @return
	 */
	public boolean insert(String sql, Object[] parms) {
		PreparedStatement st = null;
		try {
			st = con.prepareStatement(sql);
			if (parms != null) {
				for (int i = 0; i < parms.length; i++) {
					st.setObject(i + 1, parms[i]);
				}
			}
			int a = st.executeUpdate();
			if (a > 0)
				return true;
		} catch (Exception e) {
			e.printStackTrace();
		throw new RuntimeException(e);
		} finally {
			 //closeAll(null, st, con);
		}
		return false;
	}

	/**
	 * ִ�в�ѯʹ��
	 * @param sql  ִ�е�sql���
	 * @param parms sql�У���Ӧ�Ĳ�����û�У���null
	 * @return
	 */
	public ResultSet select(String sql, Object[] parms) {
		PreparedStatement st = null;
		try {
			 st = con.prepareStatement(sql);
			 if (parms != null) {
					for (int i = 0; i < parms.length; i++) {
						st.setObject(i + 1, parms[i]);
					}
				}
			rs=st.executeQuery();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			 //closeAll(null, st, con);
		}
		return null;
	}
	
	/**
	 * ִ�в�ѯ,���ص���ֵ
	 * @param sql
	 * @return
	 */
	public Object getValue(String sql) {
		PreparedStatement st=null;
		ResultSet rs=null;
		try {
			st = con.prepareStatement(sql);
			rs= st.executeQuery();		
			if (rs.next()) {
				return rs.getObject(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("ִ�в�ѯ����:"+sql);
			throw new RuntimeException(e);
		}
		return null;
	}
	
	
	public void closeAll(ResultSet rs, Statement st, Connection con) {
		try {
			if (rs != null)
				rs.close();
		} catch (SQLException e1) {
		}
		try {
			if (st != null)
				st.close();
		} catch (SQLException e) {
		}
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
		}
	}
}
