create database Student
on(
name ='Studentmdf',
filename='d:\Student.mdf',
size=5,
maxsize=50,
filegrowth=2
)
log on(
name='Studentldf',
filename='d:\Student_log.ldf',
size=3,
maxsize=50,
filegrowth=2
)