package action;

import java.util.List;

import javax.swing.JOptionPane;



import po.Direction;
import po.Paragraph;
import po.Subject;
import po.Writer;
import tools.PageBean;
import biz.StudentLoginBiz;
import biz.WriterListBiz;
import biz.imp.StudentLoginBizImp;
import biz.imp.WriterListBizImp;

public class ListAction {
	private  List<Object[]> objec ;
	private  List<Subject> suList ;
	private Subject subject;
	private  List<Writer>  wriList ;
	private  List<Paragraph> paragraphs ;
	private  List<Direction>  directions;
	private  Writer writer;
	private int sid;
	private int p;
	private int count;
	private  String  pid;
	private  String  did;
	private int id;
	private  Paragraph  par;
	private PageBean pageBean;
	private WriterListBiz biz2 = new WriterListBizImp();
	public String  sufind(){
		paragraphs=biz2.paragraphs();
		directions=biz2.directions();
		if (pid != null && did != null ) {
			int fid = Integer.valueOf(pid);
			int wid = Integer.valueOf(did);
			par = biz2.par(fid);
			System.out.println(par.getPname());
			objec =  biz2.object(Integer.parseInt(pid),Integer.parseInt(did));
		} else {
			System.out.println("yunxingdao3");
			par = biz2.par(1);
			System.out.println("yunxingdao4");
			System.out.println(par.getPname());
			objec =  biz2.object(1,1);
		}
		return "su";

	}
	public String idlist(){
	writer = biz2.idlist(sid);
		return "id";
	}
	public String update(){
		System.out.println(sid);
	int a = biz2.update(writer, sid);
	if (a==1) {
		JOptionPane.showMessageDialog(null, "����ʧ��");
		return "add";
	
	} else {
			pageBean = biz2.pagelist(sid);
			wriList = biz2.wrList(sid,1);
		    pageBean.setP(1);
		
		return "wr";	
	}
		
	}
	public String  wrifind(){
		System.out.println(p+"gongzhemeduoye");
		 if (p<1) {
			 
			pageBean = biz2.pagelist(sid);
			wriList = biz2.wrList(sid,1);
			pageBean.setP(1);
		} else {
		
			pageBean = biz2.pagelist(sid);
			wriList = biz2.wrList(sid,p);
			pageBean.setP(p);
		}
	
		return "wr";

	}
	public String  sfind(){
		subject = biz2.subjects(id);
		return "s";

	}
	public String  addwri(){
		System.out.println(sid);
	
	int	a = biz2.save(writer, sid);
	if (a==1) {
		JOptionPane.showMessageDialog(null, "����ʧ��");
		return "add";
	} else {
			pageBean = biz2.pagelist(sid);
			wriList = biz2.wrList(sid,1);
			pageBean.setP(1);
		return "wr";
		
	}
	}
	public List<Object[]> getObjec() {
		return objec;
	}

	public void setObjec(List<Object[]> objec) {
		this.objec = objec;
	}

	public List<Subject> getSuList() {
		return suList;
	}
	public void setSuList(List<Subject> suList) {
		this.suList = suList;
	}
	public List<Writer> getWriList() {
		return wriList;
	}
	public void setWriList(List<Writer> wriList) {
		this.wriList = wriList;
	}
	public Writer getWriter() {
		return writer;
	}
	public void setWriter(Writer writer) {
		this.writer = writer;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}

	public List<Paragraph> getParagraphs() {
		return paragraphs;
	}

	public void setParagraphs(List<Paragraph> paragraphs) {
		this.paragraphs = paragraphs;
	}

	public List<Direction> getDirections() {
		return directions;
	}

	public void setDirections(List<Direction> directions) {
		this.directions = directions;
	}
	public Paragraph getPar() {
		return par;
	}
	public void setPar(Paragraph par) {
		this.par = par;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public PageBean getPageBean() {
		return pageBean;
	}
	public void setPageBean(PageBean pageBean) {
		this.pageBean = pageBean;
	}

	

}
