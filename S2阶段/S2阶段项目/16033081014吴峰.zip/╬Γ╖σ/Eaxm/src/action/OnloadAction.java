package action;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

public class OnloadAction {
	    private File lodeName;
	    private String lodeNameFileName;
	    private String lodeNameContentType;
	    private String fileName ;
	    private InputStream ism;
		 public String onload(){
			 try {
				 System.out.println(lodeName);
				 String fliepath = ServletActionContext.getServletContext().getRealPath("/")+"upload";
				 System.out.println(fliepath);
				 FileUtils.copyFile(lodeName, new File(fliepath, lodeNameFileName));
				 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "onload";
			 
		 }
		 public String dow(){
			 String fliepath = ServletActionContext.getServletContext().getRealPath("/")+"upload"+fileName;
			 try {
				ism = new FileInputStream(fliepath);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "dow";
		 }
		public File getLodeName() {
			return lodeName;
		}
		public void setLodeName(File lodeName) {
			this.lodeName = lodeName;
		}
		public String getLodeNameFileName() {
			return lodeNameFileName;
		}
		public void setLodeNameFileName(String lodeNameFileName) {
			this.lodeNameFileName = lodeNameFileName;
		}
		public String getLodeNameContentType() {
			return lodeNameContentType;
		}
		public void setLodeNameContentType(String lodeNameContentType) {
			this.lodeNameContentType = lodeNameContentType;
		}
		public String getFileName() {
			return fileName;
		}
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}
		public InputStream getIsm() {
			return ism;
		}
		public void setIsm(InputStream ism) {
			this.ism = ism;
		}


}
