package biz;

import java.util.List;

import po.Answer;
import po.Scores;
import po.Subject;
import po.TestPaper;
import tools.PageBean;

public interface ScoreEaxmBiz {
	public List<TestPaper> list(int sid,int p);
	public List<TestPaper> list(int p);
	public List<Subject> subjects();
	public List<TestPaper> sulist(int sid);
	public List<Scores> scores(int sid,int tid);
	public List<Scores> scores(int tid);
	public Scores sco(int sid);
	public List<Answer> answers(int tid);
	public PageBean pagelist(int sid);
	public PageBean pagelist();
}
