package po;

/**
 * Answer entity. @author MyEclipse Persistence Tools
 */

public class Answer implements java.io.Serializable {

	// Fields

	private Integer aid;
	private TestPaper testPaper;
	private Writer writer;
	private Student student;
	private String stuans;
	private String  state;
	// Constructors

	/** default constructor */
	public Answer() {
	}

	/** minimal constructor */
	public Answer(Integer aid) {
		this.aid = aid;
	}

	/** full constructor */
	public Answer(Integer aid, TestPaper testPaper, Writer writer,
			Student student, String stuans,String  state) {
		this.aid = aid;
		this.testPaper = testPaper;
		this.writer = writer;
		this.student = student;
		this.stuans = stuans;
		this.state = state;
	}

	// Property accessors

	public Integer getAid() {
		return this.aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Writer getWriter() {
		return this.writer;
	}

	public void setWriter(Writer writer) {
		this.writer = writer;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getStuans() {
		return this.stuans;
	}

	public void setStuans(String stuans) {
		this.stuans = stuans;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}