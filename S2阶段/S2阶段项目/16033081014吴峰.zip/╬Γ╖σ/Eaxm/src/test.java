

import java.util.List;
import java.util.Set;

import biz.ScoreEaxmBiz;

import po.Answer;
import po.ST;
import po.TestPaper;
import po.Writer;




import dao.ScoreEaxmDao;
import dao.imp.ScoreEaxmDaoImp;
import dao.imp.StudentEaxmDaoImp;
import dao.imp.TestPaperListDaoImp;
import dao.imp.WriterListDaoImp;


public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		WriterListDaoImp w = new WriterListDaoImp();
		TestPaperListDaoImp t = new TestPaperListDaoImp();
	
		StudentEaxmDaoImp a= new StudentEaxmDaoImp();
		ScoreEaxmDao s = new ScoreEaxmDaoImp();
     
          
}}
