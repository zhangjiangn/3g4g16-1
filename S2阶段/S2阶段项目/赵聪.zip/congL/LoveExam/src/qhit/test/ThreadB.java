package qhit.test;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import qhit.bean.Student;
import qhit.dao.HibernateSessionFactory;

public class ThreadB extends Thread {
	private Session session;
	public ThreadB(){
		
	}
	public void run() {
		session=HibernateSessionFactory.getSession();
		Transaction t=session.getTransaction();
		t.begin();
		Criteria criteria=session.createCriteria(Student.class);
		t.commit();
		for (Object o : criteria.list()) {
			System.out.println(o);
		}
		session.close();
	}
}
