package qhit.dao.implents;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import qhit.bean.PageBean;
import qhit.bean.Paper;
import qhit.bean.Subject;
import qhit.dao.DaoInterface;
import qhit.dao.HibernateSessionFactory;

public class DaoImplents implements DaoInterface {
	private Session session;
	private Transaction transaction;
	//��ѯ����
	public <T>List<T> Select(DetachedCriteria detac) {
		List<T> list=new ArrayList<T>();
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			Criteria criteria=detac.getExecutableCriteria(session);
			list=criteria.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return list;
	}
	
	//ʧ�ܵĲ�ѯ����
	public <T>List<T> allList(Class<T> c,DetachedCriteria detac){
		List<T> list=new ArrayList<T>();
		Criteria criteria;
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			if (detac==null) {
				criteria=session.createCriteria(c);
			} else  {
				criteria=detac.getExecutableCriteria(session);
			} 
			list=criteria.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return list;
	}
	
	//qbcͳ�ƿ�Ŀ����������
	public List<Object[]> subList(String dir,String sta){
		List<Object[]> list=new ArrayList<Object[]>();
		Criteria criteria;
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			criteria=session.createCriteria(Subject.class);
			criteria.createAlias("questions","q",Criteria.LEFT_JOIN);
			criteria.add(Restrictions.eq("direction", dir));
			criteria.add(Restrictions.eq("stage", sta));
			ProjectionList plist=Projections.projectionList();
			plist.add(Projections.groupProperty("subjectname"));
			plist.add(Projections.groupProperty("id"));
			plist.add(Projections.count("q.subject.id"));
			criteria.setProjection(plist);
			list=criteria.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return list;
	}

	//���ӷ���
	public int add(Object o){
		int i=0;
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			session.save(o);
			transaction.commit();
		} catch (Exception e) {
			i=1;
			transaction.rollback();
			e.printStackTrace();
		} finally{
			
		}
		return i;
	}
	
	//���Ӻ󷵻ط���
	public Object addretobj(Object o){
		Object obj=null;
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			session.save(o);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally{
			
		}
		return obj;
	}
	
	//�޸ķ���
	public int update(Object o){
		int i=0;
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			session.update(o);
			transaction.commit();
		} catch (Exception e) {
			i=1;
			transaction.rollback();
			e.printStackTrace();
		} finally{
			
		}
		return i;
	}
	
	//��ҳ����
	public PageBean Pagebean(int p,String hql1,String hql2){
		PageBean pb=new PageBean();
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			Query q=session.createQuery(hql1);
			Integer count=Integer.valueOf(q.uniqueResult().toString());
//			Integer count=(Integer)count;
			pb.setPagesize(4);
			pb.setCount(count);
			pb.setP(p);
			System.out.println(pb.getP());
			Query q1=session.createQuery(hql2);
			List list=q1.setFirstResult((pb.getP()-1)*4).setMaxResults(pb.getPagesize()).list();
			System.out.println(list);
			pb.setData(list);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return pb;
	}
	
	//qbc��ҳ����
	public PageBean qbcPagebean(int p,DetachedCriteria detac1,DetachedCriteria detac2){
		PageBean pb=new PageBean();
		Criteria criteria1;
		Criteria criteria2;
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			criteria1=detac1.getExecutableCriteria(session);
			criteria2=detac2.getExecutableCriteria(session);
			int count=(Integer)criteria1.setProjection(Projections.rowCount()).uniqueResult();
			pb.setPagesize(4);
			pb.setCount(count);
			pb.setP(p);
			List list=criteria2.setFirstResult((pb.getP()-1)*4).setMaxResults(pb.getPagesize()).list();
			pb.setData(list);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return pb;
	}
	
	//��ʾ û��ʹ��
	public List<Paper> showtestpaper(Paper p){
		List<Paper> list=new ArrayList<Paper>();
		Criteria criteria;
		try {
			session=HibernateSessionFactory.getSession();
			transaction=session.getTransaction();
			transaction.begin();
			criteria=session.createCriteria(Paper.class);
			criteria.setFetchMode("subject", FetchMode.JOIN);
			//criteria.setFetchMode("Classer", FetchMode.JOIN);
			criteria.createAlias("subject","s");
			//criteria.createAlias("Classer","c");
			criteria.add(Restrictions.eq("s.id", p.getSubject().getId()));
			criteria.add(Restrictions.eq("kind", p.getKind()));
			criteria.add(Restrictions.eq("state", "���Խ���"));
//			ProjectionList plist=Projections.projectionList();
//			plist.add(Projections.property("kind"));
//			plist.add(Projections.property("s.direction"));
//			plist.add(Projections.property("s.stage"));
//			plist.add(Projections.property("s.subjectname"));
//			plist.add(Projections.property("c.className"));
//			plist.add(Projections.property("testHour"));			
//			criteria.setProjection(plist);
			list=criteria.list();
//			criteria.createAlias("questions","q",Criteria.LEFT_JOIN);
//			criteria.add(Restrictions.eq("direction", dir));
//			criteria.add(Restrictions.eq("stage", sta));
//			ProjectionList plist=Projections.projectionList();
//			plist.add(Projections.groupProperty("subjectname"));
//			plist.add(Projections.groupProperty("id"));
//			plist.add(Projections.count("q.subject.id"));
//			criteria.setProjection(plist);
//			list=criteria.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return list;
	}
		
}
