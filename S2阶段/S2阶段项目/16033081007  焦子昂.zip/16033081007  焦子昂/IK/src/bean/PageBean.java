package bean;

import java.util.List;

public class PageBean {
	//ÿҳ��С
	public Integer pagesize;
	//������
	public Integer count;
	//��ҳ��
	public Integer pagecount;
	//��ǰ�ڼ�ҳ
	public Integer pagenow;
	//��ҳ����
	public List list;
	
	
	
	
	public Integer getPagesize() {
		return pagesize;
	}
	public void setPagesize(Integer pagesize) {
		this.pagesize = pagesize;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Integer getPagecount() {
		return pagecount;
	}
	public void setPagecount(Integer pagecount) {
		this.pagecount = pagecount;
	}
	public Integer getPagenow() {
		return pagenow;
	}
	public void setPagenow(Integer pagenow) {
		this.pagenow = pagenow;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	
	
	
	
	}
