package bean;

public class Score {
	private Integer scoid;
	private Student student;
	private Testpaper testpaper;
	private Float scores;
	public Integer getScoid() {
		return scoid;
	}
	public void setScoid(Integer scoid) {
		this.scoid = scoid;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	
	public Testpaper getTestpaper() {
		return testpaper;
	}
	public void setTestpaper(Testpaper testpaper) {
		this.testpaper = testpaper;
	}
	public Float getScores() {
		return scores;
	}
	public void setScores(Float scores) {
		this.scores = scores;
	}

	
	
}
