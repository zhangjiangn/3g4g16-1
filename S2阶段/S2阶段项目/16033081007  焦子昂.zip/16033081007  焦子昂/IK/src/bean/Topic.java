package bean;

import java.util.Set;

public class Topic {
	private Integer tid;
	private String ttype;
	private String level;
	private String content;
	private Subject subject;
	private Answer answer;
	private Set<Testpaper_Topic> settestpaper;
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		
		this.tid = tid;
	}
	public String getTtype() {
		return ttype;
	}
	public void setTtype(String ttype) {
		this.ttype = ttype;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	public Answer getAnswer() {
		return answer;
	}
	public void setAnswer(Answer answer) {
		this.answer = answer;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public Set<Testpaper_Topic> getSettestpaper() {
		return settestpaper;
	}
	public void setSettestpaper(Set<Testpaper_Topic> settestpaper) {
		this.settestpaper = settestpaper;
	}

	

	
	

}
