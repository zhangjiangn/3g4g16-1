package bean;

import java.util.Set;

public class Direction {
	private Integer did;
	private String dname;
	
	
	public Integer getDid() {
		return did;
	}
	public void setDid(Integer did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}


	
	
	
}
