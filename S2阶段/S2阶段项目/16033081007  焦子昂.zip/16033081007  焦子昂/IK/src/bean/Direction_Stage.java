package bean;

import java.util.Set;

public class Direction_Stage {
	private Integer dsid;
	private Direction direction;
	private Stage stage;
	private Set<Subject> setsubject;
	public Integer getDsid() {
		return dsid;
	}
	public void setDsid(Integer dsid) {
		this.dsid = dsid;
	}
	public Direction getDirection() {
		return direction;
	}
	public void setDirection(Direction direction) {
		this.direction = direction;
	}
	public Stage getStage() {
		return stage;
	}
	public void setStage(Stage stage) {
		this.stage = stage;
	}
	public Set<Subject> getSetsubject() {
		return setsubject;
	}
	public void setSetsubject(Set<Subject> setsubject) {
		this.setsubject = setsubject;
	}
	
	
	

}
