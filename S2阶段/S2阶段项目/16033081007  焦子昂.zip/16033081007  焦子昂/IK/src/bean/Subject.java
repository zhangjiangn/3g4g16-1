package bean;

import java.util.Set;

public class Subject {
	private Integer subid;
	private String subname;
	private Set<Direction_Stage> setdirection_stage;
	private Set<Topic> settopic;
	
	public Set<Topic> getSettopic() {
		return settopic;
	}
	public void setSettopic(Set<Topic> settopic) {
		this.settopic = settopic;
	}
	public Integer getSubid() {
		return subid;
	}
	public void setSubid(Integer subid) {
		this.subid = subid;
	}
	public String getSubname() {
		return subname;
	}
	public void setSubname(String subname) {
		this.subname = subname;
	}
	public Set<Direction_Stage> getSetdirection_stage() {
		return setdirection_stage;
	}
	public void setSetdirection_stage(Set<Direction_Stage> setdirection_stage) {
		this.setdirection_stage = setdirection_stage;
	}
	
	

}
