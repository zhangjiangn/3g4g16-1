package dao.implents;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.transform.Transformers;

import bean.Subject;
import bean.Testpaper;

import dao.interfaces.DaoInterface;

public class DaoImplents implements DaoInterface {
	private Session session = HibernateSessionFactory.getSession();

	public List Select(String hql, Object[] object) {

		List list = new ArrayList();
		Query query = session.createQuery(hql);
		if (object != null) {
			for (int i = 0; i < object.length; i++) {
				query.setParameter(i, object[i]);
			}
		}

		Transaction transaction = session.beginTransaction();
		try {
			list = query.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {

		}

		return list;
	}

	public List Select(String hql, Object[] object, Integer maxresult) {

		List list = new ArrayList();
		Query query = session.createQuery(hql);

		if (object != null) {
			for (int i = 0; i < object.length; i++) {
				query.setParameter(i, object[i]);
			}
		}
		query.setMaxResults(maxresult);

		Transaction transaction = session.beginTransaction();
		try {
			list = query.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {

		}

		return list;
	}

	public List SelectSQLQuery(String sql, Object[] object) {

		List list = new ArrayList();
		Query query = session.createSQLQuery(sql);
		if (object != null) {
			for (int i = 0; i < object.length; i++) {
				query.setParameter(i, object[i]);
			}
		}
		query.setResultTransformer(Transformers.aliasToBean(Subject.class));
		Transaction transaction = session.beginTransaction();
		try {

			list = query.list();

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {

		}

		return list;
	}

	public List PagingSelect(String hql, Object[] object, Integer beginpage,
			Integer maxresult) {

		List list = new ArrayList();
		Query query = session.createQuery(hql);
		if (object != null) {
			for (int i = 0; i < object.length; i++) {
				query.setParameter(i, object[i]);
			}
		}
		query.setFirstResult(beginpage);
		query.setMaxResults(maxresult);
		Transaction transaction = session.beginTransaction();
		try {
			list = query.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {

		}

		return list;

	}

	@Override
	public boolean Add(Object object) {
		Transaction transaction = session.beginTransaction();
		try {
			session.save(object);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
			return false;

		} finally {

		}
		return true;
	}

	@Override
	public boolean Update(Object object) {

		Transaction transaction = session.beginTransaction();
		try {
			session.merge(object);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
			return false;

		} finally {

		}
		return true;

	}

	@Override
	public Object Inset(Object object) {

		Transaction transaction = session.beginTransaction();
		Object obj = null;
		try {
			obj = session.save(object);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
			return false;

		} finally {

		}
		return obj;
	}
}
