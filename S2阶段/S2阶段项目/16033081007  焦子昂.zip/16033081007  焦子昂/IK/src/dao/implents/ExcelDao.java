package dao.implents;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import bean.Answer;
import bean.Subject;
import bean.Topic;
import biz.implents.BizImplents;

import jxl.Sheet;
import jxl.Workbook;

public class ExcelDao {

	public static List<Object[]> getAllByExcel(String file) {
		BizImplents bizimplents = new BizImplents();
		List<Object[]> list = new ArrayList<Object[]>();
		try {
			Workbook rwb = Workbook.getWorkbook(new File(file));
			Sheet rs = rwb.getSheet(0);
			int clos = rs.getColumns();
			int rows = rs.getRows();

			System.out.println("clos" + clos + " rows:" + rows);
			for (int i = 1; i < rows; i++) {
				for (int j = 0; j < clos; j++) {

					String a1 = rs.getCell(j++, i).getContents();
					String a2 = rs.getCell(j++, i).getContents();
					String a3 = rs.getCell(j++, i).getContents();
					String a4 = rs.getCell(j++, i).getContents();
					String a5 = rs.getCell(j++, i).getContents();
					String a6 = rs.getCell(j++, i).getContents();
					String a7 = rs.getCell(j++, i).getContents();
					String a8 = rs.getCell(j++, i).getContents();
					String a9 = rs.getCell(j++, i).getContents();

					Topic topic = new Topic();
					Subject subject = (Subject) bizimplents
							.Select("from Subject where subname=?",
									new Object[] { a7 }).get(0);
					topic.setSubject(subject);
					topic.setContent(a1);
					Answer a = new Answer();
					a.setA(a2);
					a.setB(a3);
					a.setC(a4);
					a.setD(a5);
					a.setRightanswer(a6);
					topic.setAnswer(a);
					topic.setLevel(a8);
					topic.setTtype(a9);
					bizimplents.Add(topic);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}
}
