package dao.interfaces;

import java.util.List;

public interface DaoInterface {

	public List Select(String hql,Object[] object);


	public List Select(String hql,Object[] object,Integer maxresult);

	public List PagingSelect(String hql,Object[] object,Integer beginpage,Integer maxresult);

	public List SelectSQLQuery(String sql,Object[] object);

	public boolean Add(Object object);

	public boolean Update(Object object);
	
	public Object Inset(Object object);
}
