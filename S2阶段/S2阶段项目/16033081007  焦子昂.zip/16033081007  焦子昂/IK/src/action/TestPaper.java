package action;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import bean.Classes;
import bean.Direction;
import bean.PageBean;
import bean.Stage;
import bean.Student;
import bean.Subject;
import bean.Testpaper;
import bean.Testpaper_Classes;
import bean.Testpaper_Topic;
import bean.Topic;
import biz.implents.BizImplents;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.ResolverUtil.Test;

public class TestPaper extends ActionSupport {

	private String directionname;
	private String stagename;
	private String subjectname;
	private Integer Identity;
	private List<Direction> listdirection;
	private List<Topic> listtopic;
	private Integer[] topicid;
	private Integer topiccount = 0;
	private PageBean pagebean;
	private String title;
	private Integer time;
	private Double score;
	private Float everonescore;
	private List<Testpaper> listtestpaper;
	private List<Classes> listclasses;
	private String begintime;
	private Integer testpaperid;
	private Set<Integer> classid;
	private List<Testpaper_Classes> listtc;
	private boolean ajax = true;

	public String Main() {
		BizImplents biz = new BizImplents();
		List<Subject> listsubject;
		List<Stage> liststage;
		String sendstagename = "";
		String sendsubjectname = "";
		SelectPaper();
		SelectTestpaper_Classes();

		if (directionname == null || directionname.length() <= 0
				|| ajax == false) {
			listdirection = biz.Select("from Direction", null);
			if (Identity != null && Identity > 0) {
				return "selectionpaper";
			}
			return "paper";
		} else {
			liststage = biz
					.Select(
							"select d.stage from Direction_Stage d where d.direction.dname=?",
							new Object[] { directionname });
			if (stagename == null || stagename.length() <= 0) {
				System.out.println(stagename);
				stagename = liststage.get(0).getSname();
			}
			String sql = "select subject.* from subject where subid in (select subid from subject_direction_stage where dsid= ( select dsid from direction_stage where did=(select did from direction where dname= ? ) and sid=(select sid from stage where sname= ? )))";
			listsubject = biz.SelectSQLQuery(sql, new Object[] { directionname,
					stagename });
			for (int i = 0; i < listsubject.size(); i++) {
				sendsubjectname += listsubject.get(i).getSubname() + ",";
			}
			for (int i = 0; i < liststage.size(); i++) {
				sendstagename += liststage.get(i).getSname() + ",";
			}

			try {
				ServletActionContext.getResponse()
						.setCharacterEncoding("UTF-8");
				ServletActionContext.getResponse().getWriter().write(
						sendstagename + "over," + sendsubjectname);
				ServletActionContext.getResponse().getWriter().flush();
				ServletActionContext.getResponse().getWriter().close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return "paper";
	}

	public String TopicForSubject() {
		BizImplents biz = new BizImplents();
		String sql = "from Topic where subject.subname=?";
		String countsql = "select count(t) from Topic t where t.subject.subname=?";
		Integer[] sum = repeat();
		if (sum != null) {
			topicid = repeat();
		}
		if (subjectname != null) {
			if (pagebean == null || pagebean.getPagenow() <= 0) {
				pagebean = new PageBean();
				pagebean.setPagenow(1);
				pagebean.setPagesize(5);
			}
			pagebean.setPagesize(12);
			List count = biz.Select(countsql, new Object[] { subjectname });
			if (count != null && count.size() > 0) {
				Integer c = Integer.parseInt((count.get(0).toString()));
				Integer b = pagebean.getPagesize();
				Integer pagec = (int) Math.ceil((double) c / (double) b);
				pagebean.setPagecount(pagec);

			}
			pagebean = biz.SelectPageing(sql, new Object[] { subjectname },
					pagebean);
		}
		ajax = false;
		Main();
		return "selectionpaper";
	}

	public String SelectPaper() {
		BizImplents biz = new BizImplents();
		String sql = "from Testpaper ";
		listtestpaper = biz.Select(sql, null);
		return "readytest";
	}

	public String SelectPaperTest() {
		BizImplents biz = new BizImplents();
		HttpSession session = ServletActionContext.getRequest().getSession();
		Student student = (Student) session.getAttribute("users");
		String sql = "from Testpaper where state=? and pid in(select testpaper.pid from Testpaper_Classes where classes.cid=?)";
		listtestpaper = biz.Select(sql, new Object[] { 1,
				student.getClasses().getCid() });
		SelectTestpaper_Classes();
		return "readytest";
	}

	public String SelectTestpaper_Classes() {
		BizImplents biz = new BizImplents();
		String sql = "from Testpaper_Classes";
		listtc = biz.Select(sql, null);
		return "readytest";
	}

	public String SelectClasses() {
		BizImplents biz = new BizImplents();
		String sql = "from Classes";
		listclasses = biz.Select(sql, null);
		return "classes";
	}

	public String BeginExam() {
		BizImplents biz = new BizImplents();

		List list = biz.Select("from Testpaper where pid=?",
				new Object[] { testpaperid });
		Testpaper testpaper = (Testpaper) list.get(0);
		testpaper.setTbegintime(DateFormat(begintime));
		testpaper.setState(1);
		biz.Update(testpaper);
		for (Integer id : classid) {
			List clist = biz.Select("from Classes where cid=?",
					new Object[] { id });
			Classes c = (Classes) clist.get(0);
			Testpaper_Classes tc = new Testpaper_Classes();
			tc.setClasses(c);
			tc.setTestpaper(testpaper);
			biz.Add(tc);
		}
		return "classes";
	}

	public String OverExam() {
		BizImplents biz = new BizImplents();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		Testpaper testp = (Testpaper) biz.Select("from Testpaper where pid=?",
				new Object[] { testpaperid }).get(0);
		testp.setState(2);
		testp.setTendtime(sdf.format(date));
		biz.Update(testp);
		return Main();
	}

	public String DateFormat(String date) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date rdate = null;
		String s = null;
		try {
			rdate = sdf.parse(date);
			s = sdf.format(rdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	public String AddPaper() {
		BizImplents biz = new BizImplents();
		if (title == null || subjectname == null || score == null
				|| time == null || everonescore == null || topicid == null) {
			return TopicForSubject();
		}
		String hqla = "from Subject where subname=?";
		Subject sub = (Subject) biz.Select(hqla, new Object[] { subjectname })
				.get(0);
		Testpaper testpapaer = new Testpaper();
		testpapaer.setSubject(sub);
		testpapaer.setPtype("����");
		testpapaer.setPtitle(title);
		testpapaer.setPtime(time);
		testpapaer.setScore(score);
		testpapaer.setState(0);
		Integer tpid = (Integer) biz.Insert(testpapaer);
		Testpaper ok = (Testpaper) biz.Select("from Testpaper where pid=?",
				new Object[] { tpid }).get(0);
		for (Integer tid : topicid) {
			String hql = "from Topic where tid=?";
			Object[] obj = new Object[] { tid };
			Topic topic = (Topic) biz.Select(hql, obj).get(0);
			Testpaper_Topic ttp = new Testpaper_Topic();
			ttp.setTopic(topic);
			ttp.setTestpaper(ok);
			biz.Add(ttp);
		}
		SelectPaper();
		return "paper";
	}

	public Integer[] repeat() {
		if (topicid == null || topicid.length <= 0) {
			return null;
		}
		List<Integer> list = new ArrayList<Integer>();
		for (Integer id : topicid) {
			if (topicid != null && topicid.length > 0) {
				if (!list.contains(id)) {
					list.add(id);
				}
			}
		}
		return list.toArray(new Integer[list.size()]);

	}

	public String getDirectionname() {
		return directionname;
	}

	public void setDirectionname(String directionname) {
		this.directionname = directionname;
	}

	public String getStagename() {
		return stagename;
	}

	public void setStagename(String stagename) {
		this.stagename = stagename;
	}

	public List<Direction> getListdirection() {
		return listdirection;
	}

	public void setListdirection(List<Direction> listdirection) {
		this.listdirection = listdirection;
	}

	public Integer getIdentity() {
		return Identity;
	}

	public void setIdentity(Integer identity) {
		Identity = identity;
	}

	public String getSubjectname() {
		return subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	public List<Topic> getListtopic() {
		return listtopic;
	}

	public void setListtopic(List<Topic> listtopic) {
		this.listtopic = listtopic;
	}

	public Integer[] getTopicid() {
		return topicid;
	}

	public void setTopicid(Integer[] topicid) {
		this.topicid = topicid;
	}

	public PageBean getPagebean() {
		return pagebean;
	}

	public void setPagebean(PageBean pagebean) {
		this.pagebean = pagebean;
	}

	public Integer getTopiccount() {
		return topiccount;
	}

	public void setTopiccount(Integer topiccount) {
		this.topiccount = topiccount;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getTime() {
		return time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	public Float getEveronescore() {
		return everonescore;
	}

	public void setEveronescore(Float everonescore) {
		this.everonescore = everonescore;
	}

	public List<Testpaper> getListtestpaper() {
		return listtestpaper;
	}

	public void setListtestpaper(List<Testpaper> listtestpaper) {
		this.listtestpaper = listtestpaper;
	}

	public List<Classes> getListclasses() {
		return listclasses;
	}

	public void setListclasses(List<Classes> listclasses) {
		this.listclasses = listclasses;
	}

	public String getBegintime() {
		return begintime;
	}

	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}

	public Integer getTestpaperid() {
		return testpaperid;
	}

	public void setTestpaperid(Integer testpaperid) {
		this.testpaperid = testpaperid;
	}

	public Set<Integer> getClassid() {
		return classid;
	}

	public void setClassid(Set<Integer> classid) {
		this.classid = classid;
	}

	public List<Testpaper_Classes> getListtc() {
		return listtc;
	}

	public void setListtc(List<Testpaper_Classes> listtc) {
		this.listtc = listtc;
	}

}
