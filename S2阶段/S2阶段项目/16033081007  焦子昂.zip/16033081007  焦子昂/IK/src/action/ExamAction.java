package action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import bean.ExamTopic;
import bean.Score;
import bean.Student;
import bean.StudentAnswer;
import bean.Testpaper;
import bean.Testpaper_Topic;
import bean.Topic;
import biz.implents.BizImplents;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import net.sf.json.JSONObject;

public class ExamAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private Testpaper testpaper;
	private Topic topic;
	private StudentAnswer studentAnswer;
	private List<StudentAnswer> liststudentanswer;
	private Student student;
	private String result;
	private String NextOrLast;
	private String testover;

	public String BeginExam() {
		BizImplents biz = new BizImplents();
		Student stu = null;
		Map<String, Object> map = ActionContext.getContext().getSession();
		if (map.containsKey("users")) {
			stu = (Student) map.get("users");
		} else {
			return "loginover";
			}

		String hqlpaper = "from Testpaper where pid=?";
		testpaper = (Testpaper) biz.Select(hqlpaper,
				new Object[] { testpaper.getPid() }).get(0);

		String hql = "from StudentAnswer where student.sid=? and testpaper.pid=?  order by studentaid asc";
		Object[] obj = { stu.getSid(), testpaper.getPid() };
		List<StudentAnswer> list = biz.Select(hql, obj);

		if (list != null && list.size() > 0) {
			if (list.get(0).getSubmit() == 1) {
				testover = "submito";
				TestPaper t = new TestPaper();
				return "submit";
			}
			liststudentanswer = list;
			topic = biz.SelectTopic(list.get(0).getTopic().getTid());
			studentAnswer = list.get(0);
			String surplustime = "select min(surplustime) from StudentAnswer where student.sid=? and testpaper.pid=?";
			Object[] min = { stu.getSid(), testpaper.getPid() };
			Object mintime = biz.Select(surplustime, min).get(0);
			studentAnswer.setSurplustime(Double.valueOf(mintime.toString()));
		}

		else {
			String hqltestpaper = "from Testpaper_Topic where testpaper.pid=?";
			Object[] hqltestpaperparameter = { testpaper.getPid() };
			List<Testpaper_Topic> lista = biz.Select(hqltestpaper,
					hqltestpaperparameter);

			for (int i = 0; i < 5; i++) {
				Collections.shuffle(lista);
				}
			liststudentanswer = new ArrayList<StudentAnswer>();
			for (Testpaper_Topic testpaper_Topic : lista) {

				StudentAnswer stAnswer = new StudentAnswer();
				stAnswer.setStudent(stu);
				stAnswer.setTestpaper(testpaper_Topic.getTestpaper());
				stAnswer.setTopic(testpaper_Topic.getTopic());
				stAnswer.setSubmit(0);
				stAnswer.setSurplustime(testpaper.getPtime() * 1.0);
				Integer studentaid = (Integer) biz.Insert(stAnswer);
				stAnswer.setStudentaid(studentaid);
				liststudentanswer.add(stAnswer);
			}
			topic = biz.SelectTopic(liststudentanswer.get(0).getTopic()
					.getTid());
			studentAnswer = liststudentanswer.get(0);
		}

		return "beginexam";
	}

	public String NextTopic() {
		ExamTopic e = new ExamTopic();
		BizImplents biz = new BizImplents();
		Object[] obj = { studentAnswer.getStudentaid() };
		List CurrentStudentAnswer = biz.Select(
				"from StudentAnswer where studentaid=?", obj);
		StudentAnswer Currentsa = (StudentAnswer) CurrentStudentAnswer.get(0);
		Currentsa.setSanswer(studentAnswer.getSanswer());
		Currentsa.setSurplustime(studentAnswer.getSurplustime());
		biz.Update(Currentsa);
		Object[] parameter = { testpaper.getPid(), student.getSid() };
		List allStudentAnswer = biz.Select(
				"from StudentAnswer where testpaper.pid=? and student.sid=? ",
				parameter);
		for (int i = 0; i < allStudentAnswer.size(); i++) {
			StudentAnswer s = (StudentAnswer) allStudentAnswer.get(i);
			if (s.getStudentaid().equals(studentAnswer.getStudentaid())) {
				if (NextOrLast.equals("next")) {
					studentAnswer = (StudentAnswer) allStudentAnswer.get(i + 1);
				} else {
					studentAnswer = (StudentAnswer) allStudentAnswer.get(i - 1);
				}
				System.out.println(studentAnswer.getStudentaid());
				break;
			}
		}
		if (isEndExam()) {
			e.setOverorno("end");
		}
		e.setStudenaid(studentAnswer.getStudentaid());
		e.setContent(studentAnswer.getTopic().getContent());
		e.setFirstA(studentAnswer.getTopic().getAnswer().getA());
		e.setSecondB(studentAnswer.getTopic().getAnswer().getB());
		e.setThirdC(studentAnswer.getTopic().getAnswer().getC());
		e.setFourthD(studentAnswer.getTopic().getAnswer().getD());
		e.setStudentanswer(studentAnswer.getSanswer());
		e.setType(studentAnswer.getTopic().getTtype());
		JSONObject json = JSONObject.fromObject(e);
		result = json.toString();
		return "nexttopic";
	}

	public String SubmitPaper() {
		BizImplents biz = new BizImplents();
		Integer rightanswernumber = 0;
		Float Eachquestionscore = 0f;
		Float score;
		Student stu;
		Testpaper tp;
		List CurrentStudentAnswer = biz.Select(
				"from StudentAnswer where studentaid=?",
				new Object[] { studentAnswer.getStudentaid() });
		StudentAnswer Currentsa = (StudentAnswer) CurrentStudentAnswer.get(0);
		Currentsa.setSanswer(studentAnswer.getSanswer());
		Currentsa.setSurplustime(studentAnswer.getSurplustime());
		biz.Update(Currentsa);
		List<StudentAnswer> allstudentanswer = biz.Select(
				"from StudentAnswer where student.sid=? and testpaper.pid=? ",
				new Object[] { student.getSid(), testpaper.getPid() });
		stu = (Student) biz.Select("from Student where sid=?",
				new Object[] { student.getSid() }).get(0);
		Eachquestionscore = (float) (allstudentanswer.get(0).getTestpaper()
				.getScore() / (float) allstudentanswer.get(0).getTestpaper()
				.getSettopic().size());
		tp = allstudentanswer.get(0).getTestpaper();
		for (StudentAnswer studentan : allstudentanswer) {
			studentan.setSubmit(1);
			biz.Update(studentan);
			String right = studentan.getTopic().getAnswer().getRightanswer();
			String studentanswer = studentan.getSanswer();
			if (right.equals(studentanswer)) {
				rightanswernumber++;
			}
		}
		score = rightanswernumber * Eachquestionscore;
		java.text.DecimalFormat df = new java.text.DecimalFormat("#.0");
		Score s = new Score();
		score = Float.valueOf(df.format(score));
		s.setScores(score);
		s.setStudent(stu);
		s.setTestpaper(tp);
		biz.Insert(s);
		testover = "over";
		return "submit";
	}

	public boolean isEndExam() {
		BizImplents bizImplents = new BizImplents();
		String hql = "select state from Testpaper where pid=?";
		Integer state = Integer.valueOf(bizImplents.Select(hql,
				new Object[] { testpaper.getPid() }).get(0).toString());
		if (state == 2) {
			return true;
		}
		return false;
	}

	public String getTestover() {
		return testover;
	}

	public void setTestover(String testover) {
		this.testover = testover;
	}

	public Testpaper getTestpaper() {
		return testpaper;
	}

	public void setTestpaper(Testpaper testpaper) {
		this.testpaper = testpaper;
	}

	public Topic getTopic() {
		return topic;
	}

	public void setTopic(Topic topic) {
		this.topic = topic;
	}

	public StudentAnswer getStudentAnswer() {
		return studentAnswer;
	}

	public void setStudentAnswer(StudentAnswer studentAnswer) {
		this.studentAnswer = studentAnswer;
	}

	public List<StudentAnswer> getListstudentanswer() {
		return liststudentanswer;
	}

	public void setListstudentanswer(List<StudentAnswer> liststudentanswer) {
		this.liststudentanswer = liststudentanswer;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getNextOrLast() {
		return NextOrLast;
	}

	public void setNextOrLast(String nextOrLast) {
		NextOrLast = nextOrLast;
	}

}
