package action;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import bean.Direction;
import bean.Direction_Stage;
import bean.Stage;
import bean.Subject;
import bean.Testpaper;
import bean.Testpaper_Topic;
import bean.Topic;
import biz.implents.BizImplents;

import net.sf.json.JSONArray;

public class RandomPaperAction {

	private Direction direction;
	private Stage stage;
	private Subject subject;
	private List<Direction> listdirection;
	private List<Stage> liststage;
	private List<Subject> listsubject;
	private Testpaper testpaper;
	private Integer[] condition;
	private Integer count;
	private String result;

	public String Main() {
		BizImplents bizImplents = new BizImplents();
		String hql = "from Direction";
		listdirection = bizImplents.Select(hql, null);
		return "Main";
	}

	public String ThreeCascade() {
		BizImplents biz = new BizImplents();
		String hql;
		JSONArray json = null;
		if (direction != null) {
			hql = "select ds.stage from Direction_Stage ds where ds.direction.did=? ";
			liststage = biz.Select(hql, new Object[] { direction.getDid() });
			json = JSONArray.fromObject(liststage);
		} else {
			hql = "select ds from Direction_Stage ds where ds.stage.sid=? ";
			List<Direction_Stage> list = biz.Select(hql, new Object[] { stage
					.getSid() });
			Set<Subject> setsubject = list.get(0).getSetsubject();
			List<Subject> listsubject = new ArrayList<Subject>();
			for (Subject s : setsubject) {
				Subject sub = new Subject();
				sub.setSubid(s.getSubid());
				sub.setSubname(s.getSubname());
				listsubject.add(sub);
			}
			json = JSONArray.fromObject(listsubject);
		}

		result = json.toString();
		return "directionstage";
	}

	public String TopicquantityRestrict() {
		BizImplents biz = new BizImplents();
		Integer radioeasy = 0;
		Integer radiomedium = 0;
		Integer radiodifficulty = 0;
		Integer choiceeasy = 0;
		Integer choicemedium = 0;
		Integer choicedifficulty = 0;
		Integer[] Restrict = new Integer[6];
		String hql = "from Subject where subid=?";
		listsubject = biz.Select(hql, new Object[] { subject.getSubid() });
		for (Topic topic : listsubject.get(0).getSettopic()) {
			if (topic.getTtype().equals("��ѡ") && topic.getLevel().equals("��")) {
				radioeasy++;
			} else if (topic.getTtype().equals("��ѡ")
					&& topic.getLevel().equals("�е�")) {
				radiomedium++;
			} else if (topic.getTtype().equals("��ѡ")
					&& topic.getLevel().equals("����")) {
				radiodifficulty++;
			}

			else if (topic.getTtype().equals("��ѡ")
					&& topic.getLevel().equals("��")) {
				choiceeasy++;
			} else if (topic.getTtype().equals("��ѡ")
					&& topic.getLevel().equals("�е�")) {
				choicemedium++;
			} else if (topic.getTtype().equals("��ѡ")
					&& topic.getLevel().equals("����")) {
				choicedifficulty++;
			}

		}
		Restrict[0] = radioeasy;
		Restrict[1] = radiomedium;
		Restrict[2] = radiodifficulty;
		Restrict[3] = choiceeasy;
		Restrict[4] = choicemedium;
		Restrict[5] = choicedifficulty;
		JSONArray json = JSONArray.fromObject(Restrict);
		result = json.toString();
		return "Restrict";
	}

	public Direction getDirection() {
		return direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public List<Direction> getListdirection() {
		return listdirection;
	}

	public void setListdirection(List<Direction> listdirection) {
		this.listdirection = listdirection;
	}

	public List<Stage> getListstage() {
		return liststage;
	}

	public void setListstage(List<Stage> liststage) {
		this.liststage = liststage;
	}

	public List<Subject> getListsubject() {
		return listsubject;
	}

	public void setListsubject(List<Subject> listsubject) {
		this.listsubject = listsubject;
	}

	public Testpaper getTestpaper() {
		return testpaper;
	}

	public void setTestpaper(Testpaper testpaper) {
		this.testpaper = testpaper;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Integer[] getCondition() {
		return condition;
	}

	public void setCondition(Integer[] condition) {
		this.condition = condition;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

}
