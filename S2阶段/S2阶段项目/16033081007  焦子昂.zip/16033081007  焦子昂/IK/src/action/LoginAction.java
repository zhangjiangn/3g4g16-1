package action;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import bean.User;
import biz.implents.BizImplents;
import biz.interfaces.BizInterface;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport{

	private User user;
	public String Login(){	
		BizInterface biz=new BizImplents();
		Object result=null;
		if(user!=null) {
			result=biz.Login(user);			
		}
		if(result!=null) {
			ServletActionContext.getRequest().getSession().setAttribute("users", result);
			ServletActionContext.getRequest().getSession().setAttribute("useres", user);
			ServletActionContext.getRequest().getSession().setMaxInactiveInterval(60*60);
			return "loginok";
			}
		else {
			return "loginfail";
			}		
	}
	
	public String Cancellation() {
		HttpSession session= ServletActionContext.getRequest().getSession();
		if(session.getAttribute("users")!=null) {
			session.removeAttribute("users");
		}
		return "Cancellation";
	}
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
}
