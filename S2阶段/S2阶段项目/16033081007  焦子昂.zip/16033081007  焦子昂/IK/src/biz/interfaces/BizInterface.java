package biz.interfaces;

public interface BizInterface {
	public <T>Object Login(Object obj);

}
