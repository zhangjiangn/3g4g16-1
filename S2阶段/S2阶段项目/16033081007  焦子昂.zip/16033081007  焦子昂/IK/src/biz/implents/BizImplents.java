package biz.implents;

import java.util.ArrayList;
import java.util.List;

import bean.Answer;
import bean.PageBean;
import bean.StudentAnswer;
import bean.Subject;
import bean.Topic;
import bean.User;
import biz.interfaces.BizInterface;

import dao.implents.DaoImplents;
import dao.interfaces.DaoInterface;

public class BizImplents implements BizInterface {
	DaoInterface dao = new DaoImplents();

	public Object Login(Object obj) {
		User user = (User) obj;
		String hql;
		Object[] object = new Object[2];
		List list = null;
		Object object2 = null;

		if (user.getRole().equals("1")) {
			hql = "select s from Student s where s.sname=? and s.spwd=?";
			object[0] = user.getName();
			object[1] = user.getPwd();
			list = dao.Select(hql, object);
		} else if (user.getRole().equals("2")) {
			hql = "select t from Teacher t where t.tname=? and t.tpwd=?";
			object[0] = user.getName();
			object[1] = user.getPwd();
			list = dao.Select(hql, object);
		} else if (user.getRole().equals("4")) {
			hql = "select a from Admin a where a.aname=? and a.apwd=?";
			object[0] = user.getName();
			object[1] = user.getPwd();
			list = dao.Select(hql, object);
		}
		if (list != null && list.size() != 0) {
			object2 = list.get(0);

		}

		return object2;
	}

	public boolean Add(Object topic) {
		boolean add = false;
		add = dao.Add(topic);
		return add;
	}

	public Object Insert(Object topic) {
		Object obj = null;
		obj = dao.Inset(topic);
		return obj;
	}

	public List Select(String hql, Object[] obj) {
		List list = new ArrayList();
		list = dao.Select(hql, obj);
		return list;
	}

	public List Select(String hql, Object[] obj, Integer maxresult) {
		List list = new ArrayList();
		list = dao.Select(hql, obj, maxresult);
		return list;
	}

	public List SelectSQLQuery(String sql, Object[] obj) {
		List list = new ArrayList();
		list = dao.SelectSQLQuery(sql, obj);
		return list;
	}

	public PageBean SelectPageing(String hql, Object[] object, PageBean pagebean) {
		//
		pagebean.setList(dao.PagingSelect(hql, object, (pagebean.pagenow - 1)
				* pagebean.getPagesize(), pagebean.getPagesize()));
		return pagebean;
	}

	public Topic SelectTopic(Integer ID) {
		Topic topic = null;
		Object[] obj = { ID };
		List<Topic> list = dao.Select("from Topic where tid=?", obj);
		if (list != null && list.size() > 0) {
			topic = list.get(0);
		}
		return topic;
	}

	public StudentAnswer SelectStudentAnswer(Integer ID) {
		StudentAnswer studentAnswer = null;
		Object[] obj = { ID };
		List<StudentAnswer> list = dao.Select(
				"from StudentAnswer where studentaid=?", obj);
		if (list != null && list.size() > 0) {
			studentAnswer = list.get(0);
		}
		return studentAnswer;
	}

	public void Update(Topic topic) {
		Answer answer = topic.getAnswer();
		dao.Update(answer);
		dao.Update(topic);

	}

	public void Update(Object object) {
		dao.Update(object);
	}
}
