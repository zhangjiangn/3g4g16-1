package qhit.test;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;

import qhit.bean.Classes;
import qhit.bean.PageBean;
import qhit.bean.Paper;
import qhit.bean.Question;
import qhit.bean.Score;
import qhit.bean.Student;
import qhit.bean.Subject;
import qhit.biz.implents.BizImplents;
import qhit.dao.DaoInterface;
import qhit.dao.HibernateSessionFactory;
import qhit.dao.implents.DaoImplents;

public class Test {
	public void testone(){
//		BizImplents biz=new BizImplents();
//		DaoImplents d=new DaoImplents();
//		Subject s=new Subject();
//		s.setId(1);
//		Paper p=new Paper();
//		p.setSubject(s);
//		p.setKind("����");
//		p.setState("���Խ���");
//		List<Paper> objs=biz.showtestpaper(1,p);
//		for (Paper paper : objs) {
//			System.out.print(paper.getKind()+" ");
//			System.out.print(paper.getSubject().getDirection()+" "+paper.getSubject().getStage()+" "+paper.getSubject().getSubjectname()+" ");
//			System.out.print(paper.getTitle()+" ");
//			for (Classes c : (Set<Classes>)paper.getClasser()) {
//				System.out.print(c.getClassName()+" ");
//			}
//			System.out.println(paper.getTestHour());
//		}
	}
	
	public void testtwo(){
//		BizImplents biz=new BizImplents();
//		Paper p=new Paper();
//		p.setId(1);
//		List<Score> list=biz.showscore(p);
//		for (Score score : list) {
//			System.out.println(score.getStudent().getStuName());
//			System.out.println(score.getBeginTime());
//			System.out.println(score.getEndTime());
//			System.out.println(score.getScore());
//		}
 	}
	
	public void testthree(){
		BizImplents biz=new BizImplents();
		Paper p=new Paper();
		Score s=new Score();
		Student st=new Student();
		Classes c=new Classes();
		
		c.setClassName("3G4G1631");
		st.setClasses(c);
		p.setId(1);
		s.setStudent(st);
		s.setPaper(p);
		List<Score> scores=biz.showscore(s);
		for (Score score : scores) {
			System.out.println(score.getScore());
		}
		
		
	}
	
	public void testfour(){
		BizImplents biz=new BizImplents();
		Subject s=new Subject();
		s.setId(1);
		PageBean pb=biz.qbcshowquestionbysub(1, s);
		for (Question qu : (List<Question>)pb.getData()) {
			System.out.println(qu.getContent());
		}
	}
	
	public static void main(String[] args) {
		Test test=new Test();
		test.testfour();
		
	}

}
