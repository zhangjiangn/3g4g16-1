package qhit.biz.implents;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import qhit.bean.Admin;
import qhit.bean.Classes;
import qhit.bean.PageBean;
import qhit.bean.Paper;
import qhit.bean.Question;
import qhit.bean.Score;
import qhit.bean.Scoredetails;
import qhit.bean.Student;
import qhit.bean.Subject;
import qhit.bean.Teacher;
import qhit.bean.User;
import qhit.biz.BizInterface;
import qhit.dao.DaoInterface;
import qhit.dao.implents.DaoImplents;



public class BizImplents implements BizInterface {
	DaoInterface dao=new DaoImplents();
	//�ж��Ƿ��и��û�
	public  Object Login(Object obj) {
		User user=(User)obj;
		//detac���ڸ�dao�㷽������QBC���߲�ѯ���
		DetachedCriteria detac;
		//list���ڽ���dao�㷽���ķ��ؽ��
		List list=null;
		Object object=null;
		//�жϵ�½�Ľ�ɫ
		//ѧ��
		if(user.getRole()==1) {
			System.out.println(user.getName());
			System.out.println(user.getPwd());
			detac=DetachedCriteria.forClass(Student.class);
			detac.add(Restrictions.eq("stuName", user.getName()));
			detac.add(Restrictions.eq("stuPwd", user.getPwd()));
			list=dao.Select(detac);
		}
		//��ʦ
		else if(user.getRole()==2) {
			detac=DetachedCriteria.forClass(Teacher.class);
			detac.add(Restrictions.eq("tname", user.getName()));
			detac.add(Restrictions.eq("tpwd", user.getPwd()));
			list=dao.Select(detac);
		}
		//����Ա
		else if(user.getRole()==4) {
			detac=DetachedCriteria.forClass(Admin.class);
			detac.add(Restrictions.eq("aname", user.getName()));
			detac.add(Restrictions.eq("apwd", user.getPwd()));
			list=dao.Select(detac);
		}
		//���list��Ϊ�ղ��ҳ��Ȳ�Ϊ0��Ϊ��ֵ�������ڸ��û��㷵��true���򷵻�false
		if(list!=null&&list.size()!=0) {
			object=list.get(0);
		}
		return object;
	}
	
	//��ѯ���з���ķ���
	public <T>List<T> dirList(Class<T> c){
		DetachedCriteria detac=DetachedCriteria.forClass(c);
		detac.setProjection(Projections.groupProperty("direction"));
		//dao.allList(c, detac);
		return dao.allList(c, detac);
	}
	
	//��ѯ�����½׶εķ���
	public <T>List<T> staList(Class<T> c,String dir){
		DetachedCriteria detac=DetachedCriteria.forClass(c);
		detac.add(Restrictions.eq("direction", dir));
		detac.setProjection(Projections.groupProperty("stage"));
		return dao.allList(c, detac);
	}
	
	//�������ⷽ��
	public int addquestion(Question q){
		//���ڱ���ĿĿǰֻ֧�ֱ���  ������ô����Ĭ��ֵΪ����
		q.setKind("����");
		return dao.add(q);
	}
	
	//��ѯ�������ⷽ��
	public Question showoneques(Question q){
		Question qq=new Question();
		DetachedCriteria detac=DetachedCriteria.forClass(Question.class);
		detac.add(Restrictions.eq("id", q.getId()));
		qq=(Question)dao.Select(detac).get(0);
		return qq;
	}
	
	
	
	//�޸����ⷽ��
	public int update(Question q){
		
		return dao.update(q);
	}
	
	//��ѯ����ͽ׶��¿�Ŀ�ķ���
	public List<Object[]> subList(String dir,String sta){
		return dao.subList(dir,sta);
	}

	//��ҳ��ѯ�Ծ����ϵķ���
	public PageBean showtestpaper(String identifer, int p,Paper paper){
		PageBean pb=new PageBean();
		DetachedCriteria detac1=DetachedCriteria.forClass(Paper.class);
		DetachedCriteria detac2=DetachedCriteria.forClass(Paper.class);
		if (paper!=null) {
			detac1.createAlias("subject","s");
			detac1.add(Restrictions.eq("s.id", paper.getSubject().getId()));
			
			detac2.createAlias("subject","s");
			detac2.add(Restrictions.eq("s.id", paper.getSubject().getId()));
			if (paper.getKind()!=null) {
				System.out.println(paper.getKind());
				detac1.add(Restrictions.eq("kind", paper.getKind()));
				detac2.add(Restrictions.eq("kind", paper.getKind()));
			} 
			if (paper.getState()!=null) {
				System.out.println(paper.getState());
				detac1.add(Restrictions.eq("state", paper.getState()));
				detac2.add(Restrictions.eq("state", paper.getState()));
			}
		}
		pb=dao.qbcPagebean(p, detac1, detac2);
		return pb;
	}
	
	//��ѯ�����Ծ��ķ���
	public Paper showonepaper(Paper paper){
		Paper p=new Paper();
		DetachedCriteria detac=DetachedCriteria.forClass(Paper.class);
		detac.add(Restrictions.eq("id", paper.getId()));
		p=(Paper)dao.Select(detac).get(0);
		return p;
	}
	
	//��ѯ���а༶����
	public List<Classes> allclass(){
		DetachedCriteria detac=DetachedCriteria.forClass(Classes.class);
		return dao.Select(detac);
	}
	
	//��ѯһ���༶����byid
	public Classes selclassbyid(Classes classes){
		Classes c=new Classes();
		DetachedCriteria detac=DetachedCriteria.forClass(Classes.class);
		detac.add(Restrictions.eq("id", classes.getId()));
		c=(Classes)dao.Select(detac).get(0);
		return c;
	}
	//��ʼ���Է���
	public int starexam(Paper p,Set<Integer> classid){
		Timestamp begintime=p.getTestTime();
		Paper paper=showonepaper(p);
		paper.setTestTime(begintime);
		paper.setState("������");
		for (Integer i : classid) {
			Classes c=new Classes();
			c.setId(i);
			c=selclassbyid(c);
			paper.getClasser().add(c);
		}
		return dao.update(paper);
	}
	
	//�������Է���
	public int endpaper(Paper p){
		Paper paper=showonepaper(p);
		paper.setState("���Խ���");
		dao.update(paper);
		return 0;
	}
	
	//�ж��Ƿ��������Եķ���
	public Score havascore(Score s){
		Score c=new Score();
		DetachedCriteria detac=DetachedCriteria.forClass(Score.class);
		detac.setFetchMode("paper", FetchMode.JOIN);
		detac.createAlias("paper","p");
		detac.add(Restrictions.eq("p.id", s.getPaper().getId()));
		detac.setFetchMode("student", FetchMode.JOIN);
		detac.createAlias("student","s");
		detac.add(Restrictions.eq("s.id", s.getStudent().getId()));
		List list=dao.Select(detac);
		if (list!=null&&list.size()>0) {
			c=(Score) list.get(0);
			return c;
		} else {
			return null;
		}	
	}
	
	//��ѯ�������������
	public Scoredetails showonescoredet(Scoredetails sd){
		Scoredetails ss=new Scoredetails();
		DetachedCriteria detac=DetachedCriteria.forClass(Scoredetails.class);
		detac.add(Restrictions.eq("id",sd.getId()));
		ss=(Scoredetails)dao.Select(detac).get(0);
		return ss;
	}
	
	//���Ĵ�
	public Scoredetails uptscoredet(Scoredetails sd){
		Scoredetails s=showonescoredet(sd);
		s.setAnswer(sd.getAnswer());
		dao.update(s);
		s=showonescoredet(sd);
		return s;
	}
	
	//��ѯ�����ɼ�����
	public Score showonescoredet(Score sd){
		Score ss=new Score();
		DetachedCriteria detac=DetachedCriteria.forClass(Score.class);
		detac.add(Restrictions.eq("id",sd.getId()));
		ss=(Score)dao.Select(detac).get(0);
		return ss;
	}
	
	//���ĳɼ���
	public Score updscore(Score s){
		Score ss=showonescoredet(s);
		ss.setSurplustime(s.getSurplustime());
		//�޸�ʱ��
		dao.update(ss);
		//�޸ķ���
		sumscore(ss);
		ss=showonescoredet(s);
		return ss;
	}
	//���㿼�Գɼ�
	public Score sumscore(Score s){
		Score ss=showonescoredet(s);
		double meitifenshu=ss.getPaper().getTotalScore()/ss.getPaper().getQnumber();
		int trueque=0;
		for (Scoredetails scoredet : (Set<Scoredetails>)ss.getScoredetailses()) {
			if (scoredet.getAnswer()!=null&&!scoredet.getAnswer().equals("")) {
				if (scoredet.getAnswer().equals(scoredet.getQuestion().getAnswer())) {
					trueque++;
				}
			}
			
		}
		double truesum=trueque;
		double stuscore=meitifenshu*truesum;
		s.setScore(String.valueOf(stuscore));
		dao.update(ss);
		ss=showonescoredet(s);
		return ss;
	}
	
	//���óɼ�����Ϊ���Խ��� ���ý���ʱ��  �����ܷ�
	public int overscore(Score s){
		Score ss=showonescoredet(s);
		Timestamp newdate=new Timestamp(System.currentTimeMillis());
		ss.setEndTime(newdate);
		ss.setSubmit(1);
		dao.update(ss);
		ss=sumscore(ss);
		return 0;
	}
	
	//Ϊ���������ɼ����ͳɼ������
	public Score addscore(Score s,List<Question>questions){
		s.setSubmit(0);
		Timestamp newdate=new Timestamp(System.currentTimeMillis());
		s.setBeginTime(newdate);
		dao.add(s);
		DetachedCriteria detac=DetachedCriteria.forClass(Score.class);
		detac.setFetchMode("paper", FetchMode.JOIN);
		detac.createAlias("paper","p");
		detac.add(Restrictions.eq("p.id", s.getPaper().getId()));
		detac.createAlias("student","ss");
		detac.add(Restrictions.eq("ss.id", s.getStudent().getId()));
		List list=dao.Select(detac);
		if (list!=null&&list.size()>0) {
			Score score=(Score)list.get(0);
			for (Question question : questions) {
				Scoredetails scoredetailes=new Scoredetails();
				scoredetailes.setQuestion(question);
				scoredetailes.setScore(score);
				dao.add(scoredetailes);
				score.getScoredetailses().add(scoredetailes);
			}
			dao.update(score);
			return (Score) dao.Select(detac).get(0);
		}else {
			return null;
		}
		
		
	}
	
	
	//��ʼ���𰸱�
	
	
	//�����Ծ��ķ���
	public int addpaper(Integer[] topicid,Paper p){
		p.setKind("����");
		p.setState("δ����");
		for (int i = 0; i < topicid.length; i++) {
			Question question=new Question();
			question.setId(topicid[i]);
			question=showoneques(question);
			p.getQuestions().add(question);
		}
		return dao.add(p);
	}
	
	//��ѯ�ɼ��ķ���
	public List<Score> showscore(Score s){
		List<Score> list;
		DetachedCriteria detac=DetachedCriteria.forClass(Score.class);
		if (s.getStudent()==null) {
			detac.setFetchMode("paper", FetchMode.JOIN);
			detac.createAlias("paper","p");
			detac.add(Restrictions.eq("p.id", s.getPaper().getId()));
		} else if (s.getStudent().getStuName().equals("")||s.getStudent().getStuName()==null) {
			System.out.println("û������ʱ���ô˷���");
			detac.setFetchMode("paper", FetchMode.JOIN);
			detac.createAlias("paper","p");
			detac.createAlias("student","ss");
			detac.createAlias("ss.classes","c");
			detac.add(Restrictions.eq("c.className",s.getStudent().getClasses().getClassName()));
			detac.add(Restrictions.eq("p.id", s.getPaper().getId()));
		} else if (s.getStudent().getClasses().getClassName()!=null&&!s.getStudent().getStuName().equals("")) {
			System.out.println("������ʱ���ô˷���");
			System.out.println(s.getStudent().getStuName());
			detac.setFetchMode("paper", FetchMode.JOIN);
			detac.createAlias("paper","p");
			detac.createAlias("student","ss");
			detac.createAlias("ss.classes","c");
			detac.add(Restrictions.eq("ss.stuName", s.getStudent().getStuName()));
			detac.add(Restrictions.eq("c.className",s.getStudent().getClasses().getClassName()));
			detac.add(Restrictions.eq("p.id", s.getPaper().getId()));
		} 
		
		list=dao.Select(detac);
		return list;
	}
	
	//��ѯ������Ŀ�ķ���
	public Subject showonesub(Subject s){
		Subject sub=new Subject();
		DetachedCriteria detac=DetachedCriteria.forClass(Subject.class);
		detac.add(Restrictions.eq("id",s.getId()));
		sub=(Subject)dao.Select(detac).get(0);
		return sub;
	}
	
	//��ҳ��ѯ��Ŀ�µ����� �ѱ�����
	public PageBean showquestionbysub(int p,Subject s) {
		PageBean pb=new PageBean();
		String hql1="select count(q.id) from Question q where q.subject.id="+s.getId();
		String hql2="select q from Question q where q.subject.id="+s.getId();
		pb=dao.Pagebean(p,hql1,hql2);
		return pb;
	}
	
	//��ѯ�ɼ�����ķ���
	public Score showScoredetails(Score ss){
		Score s=new Score();
		DetachedCriteria detac=DetachedCriteria.forClass(Score.class);
		detac.add(Restrictions.eq("id",ss.getId()));
		s=(Score)dao.Select(detac).get(0);
		return s;
	}
	
	//qbc��ҳ��ѯ��Ŀ�µ�����
	public PageBean qbcshowquestionbysub(int p,Subject s){
		PageBean pb=new PageBean();
		DetachedCriteria detac1=DetachedCriteria.forClass(Question.class);
		DetachedCriteria detac2=DetachedCriteria.forClass(Question.class);
		if (s!=null) {
			detac1.add(Restrictions.eq("subject.id",s.getId()));
			detac2.add(Restrictions.eq("subject.id",s.getId()));		
		}
		pb=dao.qbcPagebean(p, detac1,detac2);
		
		return pb;
	}
	
//	public PageBean getPbBook(int p) {
//		PageBean pb=new PageBean();
//		Criteria criteria=session.createCriteria(TbBooks.class);
//		int count=(Integer)criteria.setProjection(Projections.rowCount()).uniqueResult();
//		pb.setCount(count);
//		pb.setPagesize(4);
//		pb.setP(p);
//		System.out.println(pb.getP());
//		pb.setData(session.createCriteria(TbBooks.class).addOrder(Order.desc("buytime")).setFirstResult((pb.getP()-1)*4).setMaxResults(pb.getPagesize()).list());
//		return pb;
//	}
	
	

}
	


