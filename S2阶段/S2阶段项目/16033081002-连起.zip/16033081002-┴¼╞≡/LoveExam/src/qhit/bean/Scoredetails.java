package qhit.bean;

/**
 * Scoredetails entity. @author MyEclipse Persistence Tools
 */

public class Scoredetails implements java.io.Serializable {

	// Fields

	private Integer id;
	private Score score;
	private Question question;
	private String answer;
	private String result;

	// Constructors

	/** default constructor */
	public Scoredetails() {
	}

	/** minimal constructor */
	public Scoredetails(Integer id) {
		this.id = id;
	}

	/** full constructor */
	public Scoredetails(Integer id, Score score, Question question,
			String answer, String result) {
		this.id = id;
		this.score = score;
		this.question = question;
		this.answer = answer;
		this.result = result;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Score getScore() {
		return this.score;
	}

	public void setScore(Score score) {
		this.score = score;
	}

	public Question getQuestion() {
		return this.question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getResult() {
		return this.result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}