package qhit.bean;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Paper implements java.io.Serializable {

	// Fields �Ծ�

	private Integer id;//���
	private Subject subject;//��Ŀ
	private String kind;//�Ծ�����
	private String title;//����
	private Timestamp testTime;//����ʱ��
	private Integer testHour;//����ʱ��
	private Double totalScore;//�ܷ�
	private Integer qnumber;//��Ŀ����
	private String state;//״̬
	private Set questions = new HashSet(0);//���⼯��
	private Set scores = new HashSet(0);//�ɼ�����
	private Set Classer = new HashSet(0);//�༶����

	// Constructors

	/** default constructor */
	public Paper() {
	}

	/** minimal constructor */
	

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getKind() {
		return this.kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Timestamp getTestTime() {
		return this.testTime;
	}

	public void setTestTime(Timestamp testTime) {
		this.testTime = testTime;
	}

	public Integer getTestHour() {
		return this.testHour;
	}

	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}

	public Double getTotalScore() {
		return this.totalScore;
	}

	public void setTotalScore(Double totalScore) {
		this.totalScore = totalScore;
	}

	public Integer getQnumber() {
		return this.qnumber;
	}

	public void setQnumber(Integer qnumber) {
		this.qnumber = qnumber;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	

	public Set getQuestions() {
		return questions;
	}

	public void setQuestions(Set questions) {
		this.questions = questions;
	}

	public Set getScores() {
		return this.scores;
	}

	public void setScores(Set scores) {
		this.scores = scores;
	}

	public Set getClasser() {
		return Classer;
	}

	public void setClasser(Set classer) {
		Classer = classer;
	}

	

}