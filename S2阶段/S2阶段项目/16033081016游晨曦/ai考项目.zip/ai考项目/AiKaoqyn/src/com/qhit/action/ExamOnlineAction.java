package com.qhit.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Paper;
import com.qhit.bean.PaperEq;
import com.qhit.bean.Score;
import com.qhit.bean.StuPaperEq;
import com.qhit.bean.Student;
import com.qhit.biz.ExamOnlineBiz;
import com.qhit.biz.impl.ExamOnlineBizImpl;
import com.qhit.util.PageBean;
import com.qhit.util.PaperContent;

public class ExamOnlineAction {
	private ExamOnlineBiz eob = new ExamOnlineBizImpl();
	private int p;
	private PageBean paperPB;
	private ArrayList<Paper> paperList;
	private int pid;
	private int TotalCount;
	private ArrayList pcoList = new ArrayList();
	private ArrayList<PaperEq> peList = new ArrayList<PaperEq>();
	private String stuanswer;
	private int eid;
	private int num;
	private int udValue;
	private String startTime;
	private String finishTime;
	private ArrayList<Score> scoList;
	private Score sco;
	private ArrayList<StuPaperEq> sAnswerAList;
	private int sid;
	//���߿�����ҳ
	public String ExamOnlineIndex(){
		Student  student= (Student) ServletActionContext.getRequest().getSession().getAttribute("student");
		int cid= student.getClasss().getCid();
		int up = 1;
		if (p!=0) up = p;
		paperPB = eob.getPaperByPageBean(up, cid);
		//�и���2018-1-8 11:11:41
		int sid = student.getSid();
		for (Paper paper : (ArrayList<Paper>) paperPB.getData()) {
			int pid = paper.getPid();
			int yn = eob.judgeExam(pid, sid);
			paper.setYn(yn);
			System.out.println("stop");
		}
		
		return "ExamOnlineIndex";
	}
	
	//���߿��� ing
	public String ExamOnlineIng(){
		Student  student= (Student) ServletActionContext.getRequest().getSession().getAttribute("student");
		int sid= student.getSid();
		paperList = eob.getPaperByPid(pid);
		TotalCount = eob.getPaperTotalCountByPid(pid);
		int onOff=1;
		for (int pcid = 1; pcid <= TotalCount; pcid++) {
			PaperContent pco = new PaperContent();
			if (onOff == 1) {
				ArrayList<StuPaperEq> speList = eob.getStuAnswerAll(sid, pid);//��ȡ���ѧ�������д�
				for (StuPaperEq spe : speList) {
					int eid = spe.getExamQuestion().getEid();
					StuPaperEq speHaveAnswer = eob.getStuAnswer(sid, pid, eid);
					String stuanswer =speHaveAnswer.getStuanswer();
					PaperContent pco1 = new PaperContent();
					pco1.setPcid(pcid);
					pco1.setStuanswer(stuanswer);
					pcoList.add(pco1);
					pcid++;
					if (pcid > TotalCount) break;
				}
				onOff = 0;//�ر� 
			}
			pco.setPcid(pcid);
			pco.setStuanswer("*");
			pcoList.add(pco);
		}
		
		//ҳ��ײ�
		ArrayList<PaperEq> paperList = eob.getPaperEqPid(pid);
		PaperEq pe = paperList.get(0);
		pe.setNum(1);
		peList.add(pe);
		
		//��ʼʱ��
		Date date = new Date();
		startTime = eob.getDate(date);
		
		return "ExamOnlineIng";
		
	}
	
	//���߿�����/�·�ҳ
	public String ExamOnlineUpDown(){
		Student  student= (Student) ServletActionContext.getRequest().getSession().getAttribute("student");
		int sid= student.getSid();
		int i = eob.addStuPaperEq(sid, pid, eid, stuanswer);//���Ӵ�
		if (i == 1) {//���Ӵ𰸳ɹ�
			paperList = eob.getPaperByPid(pid);
			TotalCount = eob.getPaperTotalCountByPid(pid);
			//ҳ���в�
			int onOff=1;
			for (int pcid = 1; pcid <= TotalCount; pcid++) {
				PaperContent pco = new PaperContent();
				if (onOff == 1) {
					ArrayList<StuPaperEq> speList = eob.getStuAnswerAll(sid, pid);//��ȡ���ѧ�������д�
					for (StuPaperEq spe : speList) {
						int eid = spe.getExamQuestion().getEid();
						StuPaperEq speHaveAnswer = eob.getStuAnswer(sid, pid, eid);
						String stuanswer =speHaveAnswer.getStuanswer();
						PaperContent pco1 = new PaperContent();
						pco1.setPcid(pcid);
						pco1.setStuanswer(stuanswer);
						pcoList.add(pco1);
						pcid++;
						if (pcid > TotalCount) break;
					}
					onOff = 0;//�ر�
				}
				pco.setPcid(pcid);
				pco.setStuanswer("*");
				pcoList.add(pco);
			}
			//ҳ��ײ�
			if (udValue == 0) {
				num = num+1;
				int peGetNum=num-1;
				ArrayList<PaperEq> paperList = eob.getPaperEqPid(pid);
				PaperEq pe = paperList.get(peGetNum);
				pe.setNum(num);
				peList.add(pe);
			} else {
				num = num-1;
				int peGetNum=num-1;
				ArrayList<PaperEq> paperList = eob.getPaperEqPid(pid);
				PaperEq pe = paperList.get(peGetNum);
				pe.setNum(num);
				peList.add(pe);
			}
			return "ExamOnlineIng";
		}else{
			return null;
		}
	}
	
	public String finishExam(){
		Student  student= (Student) ServletActionContext.getRequest().getSession().getAttribute("student");
		int sid= student.getSid();
		ArrayList<StuPaperEq> speList = eob.getStuAnswerAll(sid, pid);
		ArrayList<Paper> paperList= eob.getPaperByPid(pid);
		Paper paper = paperList.get(0);
		int ptotalScore = Integer.parseInt(paper.getPtotalScore());//�Ծ��ܷ�
		int size = eob.getPaperTotalCountByPid(pid);//�Ծ�������
		int score = eob.getScore(speList, ptotalScore, size);//ѧ������
		Date date1 = new Date();
		finishTime = eob.getDate(date1);
		int i = eob.finishExam(startTime, finishTime, score, pid, sid);
		if (i == 1) {
			return "LookMyPaperScore";
		} else {
			return null;
		}
	}
	
	public String LookMyPaperScore(){
		try {
			Student  student= (Student) ServletActionContext.getRequest().getSession().getAttribute("student");
			sid= student.getSid();
		} catch (Exception e) {
			System.out.println("��������");//�öδ����Ǵ�������ҳ�����󵽸�action�޷���ȡStudent���� ��Ҫ������쳣
		}
		scoList = eob.getStuSocreList(pid,sid);
		sco = scoList.get(0);
		sAnswerAList = eob.getStuAnswerAll(sid, pid);
		TotalCount = eob.getPaperTotalCountByPid(pid);
		int NO = 1;
		for (StuPaperEq  sAAL : sAnswerAList) {
			sAAL.setNO(NO);
			NO++;
		}
		System.out.println(finishTime);
		return "lookMyPaperScore";
		
	}

	public ExamOnlineBiz getEob() {
		return eob;
	}

	public void setEob(ExamOnlineBiz eob) {
		this.eob = eob;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public PageBean getPaperPB() {
		return paperPB;
	}

	public void setPaperPB(PageBean paperPB) {
		this.paperPB = paperPB;
	}

	public ArrayList<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(ArrayList<Paper> paperList) {
		this.paperList = paperList;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getTotalCount() {
		return TotalCount;
	}

	public void setTotalCount(int totalCount) {
		TotalCount = totalCount;
	}

	public ArrayList getPcoList() {
		return pcoList;
	}

	public void setPcoList(ArrayList pcoList) {
		this.pcoList = pcoList;
	}

	public ArrayList<PaperEq> getPeList() {
		return peList;
	}

	public void setPeList(ArrayList<PaperEq> peList) {
		this.peList = peList;
	}

	public String getStuanswer() {
		return stuanswer;
	}

	public void setStuanswer(String stuanswer) {
		this.stuanswer = stuanswer;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getUdValue() {
		return udValue;
	}

	public void setUdValue(int udValue) {
		this.udValue = udValue;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(String finishTime) {
		this.finishTime = finishTime;
	}

	public ArrayList<Score> getScoList() {
		return scoList;
	}

	public void setScoList(ArrayList<Score> scoList) {
		this.scoList = scoList;
	}

	

	public ArrayList<StuPaperEq> getsAnswerAList() {
		return sAnswerAList;
	}

	public void setsAnswerAList(ArrayList<StuPaperEq> sAnswerAList) {
		this.sAnswerAList = sAnswerAList;
	}

	public Score getSco() {
		return sco;
	}

	public void setSco(Score sco) {
		this.sco = sco;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}
	
	
}
