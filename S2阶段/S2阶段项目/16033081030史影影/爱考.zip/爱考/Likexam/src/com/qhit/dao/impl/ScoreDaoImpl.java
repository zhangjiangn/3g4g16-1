package com.qhit.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Paper;
import com.qhit.bean.Score;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.dao.ScoreDao;
import com.qhit.util.PageBean;

public class ScoreDaoImpl implements ScoreDao {

	public ArrayList<Direction> getDirList() {
		String hql = "from Direction";
		Query query = session.createQuery(hql);
		return (ArrayList<Direction>) query.list();
	}

	public ArrayList<Stage> getStageList() {
		String hql = "from Stage";
		Query query = session.createQuery(hql);
		return (ArrayList<Stage>) query.list();
	}

	public ArrayList<Subject> getSubjectList() {
		String hql = "from Subject";
		Query query = session.createQuery(hql);
		return (ArrayList<Subject>) query.list();
	}

	public PageBean getPaperByPageBean(int p, int psubid) {
		PageBean pb = new PageBean();
		Transaction transaction = session.beginTransaction();
		try {
			String hql = "from Paper where psubid=:psubid and ptaid=3";
			Query query = session.createQuery(hql).setCacheable(true);
			query.setInteger("psubid", psubid);
			int count=query.list().size();
			
			pb.setPagesize(5);
			pb.setCount(count);
			pb.setP(p);
			
			query.setFirstResult((p-1)*pb.getPagesize());
			query.setMaxResults(pb.getPagesize());
			List<ExamQuestion> eqList = query.list();
			pb.setData(eqList);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
		}
		return pb;
	}

	public ArrayList<Subject> getSubjectListByDidAndStaid(int subdid,
			int substaid) {
		String hql = "from Subject where subdid=:subdid and substaid=:substaid";
		Query query = session.createQuery(hql);
		query.setInteger("subdid", subdid);
		query.setInteger("substaid", substaid);
		return (ArrayList<Subject>) query.list();
	}

	public ArrayList<Score> getScoreByPid(int pid) {
		String hql = "from Score where scopid=:pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		return (ArrayList<Score>) query.list();
	}

	public ArrayList<Paper> getPaper(int pid) {
		String hql = "from Paper where pid=:pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		return (ArrayList<Paper>) query.list();
	}

	public int getCountBypid(int pid) {
		String hql = "from Score where scopid=:pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		return query.list().size();
	}

	public int getPassCount(int pid) {
		int count =0;
		String hql = "from Score where scopid=:pid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
	 	ArrayList<Score> scoreList = (ArrayList<Score>) query.list();
	 	for (Score sc : scoreList) {
			int score = Integer.parseInt(sc.getScoscore());
			if (score>=60) {
				count++;
			}
		}
		return count;
	}

	public ArrayList<Score> getScoreByPidAndSid(int pid, int sid) {
		String hql = "from Score where scopid=:pid and scosid=:sid";
		Query query = session.createQuery(hql);
		query.setInteger("pid", pid);
		query.setInteger("sid", sid);
		return (ArrayList<Score>) query.list();
	}

	public ArrayList<Student> getStudentsByNameStr(String snameStr) {
		String hql = "from Student where sname like :snameStr";
		Query query = session.createQuery(hql);
		query.setString("snameStr", "%"+snameStr+"%");
		return (ArrayList<Student>) query.list();
	}

	
}
