package com.qhit.biz.impl;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.qhit.bean.Paper;
import com.qhit.bean.PaperEq;
import com.qhit.bean.Score;
import com.qhit.bean.StuPaperEq;
import com.qhit.biz.ExamOnlineBiz;
import com.qhit.dao.ExamOnlineDao;
import com.qhit.dao.impl.ExamOnlineDaoImpl;
import com.qhit.util.DateFormatUtil;
import com.qhit.util.PageBean;

public class ExamOnlineBizImpl implements ExamOnlineBiz {

	private ExamOnlineDao eod = new ExamOnlineDaoImpl();
	private DateFormatUtil  dfu = new DateFormatUtil();
	
	public PageBean getPaperByPageBean(int p, int pcid) {
		return eod.getPaperByPageBean(p, pcid);
	}

	public ArrayList<Paper> getPaperByPid(int pid) {
		return eod.getPaperByPid(pid);
	}

	public int getPaperTotalCountByPid(int pid) {
		return eod.getPaperTotalCountByPid(pid);
	}

	public ArrayList<PaperEq> getPaperEqPid(int pid) {
		return eod.getPaperEqPid(pid);
	}

	public int addStuPaperEq(int sid, int pid, int eid, String stuanswer) {
		return eod.addStuPaperEq(sid, pid, eid, stuanswer);
	}


	public ArrayList<StuPaperEq> getStuAnswerAll(int sid, int pid) {
		return eod.getStuAnswerAll(sid, pid);
	}

	public StuPaperEq getStuAnswer(int sid, int pid, int eid) {
		return eod.getStuAnswer(sid, pid, eid);
	}

	public int getScore(ArrayList<StuPaperEq> speList, int ptotalScore, int size) {
		return eod.getScore(speList, ptotalScore, size);
	}

	

	public String getDate(Date date) {
		// TODO Auto-generated method stub
		return dfu.getDate(date);
	}

	public int finishExam(String startTime, String finishTime, int socre,
			int pid, int sid) {
		// TODO Auto-generated method stub
		return eod.finishExam(startTime, finishTime, socre, pid, sid);
	}

	public ArrayList<Score> getStuSocreList(int pid, int sid) {
		// TODO Auto-generated method stub
		return eod.getStuSocreList(pid, sid);
	}

	public int judgeExam(int pid, int sid) {
		// TODO Auto-generated method stub
		return eod.judgeExam(pid, sid);
	}

}
