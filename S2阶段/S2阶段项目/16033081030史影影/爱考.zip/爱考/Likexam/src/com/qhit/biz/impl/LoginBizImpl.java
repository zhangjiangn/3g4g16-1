package com.qhit.biz.impl;

import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.biz.LoginBiz;
import com.qhit.dao.LoginDao;
import com.qhit.dao.impl.LoginDaoImpl;

public class LoginBizImpl implements LoginBiz {

	private LoginDao ld = new LoginDaoImpl();
	
	public Student getUsersByStu(String name, String pwd) {
		// TODO Auto-generated method stub
		return ld.getUsersByStu(name, pwd);
	}

	public Users getUsersByUsers(String name, String pwd) {
		// TODO Auto-generated method stub
		return ld.getUsersByUsers(name, pwd);
	}

}
