package com.qhit.biz;

import org.hibernate.Session;

import com.qhit.bean.Student;
import com.qhit.bean.Users;
import com.qhit.dao.HibernateSessionFactory;

public interface LoginBiz {
	public Session session = HibernateSessionFactory.getSession();
	public Student getUsersByStu(String name,String pwd);
	public Users getUsersByUsers(String name,String pwd);
}
