package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Classs;
import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Level;
import com.qhit.bean.Paper;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.bean.Tatus;
import com.qhit.biz.PaperBiz;
import com.qhit.dao.PaperDao;
import com.qhit.dao.impl.PaperDaoImpl;
import com.qhit.util.PageBean;

public class PaperBizImpl implements PaperBiz {

	private PaperDao pd = new PaperDaoImpl();
	
	public ArrayList<Direction> getDirList(int order) {
		return pd.getDirList(order);
	}

	public ArrayList<Tatus> getExamTatus(int order) {
		return pd.getExamTatus(order);
	}

	public ArrayList<Paper> getExamType(int order) {
		return pd.getExamType(order);
	}

	public ArrayList<Paper> getPaperById(int pid) {
		return pd.getPaperById(pid);
	}

	public PageBean getPaperByPageBean(int p, int pid) {
		return pd.getPaperByPageBean(p, pid);
	}

	public ArrayList<Stage> getStageList(int order) {
		return pd.getStageList(order);
	}

	public ArrayList<Subject> getSubjectList(int order) {
		return pd.getSubjectList(order);
	}

	public PageBean getPaperByPageBean(int p, String pfirstType) {
		return pd.getPaperByPageBean(p, pfirstType);
	}

	public ArrayList<Subject> getSubjectListByDidAndStaid(int subdid,
			int substaid) {
		return pd.getSubjectListByDidAndStaid(subdid, substaid);
	}

	public PageBean getPaperByPageBeanBySubid(int p, int psubid) {
		return pd.getPaperByPageBeanBySubid(p, psubid);
	}

	public PageBean getPaperByPageBean(int p, int psubid, int ptaid) {
		return pd.getPaperByPageBean(p, psubid, ptaid);
	}

	public PageBean getExamQuestionByPageBean(int p, int esubid) {
		return pd.getExamQuestionByPageBean(p, esubid);
	}

	public int addPaper(Paper paper, int psubid) {
		return pd.addPaper(paper, psubid);
	}

	public int getPaperDescID() {
		return pd.getPaperDescID();
	}

	public int addPaper_EQ(int pid, int eid) {
		return pd.addPaper_EQ(pid, eid);
	}

	public ArrayList<ExamQuestion> getExamQuestionByEqPid(int pid) {
		return pd.getExamQuestionByEqPid(pid);
	}

	public int updateIStart(ArrayList<Paper> paperLists) {
		return pd.updateIStart(paperLists);
	}

	public ArrayList<Classs> getCalsss() {
		return pd.getCalsss();
	}

	public int StartExam(int pid) {
		return pd.StartExam(pid);
	}

	public int FinishExam(int pid) {
		return pd.FinishExam(pid);
	}

	public int deletePaperAndPaperEQ(int pid) {
		// TODO Auto-generated method stub
		return pd.deletePaperAndPaperEQ(pid);
	}

	public int addPaperEq(int pid, Level level) {
		// TODO Auto-generated method stub
		return pd.addPaperEq(pid, level);
	}

	public ArrayList<Direction> getDirList() {
		// TODO Auto-generated method stub
		return pd.getDirList();
	}

	public ArrayList<Stage> getStageList() {
		// TODO Auto-generated method stub
		return pd.getStageList();
	}

	public ArrayList<Subject> getSubjectList() {
		// TODO Auto-generated method stub
		return pd.getSubjectList();
	}

}
