package com.qhit.dao;

import java.util.ArrayList;

import org.hibernate.Session;

import com.qhit.bean.Paper;
import com.qhit.bean.PaperEq;
import com.qhit.bean.Score;
import com.qhit.bean.StuPaperEq;
import com.qhit.bean.Student;
import com.qhit.util.PageBean;

public interface ExamOnlineDao {
	public Session session = HibernateSessionFactory.getSession();
	public PageBean getPaperByPageBean(int p, int pcid);
	public ArrayList<Paper> getPaperByPid(int pid);
	public int getPaperTotalCountByPid(int pid);//
	public ArrayList<PaperEq> getPaperEqPid(int pid);
	public int addStuPaperEq(int sid, int pid, int eid, String stuanswer);
	public StuPaperEq getStuAnswer(int sid, int pid, int eid);//��ȡѧ����
	public ArrayList<StuPaperEq> getStuAnswerAll(int sid, int pid);//��ȡѧ�����д�
	public int getScore(ArrayList<StuPaperEq> speList, int ptotalScore,int size);//�������
	public int finishExam(String startTime, String finishTime, int socre, int pid, int sid);//��ɿ���
	public ArrayList<Score> getStuSocreList(int pid ,int sid);//��ȡ��ѧ���ĳɼ�
	public int judgeExam(int pid, int sid);//�ж�������ܲ��ܼ�������
	
}
