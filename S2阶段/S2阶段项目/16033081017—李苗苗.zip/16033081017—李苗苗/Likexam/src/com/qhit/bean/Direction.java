package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Direction entity. @author MyEclipse Persistence Tools
 */

public class Direction implements java.io.Serializable {

	// Fields

	private Integer did;
	private String dname;
	private Set subjects = new HashSet(0);
	private Set students = new HashSet(0);

	// Constructors

	/** default constructor */
	public Direction() {
	}

	/** minimal constructor */
	public Direction(Integer did) {
		this.did = did;
	}

	/** full constructor */
	public Direction(Integer did, String dname, Set subjects, Set students) {
		this.did = did;
		this.dname = dname;
		this.subjects = subjects;
		this.students = students;
	}

	// Property accessors

	public Integer getDid() {
		return this.did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public Set getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Set subjects) {
		this.subjects = subjects;
	}

	public Set getStudents() {
		return this.students;
	}

	public void setStudents(Set students) {
		this.students = students;
	}

}