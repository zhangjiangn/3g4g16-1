package com.qhit.biz;

import java.util.ArrayList;
import java.util.Date;

import org.hibernate.Session;

import com.qhit.bean.Paper;
import com.qhit.bean.PaperEq;
import com.qhit.bean.Score;
import com.qhit.bean.StuPaperEq;
import com.qhit.dao.HibernateSessionFactory;
import com.qhit.util.PageBean;

public interface ExamOnlineBiz {
	public Session session = HibernateSessionFactory.getSession();
	public PageBean getPaperByPageBean(int p, int pcid);
	public ArrayList<Paper> getPaperByPid(int pid);//��ȡ�Ծ�
	public int getPaperTotalCountByPid(int pid);//��ȡ�Ծ�������
	public ArrayList<PaperEq> getPaperEqPid(int pid);
	public int addStuPaperEq(int sid, int pid, int eid, String stuanswer);
	public StuPaperEq getStuAnswer(int sid, int pid, int eid);//��ȡѧ����
	public ArrayList<StuPaperEq> getStuAnswerAll(int sid, int pid);//��ȡѧ�����д�
	public int getScore(ArrayList<StuPaperEq> speList, int ptotalScore,int size);//�������
	public int finishExam(String startTime, String finishTime, int socre, int pid, int sid);//��ɿ���
	public String getDate(Date date);
	public ArrayList<Score> getStuSocreList(int pid ,int sid);//��ȡ��ѧ���ĳɼ�
}
