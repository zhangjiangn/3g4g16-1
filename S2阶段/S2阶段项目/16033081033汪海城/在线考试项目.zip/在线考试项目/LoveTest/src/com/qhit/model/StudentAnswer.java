package com.qhit.model;

public class StudentAnswer {
	private Integer studentaid;
	private Student student;
	private Testpaper testpaper;
	private Topic topic;
	private String sanswer;
	//�������Ծ���ʣʱ��
	private Double surplustime;
	//�Ƿ��Ѿ����� 0��Ϊδ������1���ѽ���
	private Integer submit;
	public Integer getStudentaid() {
		return studentaid;
	}
	public void setStudentaid(Integer studentaid) {
		this.studentaid = studentaid;
	}
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Testpaper getTestpaper() {
		return testpaper;
	}
	public void setTestpaper(Testpaper testpaper) {
		this.testpaper = testpaper;
	}
	public Topic getTopic() {
		return topic;
	}
	public void setTopic(Topic topic) {
		this.topic = topic;
	}
	public String getSanswer() {
		return sanswer;
	}
	public void setSanswer(String sanswer) {
		this.sanswer = sanswer;
	}
	public Double getSurplustime() {
		return surplustime;
	}
	public void setSurplustime(Double surplustime) {
		this.surplustime = surplustime;
	}
	public Integer getSubmit() {
		return submit;
	}
	public void setSubmit(Integer submit) {
		this.submit = submit;
	}
	
	
	
	
	
}
