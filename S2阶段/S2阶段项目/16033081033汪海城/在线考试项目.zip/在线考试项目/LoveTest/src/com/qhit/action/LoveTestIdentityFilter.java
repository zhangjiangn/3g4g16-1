package com.qhit.action;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoveTestIdentityFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}

	@Override
	// �����������ֻ��post�ύ��ʽ��������������
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		// ������ת��ΪHttpServletRequest���͵�
		HttpServletRequest request = (HttpServletRequest) arg0;
		// ����Ӧת��ΪHttpServletResponse���͵�
		HttpServletResponse response = (HttpServletResponse) arg1;
		HttpSession session = request.getSession();
		String s = request.getServletPath();
		int length = s.split("/").length;
		if (session.getAttribute("useres") == null
				&& !request.getServletPath().equals("/Login.jsp")
				&& length == 2
				&& !request.getServletPath().equals("/Login_login.action")) {
			response.sendRedirect("Login.jsp");
		}
		// �����������󴫵�
		else {
			arg2.doFilter(request, response);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
	}
}
