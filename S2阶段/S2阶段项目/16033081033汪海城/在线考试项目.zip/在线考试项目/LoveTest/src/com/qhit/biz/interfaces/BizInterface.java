package com.qhit.biz.interfaces;

public interface BizInterface {

	/**
	 * ��¼��֤
	 * */
	public <T> Object Login(Object obj);

}
