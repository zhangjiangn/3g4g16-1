package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * TestPaper entity. @author MyEclipse Persistence Tools
 */

public class TestPaper implements java.io.Serializable {

	// Fields

	private Integer tpid;
	private Subject subject;
	private String tpname;
	private String testTime;
	private String state;
	private String startime;
    private String jieshutime;
    private Integer avg;
    private Integer tishu;
	private Set Title = new HashSet(0);
	private Set classroom = new HashSet(0);
	private Set studentanswer=new HashSet();
	private Set studentscore=new HashSet();
	// Constructors

	/** default constructor */
	public TestPaper() {
	}

	/** minimal constructor */
	public TestPaper(Integer tpid) {
		this.tpid = tpid;
	}

	/** full constructor */
	

	// Property accessors

	public Integer getTpid() {
		return this.tpid;
	}

	public TestPaper(Integer tpid, Subject subject, String tpname,
			String testTime, String state, String startime, String jieshutime,
			Integer avg, Integer tishu, Set title, Set classroom,
			Set studentanswer, Set studentscore) {
		super();
		this.tpid = tpid;
		this.subject = subject;
		this.tpname = tpname;
		this.testTime = testTime;
		this.state = state;
		this.startime = startime;
		this.jieshutime = jieshutime;
		this.avg = avg;
		this.tishu = tishu;
		Title = title;
		this.classroom = classroom;
		this.studentanswer = studentanswer;
		this.studentscore = studentscore;
	}

	public Set getStudentscore() {
		return studentscore;
	}

	public void setStudentscore(Set studentscore) {
		this.studentscore = studentscore;
	}

	public Set getStudentanswer() {
		return studentanswer;
	}

	public void setStudentanswer(Set studentanswer) {
		this.studentanswer = studentanswer;
	}

	public void setTpid(Integer tpid) {
		this.tpid = tpid;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getTpname() {
		return this.tpname;
	}

	public void setTpname(String tpname) {
		this.tpname = tpname;
	}

	public String getTestTime() {
		return this.testTime;
	}

	public void setTestTime(String testTime) {
		this.testTime = testTime;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Set getTitle() {
		return Title;
	}

	public void setTitle(Set title) {
		Title = title;
	}

	public Set getClassroom() {
		return classroom;
	}

	public void setClassroom(Set classroom) {
		this.classroom = classroom;
	}

	public String getStartime() {
		return startime;
	}

	public void setStartime(String startime) {
		this.startime = startime;
	}

	public String getJieshutime() {
		return jieshutime;
	}

	public void setJieshutime(String jieshutime) {
		this.jieshutime = jieshutime;
	}

	public Integer getAvg() {
		return avg;
	}

	public void setAvg(Integer avg) {
		this.avg = avg;
	}

	public Integer getTishu() {
		return tishu;
	}

	public void setTishu(Integer tishu) {
		this.tishu = tishu;
	}

	

}