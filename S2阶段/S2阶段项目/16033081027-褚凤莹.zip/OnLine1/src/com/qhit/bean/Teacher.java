package com.qhit.bean;

/**
 * Teacher entity. @author MyEclipse Persistence Tools
 */

public class Teacher implements java.io.Serializable {

	// Fields

	private Integer tid;
	private String taccount;
	private String tpwd;

	// Constructors

	/** default constructor */
	public Teacher() {
	}

	/** minimal constructor */
	public Teacher(Integer tid) {
		this.tid = tid;
	}

	/** full constructor */
	public Teacher(Integer tid, String taccount, String tpwd) {
		this.tid = tid;
		this.taccount = taccount;
		this.tpwd = tpwd;
	}

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public String getTaccount() {
		return this.taccount;
	}

	public void setTaccount(String taccount) {
		this.taccount = taccount;
	}

	public String getTpwd() {
		return this.tpwd;
	}

	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}

}