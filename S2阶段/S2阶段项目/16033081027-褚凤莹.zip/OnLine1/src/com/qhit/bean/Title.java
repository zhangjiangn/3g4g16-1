package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Title entity. @author MyEclipse Persistence Tools
 */

public class Title implements java.io.Serializable {

	// Fields

	private Integer tid;
	private Subject subject;
	private String tname;
	private Integer shiti;
	private Integer danxuan;
	private String nandu;
	private String a;
	private String b;
	private String c;
	private String d;
	private String answer;
	private String chapter;
	private Set testPaper = new HashSet(0);
	private Set studentanswer=new HashSet();
	// Constructors

	/** default constructor */
	public Title() {
	}

	/** minimal constructor */
	public Title(Integer tid, String nandu) {
		this.tid = tid;
		this.nandu = nandu;
	}

	/** full constructor */
	

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public Title(Integer tid, Subject subject, String tname, Integer shiti,
			Integer danxuan, String nandu, String a, String b, String c,
			String d, String answer, String chapter, Set testPaper,
			Set studentanswer) {
		super();
		this.tid = tid;
		this.subject = subject;
		this.tname = tname;
		this.shiti = shiti;
		this.danxuan = danxuan;
		this.nandu = nandu;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.answer = answer;
		this.chapter = chapter;
		this.testPaper = testPaper;
		this.studentanswer = studentanswer;
	}

	public Set getStudentanswer() {
		return studentanswer;
	}

	public void setStudentanswer(Set studentanswer) {
		this.studentanswer = studentanswer;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public Integer getShiti() {
		return this.shiti;
	}

	public void setShiti(Integer shiti) {
		this.shiti = shiti;
	}

	public Integer getDanxuan() {
		return this.danxuan;
	}

	public void setDanxuan(Integer danxuan) {
		this.danxuan = danxuan;
	}

	public String getNandu() {
		return this.nandu;
	}

	public void setNandu(String nandu) {
		this.nandu = nandu;
	}

	public String getA() {
		return this.a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getB() {
		return this.b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return this.c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getD() {
		return this.d;
	}

	public void setD(String d) {
		this.d = d;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getChapter() {
		return this.chapter;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public Set getTestPaper() {
		return testPaper;
	}

	public void setTestPaper(Set testPaper) {
		this.testPaper = testPaper;
	}

	

}