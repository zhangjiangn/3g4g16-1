package com.qhit.bean;

/**
 * StudentAnswer entity. @author MyEclipse Persistence Tools
 */

public class StudentAnswer implements java.io.Serializable {

	// Fields

	private Integer said;
	private Title title;
	private Student student;
	private TestPaper testPaper;
	private String time;
	private String stuanswer;

	// Constructors

	/** default constructor */
	public StudentAnswer() {
	}

	/** minimal constructor */
	public StudentAnswer(Integer said) {
		this.said = said;
	}

	/** full constructor */
	public StudentAnswer(Integer said, Title title, Student student,
			TestPaper testPaper, String time, String stuanswer) {
		this.said = said;
		this.title = title;
		this.student = student;
		this.testPaper = testPaper;
		this.time = time;
		this.stuanswer = stuanswer;
	}

	// Property accessors

	public Integer getSaid() {
		return this.said;
	}

	public void setSaid(Integer said) {
		this.said = said;
	}

	public Title getTitle() {
		return this.title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public String getTime() {
		return this.time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getStuanswer() {
		return this.stuanswer;
	}

	public void setStuanswer(String stuanswer) {
		this.stuanswer = stuanswer;
	}

}