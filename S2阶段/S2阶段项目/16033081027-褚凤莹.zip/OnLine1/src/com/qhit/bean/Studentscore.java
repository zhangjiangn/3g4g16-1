package com.qhit.bean;

import java.sql.Timestamp;

/**
 * Studentscore entity. @author MyEclipse Persistence Tools
 */

public class Studentscore implements java.io.Serializable {

	// Fields

	private Integer ssid;
	private Student student;
	private TestPaper testPaper;
	private Integer sum;
	private Timestamp losetime;
	
	// Constructors

	/** default constructor */
	public Studentscore() {
	}

	/** minimal constructor */
	public Studentscore(Integer ssid) {
		this.ssid = ssid;
	}

	/** full constructor */
	public Studentscore(Integer ssid, Student student, TestPaper testPaper,
			Integer sum, Timestamp losetime) {
		this.ssid = ssid;
		this.student = student;
		this.testPaper = testPaper;
		this.sum = sum;
		this.losetime = losetime;
	}

	// Property accessors

	public Integer getSsid() {
		return this.ssid;
	}

	public void setSsid(Integer ssid) {
		this.ssid = ssid;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Integer getSum() {
		return this.sum;
	}

	public void setSum(Integer sum) {
		this.sum = sum;
	}

	public Timestamp getLosetime() {
		return this.losetime;
	}

	public void setLosetime(Timestamp losetime) {
		this.losetime = losetime;
	}

}