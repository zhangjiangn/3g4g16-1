package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;


/**
 * Subject entity. @author MyEclipse Persistence Tools
 */

public class Subject  implements java.io.Serializable {


    // Fields    

     private Integer jid;
     private Stage stage;
     private String jname;
     private Set testPapers = new HashSet(0);
     private Set titles = new HashSet(0);


    // Constructors

    /** default constructor */
    public Subject() {
    }

	/** minimal constructor */
    public Subject(Integer jid) {
        this.jid = jid;
    }
    
    /** full constructor */
    public Subject(Integer jid, Stage stage, String jname, Set testPapers, Set titles) {
        this.jid = jid;
        this.stage = stage;
        this.jname = jname;
        this.testPapers = testPapers;
        this.titles = titles;
    }

   
    // Property accessors

    public Integer getJid() {
        return this.jid;
    }
    
    public void setJid(Integer jid) {
        this.jid = jid;
    }

    public Stage getStage() {
        return this.stage;
    }
    
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public String getJname() {
        return this.jname;
    }
    
    public void setJname(String jname) {
        this.jname = jname;
    }

    public Set getTestPapers() {
        return this.testPapers;
    }
    
    public void setTestPapers(Set testPapers) {
        this.testPapers = testPapers;
    }

    public Set getTitles() {
        return this.titles;
    }
    
    public void setTitles(Set titles) {
        this.titles = titles;
    }
   








}