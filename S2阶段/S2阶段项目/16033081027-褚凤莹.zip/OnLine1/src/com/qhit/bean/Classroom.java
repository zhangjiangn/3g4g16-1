package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;


/**
 * Classroom entity. @author MyEclipse Persistence Tools
 */

public class Classroom  implements java.io.Serializable {


    // Fields    

     private Integer cid;
     private String cname;    
     private Set testpaper = new HashSet(0);
     private Set stu=new HashSet();

    // Constructors

    /** default constructor */
    public Classroom() {
    }

	/** minimal constructor */
    public Classroom(Integer cid) {
        this.cid = cid;
    }
    
    /** full constructor */
    

   
    // Property accessors

    public Integer getCid() {
        return this.cid;
    }
    
   

	public Classroom(Integer cid, String cname, 
			 Set testpaper, Set stu) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.testpaper = testpaper;
		this.stu = stu;
	}

	public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getCname() {
        return this.cname;
    }
    
    public void setCname(String cname) {
        this.cname = cname;
    }

    public Set getTestpaper() {
        return this.testpaper;
    }
    
    public void setTestpaper(Set testpaper) {
        this.testpaper = testpaper;
    }

	public Set getStu() {
		return stu;
	}

	public void setStu(Set stu) {
		this.stu = stu;
	}
   








}