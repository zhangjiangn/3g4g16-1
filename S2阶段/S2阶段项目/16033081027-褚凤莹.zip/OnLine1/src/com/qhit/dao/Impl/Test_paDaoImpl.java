package com.qhit.dao.Impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.hibernate.Query;

import com.qhit.bean.Classroom;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.bean.TestPaper;
import com.qhit.bean.Title;
import com.qhit.dao.Test_paDao;

public class Test_paDaoImpl implements Test_paDao {
	public List<Subject> getSub(Stage s, Direction dir) {
		Query query = session
				.createQuery(
						"from Subject s where s.stage.sname=? and s.stage.direction.dname=?")
				.setParameter(0, s.getSname()).setParameter(1, dir.getDname());
		return query.list();
	}

	public List<Object[]> getPaper() {
		List<Object[]> query = (List<Object[]>) session.createQuery(
				"select s.jname, tp from TestPaper tp left join tp.subject s ")
				.list();
		return query;

	}

	public List<Object[]> getPaperByname(Subject j, Stage s, Direction d,
			TestPaper tp) {
		List<Object[]> query = (List<Object[]>) session
				.createQuery(
						"select s.jname,t from TestPaper t left join t.subject s  where s.jname=? and s.stage.sname=? and s.stage.direction.dname=? and t.state=?")
				.setParameter(0, j.getJname()).setParameter(1, s.getSname())
				.setParameter(2, d.getDname()).setParameter(3, tp.getState())
				.list();
		return query;
	}

	public List<Title> getT(Subject j, Stage s, Direction d) {
		Query query = session
				.createQuery(
						"select t from Title t  left join t.subject s where s.jname=? and s.stage.sname=? and s.stage.direction.dname=?")
				.setParameter(0, j.getJname()).setParameter(1, s.getSname())
				.setParameter(2, d.getDname());
		return query.list();
	}

	public int addTestPaperTitle(Set<Title> t, TestPaper tp, Subject j,
			Stage s, Direction dir) {
		int i = 0;
		try {
			System.out.println(dir.getDname() + "0000000000");
			TestPaper tpp = new TestPaper();

			Subject subject = (Subject) session
					.createQuery(
							"from Subject j where j.stage.sname=? and j.stage.direction.dname=? and j.jname=?")
					.setParameter(0, s.getSname()).setParameter(1,
							dir.getDname()).setParameter(2, j.getJname())
					.uniqueResult();
			tpp.setTpname(tp.getTpname());
			tpp.setSubject(subject);
			tpp.setTitle(t);
			session.save(tpp);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			i = 1;
		}
		return i;

	}

	public List<Title> getTitleById(List<Title> tests) {
		List<Title> tt = new ArrayList<Title>();
		for (int i = 0; i < tests.size(); i++) {
			Title t = (Title) session.createQuery("from Title t where t.tid=?")
					.setParameter(0, tests.get(i).getTid()).uniqueResult();
			tt.add(t);
		}
		// session.createQuery("from Title t where t.tid=?").setParameter(0,
		// id)ist();
		return tt;
	}

	public List<Title> chakan(int i) {
		TestPaper tp = (TestPaper) session.get(TestPaper.class, i);
		return new ArrayList<Title>(tp.getTitle());
	}

	public List<Title> randomTitle(List<Title> t) {
		List<Title> ti = new ArrayList<Title>();
		Title tt = new Title();
		Random r = new Random();
		List<Integer> list = new ArrayList<Integer>();
		for (Title title : t) {
			list.add(title.getTid());
		}
		int i;
		while (ti.size() < 3) {
			i = r.nextInt(17);
			if (!ti.contains(i)) {
				tt = (Title) session.createQuery("from Title t where t.tid=?")
						.setParameter(0, i).uniqueResult();
				System.out.println(ti.size() + "0000");
				ti.add(tt);
			}
		}

		return ti;
	}

	public List<Classroom> getRoom() {
		return session.createQuery("from Classroom").list();
	}
	public int addtpTestClass(TestPaper  tp,Classroom cm){
		Set<Classroom> cmset=new HashSet<Classroom>();
		int i=0;
		try {
			session.beginTransaction();
			TestPaper t=(TestPaper) session.get(TestPaper.class, tp.getTpid());
			Classroom cr=(Classroom) session.get(Classroom.class, cm.getCid());
			
			cmset.add(cr);
			t.setState("������");
			t.setClassroom(cmset);			
			session.update(t);
			session.save(t);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			i=1;
		}
		return i;
	}
	//public List<TestPaper> 
}
