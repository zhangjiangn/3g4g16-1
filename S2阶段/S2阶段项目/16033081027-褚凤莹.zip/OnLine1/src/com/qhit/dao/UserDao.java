package com.qhit.dao;

import java.util.List;

import org.hibernate.Session;

import com.qhit.bean.Admin;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.bean.Teacher;
import com.qhit.bean.Title;
import com.qhit.bean.Users;
import com.qhit.biz.PageBean;

public interface UserDao {
	
	public Session session=HibernateSessionFactory.getSession();
	
	public List Get(String hql ,Object [] object);
	
	
	public PageBean selectfenye(String hql ,Object [] object,PageBean p);
	public int addTi(Object object);
	
	
}
