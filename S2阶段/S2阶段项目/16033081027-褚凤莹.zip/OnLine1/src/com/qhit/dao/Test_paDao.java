package com.qhit.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;

import com.qhit.bean.Classroom;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.bean.TestPaper;
import com.qhit.bean.Title;

public interface Test_paDao {
	public Session session=HibernateSessionFactory.getSession();
	
	public List<Subject> getSub(Stage s,Direction dir);
	
	public List<Object []> getPaper();
	
	 public List<Object[]> getPaperByname(Subject j,Stage s,Direction d,TestPaper tp);
	 
	 public List<Title> getT(Subject j,Stage s,Direction d);
	 
	 public int addTestPaperTitle(Set<Title> t,TestPaper tp,Subject j,Stage s,Direction dir);
	 
	 public List<Title> getTitleById(List<Title> tests);
	 
	 public List<Title> chakan(int i);
	 
	 public List<Title> randomTitle(List<Title> t);
	 
	 public List<Classroom> getRoom();
	 
	 public int addtpTestClass(TestPaper  tp,Classroom cm);
}
