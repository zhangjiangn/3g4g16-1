package com.qhit.biz.impl;

import java.util.List;
import java.util.Set;

import com.qhit.bean.Classroom;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.bean.TestPaper;
import com.qhit.bean.Title;
import com.qhit.biz.Test_paDaoBiz;
import com.qhit.dao.Test_paDao;
import com.qhit.dao.Impl.Test_paDaoImpl;

public class Test_paDaoBizImpl implements Test_paDaoBiz {
	Test_paDao tpdao=new Test_paDaoImpl();
	public List<Subject> getSub(Stage s, Direction dir) {
		// TODO Auto-generated method stub
		return tpdao.getSub(s, dir);
	}
	public List<Object[]> getPaper() {
		// TODO Auto-generated method stub
		return tpdao.getPaper();
	}
	public List<Object[]> getPaperByname(Subject j, Stage s, Direction d,
			TestPaper tp) {
		// TODO Auto-generated method stub
		return tpdao.getPaperByname(j, s, d, tp);
	}
	public List<Title> getT(Subject j, Stage s, Direction d) {
		// TODO Auto-generated method stub
		return tpdao.getT(j, s, d);
	}
	public int addTestPaperTitle(Set<Title> t,TestPaper tp,Subject j,Stage s,Direction dir) {
		// TODO Auto-generated method stub
		return tpdao.addTestPaperTitle(t,tp,j,s,dir);
	}
	 public List<Title> getTitleById(List<Title> tests) {
		// TODO Auto-generated method stub
		return tpdao.getTitleById(tests);
	}
	public List<Title> chakan(int i) {
		// TODO Auto-generated method stub
		return tpdao.chakan(i);
	}
	public List<Title> randomTitle(List<Title> t) {
		// TODO Auto-generated method stub
		return tpdao.randomTitle(t);
	}
	public List<Classroom> getRoom() {
		// TODO Auto-generated method stub
		return tpdao.getRoom();
	}
	public int addtpTestClass(TestPaper tp, Classroom cm) {
		// TODO Auto-generated method stub
		return tpdao.addtpTestClass(tp, cm);
	}
	
}
