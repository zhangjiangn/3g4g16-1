package com.qhit.biz.impl;

import java.util.ArrayList;
import java.util.List;

import com.qhit.bean.Admin;
import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.bean.Teacher;
import com.qhit.bean.Title;
import com.qhit.bean.Users;
import com.qhit.biz.PageBean;
import com.qhit.biz.UserDaoBiz;
import com.qhit.dao.UserDao;
import com.qhit.dao.Impl.UserDaoImpl;

public class UserDaoBizImpl implements UserDaoBiz{
	UserDao udao=new UserDaoImpl();
	public Object login(Object object){
		Users users=(Users)object;
		String hql=null;
		Object [] obj=new Object [2];//���hql�е�����
		List list=null;
		Object object1=null;
		//ѧ��
		if(users.getId()==1){
			hql="from Student s where s.saccount=? and s.spwd=?";
			obj[0]=users.getName();
			obj[1]=users.getPwd();
			list=udao.Get(hql, obj);
		//��ʦ
		}else if(users.getId()==2){
			hql="from Teacher t where t.taccount=? and t.tpwd=?";
			obj[0]=users.getName();
			obj[1]=users.getPwd();
			list=udao.Get(hql, obj);
		//����Ա
		}else if(users.getId()==3){
			hql="from Admin a where a.account=? and a.apwd=?";
			obj[0]=users.getName();
			obj[1]=users.getPwd();
			list=udao.Get(hql, obj);
		}
		if(list.size()!=0){
			object1=list.get(0);
		}
		return object1;
	}
	//��ѯ��ü���
	public List Get(String hql, Object[] object) {
		List list=new ArrayList();
		list=udao.Get(hql, object);
		return list;
	}
	//��ҳ
	public PageBean selectfenye(String hql, Object[] object, PageBean p) {
		p=udao.selectfenye(hql, object, p);
		return p;
	}
	
	
	
	
	public int addTi(Object object){
		return udao.addTi(object);
	}
	




	

}
