package odbc;
import java.sql.Connection;
import java.sql.DriverManager;


public class ODBC {

	/**
	 * @param args
	 */
	
	public static Connection conn=null;
	
	
	public static Connection getConn(){
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			String url="jdbc:oracle:thin:127.0.0.1:1521:orcl";
			String user="scott";
			String password="123";
			conn=DriverManager.getConnection(url, user, password);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	

}
