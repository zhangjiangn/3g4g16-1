package fangfa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import t.ODBC;

import e.Emp;

public class FF {
	Connection conn=ODBC.getconnection();
	public List<Emp> allemp(){
		List<Emp> emp=new ArrayList<Emp>();
		try {
			PreparedStatement ps = conn.prepareStatement("select * from emp");
			ResultSet rs=ps.executeQuery();
			
			while (rs.next()) {
				Emp em=new Emp();
				em.setEmpno(rs.getInt("empno"));
				em.setEname(rs.getString("ename"));
				em.setJob(rs.getString("job"));
				em.setSal(rs.getString("sal"));
				emp.add(em);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
		
	}
	public List<Object[]> all(){
		List<Object[]> list=new ArrayList<Object[]>();
		
		try {
			PreparedStatement ps = conn.prepareStatement("select * from emp");
			ResultSet rs=ps.executeQuery();
	
			while (rs.next()) {
				Object[] ob=new Object[4];
				ob[0]=rs.getObject(1);
				ob[1]=rs.getObject(2);
				ob[2]=rs.getObject(3);
				ob[3]=rs.getObject(6);
				list.add(ob);
		    }
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
		
		
	}
	
	
	public int add(Emp emp){
		int i=0;
		try {
			PreparedStatement ps=conn.prepareStatement("insert into emp(empno,ename,job,sal) values(?,?,?,?)");
			ps.setInt(1, emp.getEmpno());
			ps.setString(2, emp.getEname());
			ps.setString(3, emp.getJob());
			ps.setString(4, emp.getSal());
			i=ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	public int delete(int j){
		int i=0;
		try {
			PreparedStatement ps=conn.prepareStatement("delete from emp where empno=?");
			ps.setInt(1, j);
			i=ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
		
	}
	

}
