package text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import t.ODBC;
import e.Emp;
import fangfa.FF;

public class Text {
	public static void main(String[] args) {
		FF ff=new FF();
//		List<Emp> emps=ff.allemp();
//		for (Emp emp : emps) {
//			System.out.println(emp.getEmpno()+"---"+emp.getEname()+"--"+emp.getJob()+"--"+emp.getSal());
//		}
		
		List<Object[]> list=ff.all();
		for (Object[] ob : list) {
			System.err.println(ob[0]+"---"+ob[1]+"---"+ob[2]+"---"+ob[3]);
			
		}
		//����
//		Emp emp = new Emp();
//	
//		emp.setEmpno(1);
//		emp.setEname("����");
//		emp.setJob("111");
//		emp.setSal("1400");
//		ff.add(emp);
//		emp.toString();
//		
		//ɾ��
		//ff.delete(1);
		
	}

}
