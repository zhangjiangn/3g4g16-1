package ojdbc_test1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.WangHaiCheng;

public class ODBC {
	private static Connection conn;
	private static String url;
	private static String user;
	private static String password;
	private PreparedStatement ps;
	private ResultSet rs;
	private static Connection getConn(){
		try {
			url="jdbc:oracle:thin:127.0.0.1:1521:orcl";
			user="sys as sysdba";
			password="123";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return conn;
	}
	/**
	 * ���ӷ���
	 * @author ���ղ�
	 * @param whc ������ʵ�������
	 * @return ��
	 * */
	private void Insert(WangHaiCheng whc){
		conn=getConn();
		String sql="insert into whc values(?,?,?)";
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1, whc.getId());
			ps.setString(2, whc.getName());
			ps.setString(3,whc.getSex());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/**
	 * �޸ķ���
	 * @author ���ղ�
	 * @param whc ������ʵ�������
	 * @return ��
	 * */
	private void Update(WangHaiCheng whc){
		conn=getConn();
		String sql="update whc set wname=?   where wid=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1, whc.getName());
			ps.setInt(2,whc.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/**
	 * ��ѯ����
	 * @author ���ղ�
	 * @param id ��ѯ�Ķ���ID
	 * @return ��
	 * */
	public WangHaiCheng Select(Integer id){
		WangHaiCheng whc=new WangHaiCheng();
		conn=getConn();
		String sql="select * from whc where wid=?";
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1,id);	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs=ps.executeQuery();
			while (rs.next()) {
				whc.setId(rs.getInt(1));
				whc.setName(rs.getString(2));
				whc.setSex(rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return whc;
	}
	
	
	
	
	
	
	
	/**
	 * ��ѯ����
	 * @author ���ղ�
	 * @param id ��ѯ�Ķ���ID
	 * @return ��
	 * */
	public List Select(){
	List<WangHaiCheng> list=new ArrayList<WangHaiCheng>();
		conn=getConn();
		String sql="select * from whc";
		try {
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
		
			while (rs.next()) {
				WangHaiCheng whc=new WangHaiCheng();
				whc.setId(rs.getInt(1));
				whc.setName(rs.getString(2));
				whc.setSex(rs.getString(3));
				list.add(whc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public static void main(String[] args) {
//		ODBC odbc=new ODBC();
//		WangHaiCheng wh=new WangHaiCheng();
//		wh.setId(1);
//		wh.setName("������");
//		wh.setSex("��");
//		odbc.Insert(wh);
		ODBC odbc=new ODBC();
		List<WangHaiCheng> list=odbc.Select();
		for (WangHaiCheng w : list) {
			System.out.println(w.getName());
		}
	
	}

}
